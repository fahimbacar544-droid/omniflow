# OmniFlow — Guide de démarrage complet

## Stack technique
- **Next.js 14** — Frontend + API routes
- **PostgreSQL + Prisma** — Base de données
- **Stripe** — Paiements + webhooks
- **JWT + bcrypt** — Auth sécurisée

---

## 1. Installation

```bash
# Cloner et installer
cd omniflow
npm install

# Générer le client Prisma
npm run db:generate
```

---

## 2. Configuration des variables d'environnement

Copie `.env.example` en `.env` et remplis chaque valeur :

```bash
cp .env.example .env
```

### DATABASE_URL
PostgreSQL local :
```
DATABASE_URL="postgresql://postgres:monpassword@localhost:5432/omniflow"
```
Sur Railway/Supabase : copier l'URL fournie directement.

### JWT_SECRET
Génère une clé aléatoire sécurisée :
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### Clés Stripe

1. Va sur https://dashboard.stripe.com/apikeys
2. Copie **Secret key** → `STRIPE_SECRET_KEY`

---

## 3. Créer les produits dans Stripe

Dans le dashboard Stripe → **Produits** → Créer :

| Nom | Prix | Facturation | Variable env |
|-----|------|-------------|--------------|
| OmniFlow Starter | 29€ | Mensuelle | `STRIPE_PRICE_STARTER` |
| OmniFlow Pro | 79€ | Mensuelle | `STRIPE_PRICE_PRO` |
| OmniFlow Business | 149€ | Mensuelle | `STRIPE_PRICE_BUSINESS` |
| OmniFlow Enterprise | 499€ | Mensuelle | `STRIPE_PRICE_ENTERPRISE` |

Pour chaque produit, copie l'ID du **prix** (commence par `price_`) dans `.env`.

---

## 4. Configurer le webhook Stripe

### En développement (Stripe CLI)

```bash
# Installer Stripe CLI
# https://stripe.com/docs/stripe-cli

# Login
stripe login

# Écouter les webhooks en local
stripe listen --forward-to localhost:3000/api/webhook/stripe

# Stripe affiche : "Your webhook signing secret is whsec_..."
# → Copiez cette valeur dans STRIPE_WEBHOOK_SECRET
```

### En production

1. Dashboard Stripe → **Développeurs** → **Webhooks** → Ajouter un endpoint
2. URL : `https://votre-domaine.com/api/webhook/stripe`
3. Événements à sélectionner :
   - `checkout.session.completed`
   - `invoice.payment_succeeded`
   - `invoice.payment_failed`
   - `customer.subscription.deleted`
   - `customer.subscription.updated`
4. Copier le **Signing secret** → `STRIPE_WEBHOOK_SECRET`

---

## 5. Initialiser la base de données

```bash
# Créer/migrer les tables
npm run db:push

# (Optionnel) Ouvrir l'interface Prisma Studio
npm run db:studio
```

---

## 6. Lancer en développement

```bash
npm run dev
# → http://localhost:3000
```

Ouvrir un 2e terminal pour les webhooks Stripe :
```bash
stripe listen --forward-to localhost:3000/api/webhook/stripe
```

---

## 7. Flux utilisateur complet

```
1. /register       → Création compte (plan FREE par défaut)
2. /pricing        → Choix du plan → redirection Stripe Checkout
3. Stripe Checkout → Paiement carte
4. Stripe webhook  → /api/webhook/stripe → plan activé en DB
5. /dashboard      → Accès immédiat avec le bon plan
```

---

## 8. Structure des fichiers

```
omniflow/
├── lib/
│   ├── prisma.ts          # Client Prisma singleton
│   ├── auth.ts            # JWT, bcrypt, cookies
│   ├── auth-context.tsx   # React context + hooks
│   └── stripe.ts          # Config Stripe + plans
│
├── pages/
│   ├── _app.tsx           # AuthProvider global
│   ├── login.tsx          # Page connexion
│   ├── register.tsx       # Page inscription
│   ├── pricing.tsx        # Page tarifs + Checkout
│   └── dashboard/
│       └── index.tsx      # Dashboard principal
│
├── pages/api/
│   ├── auth/
│   │   ├── register.ts    # POST /api/auth/register
│   │   ├── login.ts       # POST /api/auth/login
│   │   ├── logout.ts      # POST /api/auth/logout
│   │   └── me.ts          # GET  /api/auth/me
│   ├── stripe/
│   │   ├── checkout.ts    # POST /api/stripe/checkout
│   │   └── portal.ts      # POST /api/stripe/portal
│   └── webhook/
│       └── stripe.ts      # POST /api/webhook/stripe
│
└── prisma/
    └── schema.prisma      # Modèles User + Subscription
```

---

## 9. Déploiement (Railway — le plus simple)

```bash
# 1. Créer un projet sur railway.app
# 2. Ajouter un service PostgreSQL
# 3. Copier DATABASE_URL dans les variables d'env
# 4. Déployer via Git ou CLI

railway up
```

Variables à configurer dans Railway :
- `DATABASE_URL` (auto-rempli si service PostgreSQL Railway)
- `JWT_SECRET`
- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`
- `STRIPE_PRICE_STARTER`, `STRIPE_PRICE_PRO`, `STRIPE_PRICE_BUSINESS`, `STRIPE_PRICE_ENTERPRISE`
- `NEXT_PUBLIC_APP_URL` = `https://ton-projet.railway.app`

---

## 10. Test des paiements (cartes Stripe test)

| Carte | Résultat |
|-------|----------|
| `4242 4242 4242 4242` | Paiement réussi ✅ |
| `4000 0000 0000 9995` | Paiement refusé ❌ |
| `4000 0025 0000 3155` | Authentification 3DS |

Date : n'importe quelle date future · CVC : n'importe quel chiffre

---

## 11. Sécurité en production

- [ ] `JWT_SECRET` minimum 64 caractères aléatoires
- [ ] HTTPS activé (Railway/Vercel le font automatiquement)
- [ ] Cookie `Secure` activé (déjà dans le code si `NODE_ENV=production`)
- [ ] Variables d'env jamais dans le code ou Git
- [ ] Webhook Stripe vérifié par signature (déjà implémenté)
