import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { NextApiRequest, NextApiResponse } from 'next'
import { parse } from 'cookie'

const JWT_SECRET = process.env.JWT_SECRET!

export interface JWTPayload {
  userId: string
  email: string
}

// Hash un mot de passe
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12)
}

// Vérifie un mot de passe
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash)
}

// Crée un JWT (expire en 7 jours)
export function createToken(payload: JWTPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' })
}

// Vérifie et décode un JWT
export function verifyToken(token: string): JWTPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as JWTPayload
  } catch {
    return null
  }
}

// Cookie sécurisé
export function setAuthCookie(res: NextApiResponse, token: string) {
  res.setHeader('Set-Cookie', [
    `omniflow_token=${token}; HttpOnly; Path=/; Max-Age=${7 * 24 * 60 * 60}; SameSite=Lax${
      process.env.NODE_ENV === 'production' ? '; Secure' : ''
    }`,
  ])
}

export function clearAuthCookie(res: NextApiResponse) {
  res.setHeader('Set-Cookie', 'omniflow_token=; HttpOnly; Path=/; Max-Age=0')
}

// Middleware : récupère l'utilisateur depuis la requête
export function getAuthUser(req: NextApiRequest): JWTPayload | null {
  const cookies = parse(req.headers.cookie || '')
  const token = cookies.omniflow_token
  if (!token) return null
  return verifyToken(token)
}

// Middleware : protège une route API
export function requireAuth(
  handler: (req: NextApiRequest, res: NextApiResponse, user: JWTPayload) => Promise<void>
) {
  return async (req: NextApiRequest, res: NextApiResponse) => {
    const user = getAuthUser(req)
    if (!user) {
      return res.status(401).json({ error: 'Non authentifié' })
    }
    return handler(req, res, user)
  }
}
