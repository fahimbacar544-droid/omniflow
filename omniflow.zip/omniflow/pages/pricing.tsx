import { useState } from 'react'
import { useUser, useRequireAuth } from '../lib/auth-context'
import { PLANS } from '../lib/stripe'
import { useRouter } from 'next/router'
import Head from 'next/head'

export default function PricingPage() {
  const { user } = useRequireAuth()
  const router = useRouter()
  const [loadingPlan, setLoadingPlan] = useState<string | null>(null)
  const [error, setError] = useState('')

  const handleSubscribe = async (planId: string) => {
    setError('')
    setLoadingPlan(planId)
    try {
      const res = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ planId }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      // Redirection vers Stripe Checkout
      window.location.href = data.url
    } catch (err: any) {
      setError(err.message)
      setLoadingPlan(null)
    }
  }

  if (!user) return null

  return (
    <>
      <Head><title>Choisir un plan — OmniFlow</title></Head>
      <div style={styles.page}>
        <div style={styles.header}>
          <div style={styles.logo} onClick={() => router.push('/dashboard')}>
            Omni<span style={{ color: '#c8f135' }}>Flow</span>
          </div>
          <h1 style={styles.title}>Choisissez votre plan</h1>
          <p style={styles.sub}>
            {user.plan === 'FREE'
              ? 'Débloquez toutes les fonctionnalités — accès immédiat après paiement'
              : `Plan actuel : ${user.plan}`}
          </p>
          {router.query.success && (
            <div style={styles.successBanner}>
              ✅ Paiement réussi ! Votre plan est maintenant actif.
            </div>
          )}
          {error && <div style={styles.errorBanner}>{error}</div>}
        </div>

        <div style={styles.grid}>
          {PLANS.map(plan => {
            const isCurrent = user.plan === plan.id
            const isLoading = loadingPlan === plan.id

            return (
              <div
                key={plan.id}
                style={{
                  ...styles.card,
                  ...(plan.popular ? styles.cardFeatured : {}),
                }}
              >
                {plan.popular && <div style={styles.badge}>⭐ Le plus populaire</div>}
                <div style={styles.tier}>{plan.name}</div>
                <div style={styles.price}>
                  {plan.price}
                  <span style={styles.pricePer}>€/mois</span>
                </div>
                <div style={styles.divider} />
                <ul style={styles.features}>
                  {plan.features.map(f => (
                    <li key={f} style={styles.feature}>
                      <span style={{ color: '#c8f135', marginRight: '8px' }}>✓</span>
                      {f}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => !isCurrent && handleSubscribe(plan.id)}
                  disabled={isCurrent || !!loadingPlan}
                  style={{
                    ...styles.btn,
                    ...(plan.popular ? styles.btnFeatured : {}),
                    ...(isCurrent ? styles.btnCurrent : {}),
                  }}
                >
                  {isCurrent
                    ? '✓ Plan actuel'
                    : isLoading
                    ? 'Redirection...'
                    : 'Choisir ce plan →'}
                </button>
              </div>
            )
          })}
        </div>

        <p style={styles.guarantee}>
          🔒 Paiement sécurisé par Stripe · Annulation à tout moment · Accès immédiat
        </p>
      </div>
    </>
  )
}

const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: '100vh',
    background: '#0a0a0a',
    fontFamily: 'system-ui, sans-serif',
    padding: '40px 24px 80px',
    color: '#fafaf8',
  },
  header: {
    textAlign: 'center',
    maxWidth: '600px',
    margin: '0 auto 56px',
  },
  logo: {
    fontFamily: 'Georgia, serif',
    fontSize: '20px',
    color: '#fafaf8',
    marginBottom: '32px',
    cursor: 'pointer',
    display: 'inline-block',
  },
  title: {
    fontSize: '38px',
    fontFamily: 'Georgia, serif',
    fontWeight: 400,
    letterSpacing: '-1px',
    marginBottom: '12px',
  },
  sub: {
    fontSize: '16px',
    color: 'rgba(255,255,255,0.45)',
    lineHeight: 1.6,
  },
  successBanner: {
    marginTop: '20px',
    padding: '12px 20px',
    background: 'rgba(100,220,120,0.1)',
    border: '1px solid rgba(100,220,120,0.25)',
    borderRadius: '12px',
    color: '#64dc78',
    fontSize: '14px',
  },
  errorBanner: {
    marginTop: '20px',
    padding: '12px 20px',
    background: 'rgba(255,80,80,0.1)',
    border: '1px solid rgba(255,80,80,0.2)',
    borderRadius: '12px',
    color: '#ff6b6b',
    fontSize: '14px',
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(230px, 1fr))',
    gap: '16px',
    maxWidth: '1100px',
    margin: '0 auto',
  },
  card: {
    background: 'rgba(255,255,255,0.03)',
    border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: '20px',
    padding: '32px 28px',
    position: 'relative',
    display: 'flex',
    flexDirection: 'column',
  },
  cardFeatured: {
    background: 'rgba(200,241,53,0.05)',
    border: '1px solid rgba(200,241,53,0.3)',
  },
  badge: {
    position: 'absolute',
    top: '-14px',
    left: '50%',
    transform: 'translateX(-50%)',
    background: '#c8f135',
    color: '#0a0a0a',
    fontSize: '11px',
    fontWeight: 600,
    padding: '4px 16px',
    borderRadius: '100px',
    whiteSpace: 'nowrap',
  },
  tier: {
    fontSize: '12px',
    textTransform: 'uppercase',
    letterSpacing: '0.1em',
    color: 'rgba(255,255,255,0.4)',
    marginBottom: '12px',
  },
  price: {
    fontFamily: 'Georgia, serif',
    fontSize: '44px',
    letterSpacing: '-1px',
    lineHeight: 1,
    marginBottom: '16px',
  },
  pricePer: {
    fontFamily: 'system-ui, sans-serif',
    fontSize: '16px',
    color: 'rgba(255,255,255,0.35)',
    letterSpacing: 0,
    marginLeft: '4px',
  },
  divider: {
    height: '1px',
    background: 'rgba(255,255,255,0.08)',
    margin: '0 0 20px',
  },
  features: {
    listStyle: 'none',
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    marginBottom: '28px',
    flex: 1,
    padding: 0,
  },
  feature: {
    fontSize: '13px',
    color: 'rgba(255,255,255,0.55)',
    lineHeight: 1.4,
    display: 'flex',
    alignItems: 'flex-start',
  },
  btn: {
    width: '100%',
    padding: '13px',
    borderRadius: '100px',
    fontSize: '14px',
    fontWeight: 500,
    cursor: 'pointer',
    border: '1px solid rgba(255,255,255,0.12)',
    background: 'transparent',
    color: 'rgba(255,255,255,0.7)',
    fontFamily: 'inherit',
    transition: 'all 0.2s',
  },
  btnFeatured: {
    background: '#c8f135',
    color: '#0a0a0a',
    border: 'none',
    fontWeight: 600,
  },
  btnCurrent: {
    background: 'rgba(100,220,120,0.08)',
    color: '#64dc78',
    border: '1px solid rgba(100,220,120,0.2)',
    cursor: 'default',
  },
  guarantee: {
    textAlign: 'center',
    marginTop: '40px',
    fontSize: '13px',
    color: 'rgba(255,255,255,0.3)',
  },
}
