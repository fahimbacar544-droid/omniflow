import { useEffect } from 'react'
import { useRequireAuth, useUser } from '../../lib/auth-context'
import { useRouter } from 'next/router'
import Head from 'next/head'

const PLAN_COLORS: Record<string, string> = {
  FREE: '#888',
  STARTER: '#60a5fa',
  PRO: '#a78bfa',
  BUSINESS: '#c8f135',
  ENTERPRISE: '#f59e0b',
}

const PLAN_LIMITS: Record<string, { shops: number | string; orders: number | string }> = {
  FREE:       { shops: 0,           orders: 0 },
  STARTER:    { shops: 1,           orders: '300/mois' },
  PRO:        { shops: 3,           orders: '2 000/mois' },
  BUSINESS:   { shops: 'Illimité',  orders: 'Illimité' },
  ENTERPRISE: { shops: 'Illimité',  orders: 'Illimité' },
}

export default function DashboardPage() {
  const { user, loading } = useRequireAuth()
  const { logout, refreshUser } = useUser()
  const router = useRouter()

  // Rafraîchir le plan après retour Stripe
  useEffect(() => {
    if (router.query.success) {
      refreshUser()
    }
  }, [router.query.success])

  if (loading || !user) {
    return (
      <div style={{ ...styles.page, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <p style={{ color: 'rgba(255,255,255,0.4)' }}>Chargement...</p>
      </div>
    )
  }

  const isPaid = user.plan !== 'FREE'
  const limits = PLAN_LIMITS[user.plan]
  const planColor = PLAN_COLORS[user.plan]

  return (
    <>
      <Head><title>Dashboard — OmniFlow</title></Head>
      <div style={styles.page}>
        {/* Nav */}
        <nav style={styles.nav}>
          <div style={styles.logo}>Omni<span style={{ color: '#c8f135' }}>Flow</span></div>
          <div style={styles.navRight}>
            <span style={{ ...styles.planBadge, background: `${planColor}18`, color: planColor, border: `1px solid ${planColor}30` }}>
              {user.plan}
            </span>
            <span style={styles.email}>{user.email}</span>
            <button onClick={logout} style={styles.btnLogout}>Déconnexion</button>
          </div>
        </nav>

        <div style={styles.content}>
          {/* Success banner */}
          {router.query.success && (
            <div style={styles.successBanner}>
              🎉 Bienvenue ! Votre plan <strong>{user.plan}</strong> est activé. Profitez d'OmniFlow !
            </div>
          )}

          {/* FREE → incite à s'abonner */}
          {!isPaid && (
            <div style={styles.upgradeBanner}>
              <div>
                <strong style={{ fontSize: '15px' }}>Vous êtes sur le plan gratuit</strong>
                <p style={{ margin: '4px 0 0', color: 'rgba(255,255,255,0.5)', fontSize: '14px' }}>
                  Choisissez un plan pour connecter vos boutiques et automatiser votre e-commerce.
                </p>
              </div>
              <button onClick={() => router.push('/pricing')} style={styles.btnUpgrade}>
                Choisir un plan →
              </button>
            </div>
          )}

          {/* Plan info */}
          <div style={styles.planCard}>
            <div style={styles.planCardHeader}>
              <div>
                <div style={styles.planName} >{user.plan}</div>
                <div style={styles.planSub}>Votre abonnement actuel</div>
              </div>
              {isPaid && (
                <button
                  onClick={async () => {
                    const res = await fetch('/api/stripe/portal', { method: 'POST' })
                    const data = await res.json()
                    if (data.url) window.location.href = data.url
                  }}
                  style={styles.btnManage}
                >
                  Gérer l'abonnement
                </button>
              )}
            </div>
            <div style={styles.limitsGrid}>
              <div style={styles.limitItem}>
                <div style={styles.limitVal}>{limits.shops}</div>
                <div style={styles.limitLabel}>Boutiques connectées</div>
              </div>
              <div style={styles.limitItem}>
                <div style={styles.limitVal}>{limits.orders}</div>
                <div style={styles.limitLabel}>Commandes</div>
              </div>
              {user.currentPeriodEnd && (
                <div style={styles.limitItem}>
                  <div style={styles.limitVal}>
                    {new Date(user.currentPeriodEnd).toLocaleDateString('fr-FR')}
                  </div>
                  <div style={styles.limitLabel}>Renouvellement</div>
                </div>
              )}
            </div>
          </div>

          {/* Modules (bloqués si FREE) */}
          <h2 style={styles.sectionTitle}>Modules disponibles</h2>
          <div style={styles.modulesGrid}>
            {modules.map(mod => {
              const locked = !isPaid && mod.minPlan !== 'FREE'
              return (
                <div
                  key={mod.id}
                  style={{ ...styles.moduleCard, ...(locked ? styles.moduleCardLocked : {}) }}
                  onClick={() => !locked && router.push(mod.href)}
                >
                  <div style={styles.moduleIcon}>{mod.icon}</div>
                  <div style={styles.moduleTitle}>{mod.title}</div>
                  <div style={styles.moduleDesc}>{mod.desc}</div>
                  {locked && (
                    <div style={styles.lockBadge}>
                      🔒 Plan {mod.minPlan}+
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </>
  )
}

const modules = [
  { id: 'stocks',      icon: '📦', title: 'Gestion des stocks',    desc: 'Multi-entrepôts, sync temps réel', href: '/dashboard/stocks',      minPlan: 'STARTER' },
  { id: 'orders',      icon: '🛒', title: 'Commandes',             desc: 'Toutes vos plateformes réunies',  href: '/dashboard/orders',      minPlan: 'STARTER' },
  { id: 'tracking',    icon: '🚚', title: 'Tracking colis',        desc: 'Page personnalisée + alertes',    href: '/dashboard/tracking',    minPlan: 'STARTER' },
  { id: 'suppliers',   icon: '🤝', title: 'Fournisseurs',          desc: 'AliExpress, CJ, Zendrop...',     href: '/dashboard/suppliers',   minPlan: 'PRO' },
  { id: 'automation',  icon: '⚡', title: 'Automatisation',        desc: 'Règles intelligentes sans code',  href: '/dashboard/automation',  minPlan: 'PRO' },
  { id: 'ai',          icon: '🤖', title: 'Prévisions IA',         desc: 'Ruptures, best-sellers, saisonnalité', href: '/dashboard/ai', minPlan: 'BUSINESS' },
  { id: 'analytics',   icon: '📊', title: 'Analytics',             desc: 'Rapports et performances',       href: '/dashboard/analytics',   minPlan: 'PRO' },
  { id: 'settings',    icon: '⚙️', title: 'Paramètres',            desc: 'Compte, API, intégrations',      href: '/dashboard/settings',    minPlan: 'FREE' },
]

const styles: Record<string, React.CSSProperties> = {
  page: { minHeight: '100vh', background: '#0a0a0a', fontFamily: 'system-ui, sans-serif', color: '#fafaf8' },
  nav: {
    position: 'sticky', top: 0, zIndex: 50,
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    padding: '16px 32px',
    background: 'rgba(10,10,10,0.85)', backdropFilter: 'blur(16px)',
    borderBottom: '1px solid rgba(255,255,255,0.07)',
  },
  logo: { fontFamily: 'Georgia, serif', fontSize: '20px' },
  navRight: { display: 'flex', alignItems: 'center', gap: '14px' },
  planBadge: { fontSize: '11px', padding: '4px 12px', borderRadius: '100px', fontWeight: 600 },
  email: { fontSize: '13px', color: 'rgba(255,255,255,0.4)' },
  btnLogout: {
    padding: '7px 16px', borderRadius: '100px', background: 'transparent',
    border: '1px solid rgba(255,255,255,0.12)', color: 'rgba(255,255,255,0.5)',
    cursor: 'pointer', fontSize: '13px', fontFamily: 'inherit',
  },
  content: { maxWidth: '1100px', margin: '0 auto', padding: '40px 24px' },
  successBanner: {
    padding: '16px 20px', background: 'rgba(200,241,53,0.07)',
    border: '1px solid rgba(200,241,53,0.2)', borderRadius: '14px',
    color: '#c8f135', fontSize: '15px', marginBottom: '24px',
  },
  upgradeBanner: {
    padding: '20px 24px', background: 'rgba(255,255,255,0.03)',
    border: '1px solid rgba(255,255,255,0.1)', borderRadius: '14px',
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    gap: '20px', marginBottom: '24px', flexWrap: 'wrap',
  },
  btnUpgrade: {
    padding: '11px 24px', borderRadius: '100px', background: '#c8f135',
    color: '#0a0a0a', border: 'none', fontWeight: 600, cursor: 'pointer',
    fontSize: '14px', fontFamily: 'inherit', whiteSpace: 'nowrap',
  },
  planCard: {
    background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: '16px', padding: '24px 28px', marginBottom: '40px',
  },
  planCardHeader: { display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '20px', flexWrap: 'wrap', gap: '12px' },
  planName: { fontFamily: 'Georgia, serif', fontSize: '24px', letterSpacing: '-0.5px' },
  planSub: { fontSize: '13px', color: 'rgba(255,255,255,0.35)', marginTop: '4px' },
  btnManage: {
    padding: '9px 20px', borderRadius: '100px',
    border: '1px solid rgba(255,255,255,0.12)', background: 'transparent',
    color: 'rgba(255,255,255,0.6)', cursor: 'pointer', fontSize: '13px', fontFamily: 'inherit',
  },
  limitsGrid: { display: 'flex', gap: '32px', flexWrap: 'wrap' },
  limitItem: {},
  limitVal: { fontSize: '22px', fontWeight: 500 },
  limitLabel: { fontSize: '12px', color: 'rgba(255,255,255,0.35)', marginTop: '3px' },
  sectionTitle: { fontSize: '18px', fontWeight: 500, marginBottom: '20px' },
  modulesGrid: {
    display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '12px',
  },
  moduleCard: {
    background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: '14px', padding: '22px 20px', cursor: 'pointer',
    transition: 'all 0.2s', position: 'relative',
  },
  moduleCardLocked: {
    opacity: 0.45, cursor: 'default',
  },
  moduleIcon: { fontSize: '24px', marginBottom: '12px' },
  moduleTitle: { fontSize: '14px', fontWeight: 500, marginBottom: '6px' },
  moduleDesc: { fontSize: '12px', color: 'rgba(255,255,255,0.4)', lineHeight: 1.5 },
  lockBadge: {
    marginTop: '12px', fontSize: '11px', color: 'rgba(255,255,255,0.4)',
    background: 'rgba(255,255,255,0.05)', padding: '4px 10px',
    borderRadius: '100px', display: 'inline-block',
  },
}
