import { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { verifyPassword, createToken, setAuthCookie } from '../../../lib/auth'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()

  const { email, password } = req.body

  if (!email || !password) {
    return res.status(400).json({ error: 'Email et mot de passe requis' })
  }

  const user = await prisma.user.findUnique({
    where: { email },
    include: { subscription: true },
  })

  if (!user) {
    return res.status(401).json({ error: 'Email ou mot de passe incorrect' })
  }

  const valid = await verifyPassword(password, user.password)
  if (!valid) {
    return res.status(401).json({ error: 'Email ou mot de passe incorrect' })
  }

  const token = createToken({ userId: user.id, email: user.email })
  setAuthCookie(res, token)

  return res.status(200).json({
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      plan: user.subscription?.plan || 'FREE',
      subscriptionStatus: user.subscription?.status || 'ACTIVE',
    },
  })
}
