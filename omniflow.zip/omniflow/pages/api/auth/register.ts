import { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { hashPassword, createToken, setAuthCookie } from '../../../lib/auth'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()

  const { email, password, name } = req.body

  if (!email || !password) {
    return res.status(400).json({ error: 'Email et mot de passe requis' })
  }

  if (password.length < 8) {
    return res.status(400).json({ error: 'Mot de passe trop court (min 8 caractères)' })
  }

  // Vérifier si l'email existe déjà
  const existing = await prisma.user.findUnique({ where: { email } })
  if (existing) {
    return res.status(409).json({ error: 'Cet email est déjà utilisé' })
  }

  // Créer l'utilisateur + subscription FREE par défaut
  const hashed = await hashPassword(password)

  const user = await prisma.user.create({
    data: {
      email,
      password: hashed,
      name: name || null,
      subscription: {
        create: {
          plan: 'FREE',
          status: 'ACTIVE',
        },
      },
    },
    include: { subscription: true },
  })

  const token = createToken({ userId: user.id, email: user.email })
  setAuthCookie(res, token)

  return res.status(201).json({
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      plan: user.subscription?.plan || 'FREE',
    },
  })
}
