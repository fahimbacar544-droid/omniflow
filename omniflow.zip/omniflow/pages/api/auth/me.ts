import { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { requireAuth } from '../../../lib/auth'

export default requireAuth(async (req, res, authUser) => {
  if (req.method !== 'GET') return res.status(405).end()

  const user = await prisma.user.findUnique({
    where: { id: authUser.userId },
    include: { subscription: true },
  })

  if (!user) return res.status(404).json({ error: 'Utilisateur introuvable' })

  return res.status(200).json({
    id: user.id,
    email: user.email,
    name: user.name,
    plan: user.subscription?.plan || 'FREE',
    subscriptionStatus: user.subscription?.status || 'ACTIVE',
    currentPeriodEnd: user.subscription?.currentPeriodEnd || null,
    stripeCustomerId: user.subscription?.stripeCustomerId || null,
  })
})
