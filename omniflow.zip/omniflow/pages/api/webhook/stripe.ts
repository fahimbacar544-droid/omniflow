import { NextApiRequest, NextApiResponse } from 'next'
import { buffer } from 'micro'
import Stripe from 'stripe'
import { stripe, STRIPE_PRICE_TO_PLAN } from '../../../lib/stripe'
import { prisma } from '../../../lib/prisma'

// Désactiver le body parser Next.js pour lire le raw body Stripe
export const config = { api: { bodyParser: false } }

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()

  const rawBody = await buffer(req)
  const sig = req.headers['stripe-signature'] as string

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(
      rawBody,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET!
    )
  } catch (err: any) {
    console.error('Webhook signature invalide:', err.message)
    return res.status(400).json({ error: `Webhook error: ${err.message}` })
  }

  // ─── ÉVÉNEMENTS STRIPE ───────────────────────────────────────────

  switch (event.type) {

    // ✅ Paiement réussi → activation immédiate du plan
    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.Checkout.Session
      const userId = session.metadata?.userId
      const planId = session.metadata?.planId

      if (!userId || !planId) break

      const subscriptionId = session.subscription as string
      const subscription = await stripe.subscriptions.retrieve(subscriptionId)
      const priceId = subscription.items.data[0]?.price.id
      const plan = STRIPE_PRICE_TO_PLAN[priceId] || planId

      await prisma.subscription.upsert({
        where: { userId },
        update: {
          plan: plan as any,
          status: 'ACTIVE',
          stripeSubscriptionId: subscriptionId,
          currentPeriodEnd: new Date(subscription.current_period_end * 1000),
        },
        create: {
          userId,
          plan: plan as any,
          status: 'ACTIVE',
          stripeCustomerId: session.customer as string,
          stripeSubscriptionId: subscriptionId,
          currentPeriodEnd: new Date(subscription.current_period_end * 1000),
        },
      })

      console.log(`✅ Plan ${plan} activé pour userId=${userId}`)
      break
    }

    // 🔄 Renouvellement mensuel réussi
    case 'invoice.payment_succeeded': {
      const invoice = event.data.object as Stripe.Invoice
      const subscriptionId = invoice.subscription as string

      if (!subscriptionId) break

      const subscription = await stripe.subscriptions.retrieve(subscriptionId)
      const userId = subscription.metadata?.userId
      if (!userId) break

      await prisma.subscription.update({
        where: { userId },
        data: {
          status: 'ACTIVE',
          currentPeriodEnd: new Date(subscription.current_period_end * 1000),
        },
      })

      console.log(`🔄 Renouvellement OK pour userId=${userId}`)
      break
    }

    // ❌ Paiement échoué
    case 'invoice.payment_failed': {
      const invoice = event.data.object as Stripe.Invoice
      const subscriptionId = invoice.subscription as string
      if (!subscriptionId) break

      const subscription = await stripe.subscriptions.retrieve(subscriptionId)
      const userId = subscription.metadata?.userId
      if (!userId) break

      await prisma.subscription.update({
        where: { userId },
        data: { status: 'PAST_DUE' },
      })

      console.log(`❌ Paiement échoué pour userId=${userId}`)
      break
    }

    // 🚫 Abonnement annulé
    case 'customer.subscription.deleted': {
      const subscription = event.data.object as Stripe.Subscription
      const userId = subscription.metadata?.userId
      if (!userId) break

      await prisma.subscription.update({
        where: { userId },
        data: {
          plan: 'FREE',
          status: 'CANCELLED',
          stripeSubscriptionId: null,
          currentPeriodEnd: null,
        },
      })

      console.log(`🚫 Abonnement annulé pour userId=${userId}`)
      break
    }

    // 🔄 Upgrade/downgrade de plan
    case 'customer.subscription.updated': {
      const subscription = event.data.object as Stripe.Subscription
      const userId = subscription.metadata?.userId
      if (!userId) break

      const priceId = subscription.items.data[0]?.price.id
      const plan = STRIPE_PRICE_TO_PLAN[priceId]
      if (!plan) break

      await prisma.subscription.update({
        where: { userId },
        data: {
          plan: plan as any,
          status: subscription.status === 'active' ? 'ACTIVE' : 'PAST_DUE',
          currentPeriodEnd: new Date(subscription.current_period_end * 1000),
        },
      })

      console.log(`🔄 Plan mis à jour → ${plan} pour userId=${userId}`)
      break
    }
  }

  return res.status(200).json({ received: true })
}
