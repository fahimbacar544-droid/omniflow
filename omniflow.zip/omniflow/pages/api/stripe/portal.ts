import { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { stripe } from '../../../lib/stripe'
import { requireAuth } from '../../../lib/auth'

export default requireAuth(async (req, res, authUser) => {
  if (req.method !== 'POST') return res.status(405).end()

  const user = await prisma.user.findUnique({
    where: { id: authUser.userId },
    include: { subscription: true },
  })

  if (!user?.subscription?.stripeCustomerId) {
    return res.status(400).json({ error: 'Aucun abonnement actif' })
  }

  // Portail Stripe : le client peut gérer sa carte, annuler, etc.
  const session = await stripe.billingPortal.sessions.create({
    customer: user.subscription.stripeCustomerId,
    return_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/settings`,
  })

  return res.status(200).json({ url: session.url })
})
