import { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { stripe, PLANS } from '../../../lib/stripe'
import { requireAuth } from '../../../lib/auth'

export default requireAuth(async (req, res, authUser) => {
  if (req.method !== 'POST') return res.status(405).end()

  const { planId } = req.body

  // Valider le plan
  const plan = PLANS.find(p => p.id === planId)
  if (!plan) {
    return res.status(400).json({ error: 'Plan invalide' })
  }

  // Récupérer ou créer le customer Stripe
  const user = await prisma.user.findUnique({
    where: { id: authUser.userId },
    include: { subscription: true },
  })

  if (!user) return res.status(404).json({ error: 'Utilisateur introuvable' })

  let customerId = user.subscription?.stripeCustomerId

  if (!customerId) {
    const customer = await stripe.customers.create({
      email: user.email,
      name: user.name || undefined,
      metadata: { userId: user.id },
    })
    customerId = customer.id

    // Sauvegarder le customer ID
    await prisma.subscription.upsert({
      where: { userId: user.id },
      update: { stripeCustomerId: customerId },
      create: {
        userId: user.id,
        plan: 'FREE',
        status: 'ACTIVE',
        stripeCustomerId: customerId,
      },
    })
  }

  const appUrl = process.env.NEXT_PUBLIC_APP_URL

  // Créer la session Stripe Checkout
  const session = await stripe.checkout.sessions.create({
    customer: customerId,
    payment_method_types: ['card'],
    line_items: [
      {
        price: plan.priceId,
        quantity: 1,
      },
    ],
    mode: 'subscription',
    success_url: `${appUrl}/dashboard?success=true&plan=${planId}`,
    cancel_url: `${appUrl}/pricing?cancelled=true`,
    metadata: {
      userId: user.id,
      planId: plan.id,
    },
    subscription_data: {
      metadata: {
        userId: user.id,
        planId: plan.id,
      },
    },
    // Essai gratuit 14 jours
    // subscription_data: { trial_period_days: 14 },
  })

  return res.status(200).json({ url: session.url })
})
