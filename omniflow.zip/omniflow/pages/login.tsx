import { useState } from 'react'
import { useUser } from '../lib/auth-context'
import Link from 'next/link'
import Head from 'next/head'

export default function LoginPage() {
  const { login } = useUser()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      await login(email, password)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <Head><title>Connexion — OmniFlow</title></Head>
      <div style={styles.page}>
        <div style={styles.card}>
          <div style={styles.logo}>Omni<span style={{ color: '#c8f135' }}>Flow</span></div>
          <h1 style={styles.title}>Bon retour 👋</h1>
          <p style={styles.sub}>Connectez-vous à votre espace</p>

          {error && <div style={styles.error}>{error}</div>}

          <form onSubmit={handleSubmit} style={styles.form}>
            <div style={styles.field}>
              <label style={styles.label}>Email</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="vous@exemple.com"
                required
                style={styles.input}
              />
            </div>
            <div style={styles.field}>
              <label style={styles.label}>Mot de passe</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                style={styles.input}
              />
            </div>
            <button type="submit" disabled={loading} style={styles.btn}>
              {loading ? 'Connexion...' : 'Se connecter'}
            </button>
          </form>

          <p style={styles.footer}>
            Pas encore de compte ?{' '}
            <Link href="/register" style={{ color: '#c8f135', textDecoration: 'none' }}>
              Créer un compte
            </Link>
          </p>
        </div>
      </div>
    </>
  )
}

const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: '100vh',
    background: '#0a0a0a',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontFamily: 'system-ui, sans-serif',
    padding: '24px',
  },
  card: {
    background: 'rgba(255,255,255,0.04)',
    border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: '20px',
    padding: '40px',
    width: '100%',
    maxWidth: '420px',
  },
  logo: {
    fontFamily: 'Georgia, serif',
    fontSize: '22px',
    color: '#fafaf8',
    marginBottom: '28px',
    fontWeight: 400,
  },
  title: {
    fontSize: '26px',
    fontWeight: 500,
    color: '#fafaf8',
    marginBottom: '8px',
  },
  sub: {
    fontSize: '15px',
    color: 'rgba(255,255,255,0.4)',
    marginBottom: '32px',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '18px',
  },
  field: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px',
  },
  label: {
    fontSize: '13px',
    color: 'rgba(255,255,255,0.55)',
    fontWeight: 500,
  },
  input: {
    padding: '11px 14px',
    borderRadius: '10px',
    border: '1px solid rgba(255,255,255,0.1)',
    background: 'rgba(255,255,255,0.05)',
    color: '#fafaf8',
    fontSize: '15px',
    outline: 'none',
    fontFamily: 'inherit',
  },
  btn: {
    padding: '13px',
    borderRadius: '100px',
    background: '#c8f135',
    color: '#0a0a0a',
    fontSize: '15px',
    fontWeight: 600,
    border: 'none',
    cursor: 'pointer',
    marginTop: '4px',
    fontFamily: 'inherit',
    transition: 'background 0.2s',
  },
  error: {
    padding: '12px 16px',
    background: 'rgba(255,80,80,0.1)',
    border: '1px solid rgba(255,80,80,0.2)',
    borderRadius: '10px',
    color: '#ff6b6b',
    fontSize: '14px',
    marginBottom: '20px',
  },
  footer: {
    marginTop: '24px',
    fontSize: '14px',
    color: 'rgba(255,255,255,0.4)',
    textAlign: 'center',
  },
}
