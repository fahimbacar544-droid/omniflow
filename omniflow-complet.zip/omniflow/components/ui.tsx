import React from 'react'

// ── Metric Card ──────────────────────────────────────────────
export function MetricCard({ label, value, delta, deltaUp, color }: {
  label: string; value: string | number; delta?: string; deltaUp?: boolean; color?: string
}) {
  return (
    <div style={mc.card}>
      <div style={mc.label}>{label}</div>
      <div style={{ ...mc.value, ...(color ? { color } : {}) }}>{value}</div>
      {delta && (
        <div style={{ ...mc.delta, color: deltaUp ? '#64dc78' : '#ff6b6b' }}>{delta}</div>
      )}
    </div>
  )
}
const mc: Record<string, React.CSSProperties> = {
  card: { background: 'rgba(255,255,255,0.04)', borderRadius: 12, padding: '16px 18px' },
  label: { fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'rgba(255,255,255,0.35)', fontWeight: 500 },
  value: { fontSize: 26, fontWeight: 500, color: '#fafaf8', marginTop: 6 },
  delta: { fontSize: 12, marginTop: 4 },
}

// ── Card wrapper ──────────────────────────────────────────────
export function Card({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 14, padding: '20px 22px', ...style }}>
      {children}
    </div>
  )
}

// ── Card title ────────────────────────────────────────────────
export function CardTitle({ children, action, onAction }: { children: React.ReactNode; action?: string; onAction?: () => void }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
      <div style={{ fontSize: 14, fontWeight: 500 }}>{children}</div>
      {action && <button onClick={onAction} style={{ fontSize: 12, color: '#c8f135', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'inherit' }}>{action}</button>}
    </div>
  )
}

// ── Status Badge ──────────────────────────────────────────────
export function Badge({ label, type }: { label: string; type: 'success' | 'warning' | 'danger' | 'info' | 'neutral' }) {
  const colors = {
    success: { bg: 'rgba(100,220,120,0.12)', color: '#64dc78' },
    warning: { bg: 'rgba(255,180,50,0.12)', color: '#ffb432' },
    danger:  { bg: 'rgba(255,80,80,0.12)',  color: '#ff5050' },
    info:    { bg: 'rgba(96,165,250,0.12)', color: '#60a5fa' },
    neutral: { bg: 'rgba(255,255,255,0.07)', color: 'rgba(255,255,255,0.5)' },
  }
  const c = colors[type]
  return (
    <span style={{ fontSize: 11, padding: '3px 9px', borderRadius: 100, background: c.bg, color: c.color, fontWeight: 500, whiteSpace: 'nowrap' }}>
      {label}
    </span>
  )
}

// ── Table ─────────────────────────────────────────────────────
export function Table({ headers, rows }: { headers: string[]; rows: React.ReactNode[][] }) {
  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
        <thead>
          <tr>
            {headers.map(h => (
              <th key={h} style={{ textAlign: 'left', padding: '8px 12px', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'rgba(255,255,255,0.3)', fontWeight: 500, borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
              {row.map((cell, j) => (
                <td key={j} style={{ padding: '10px 12px', color: 'rgba(255,255,255,0.7)', verticalAlign: 'middle' }}>
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

// ── Button ────────────────────────────────────────────────────
export function Btn({ children, onClick, variant = 'ghost', small }: {
  children: React.ReactNode; onClick?: () => void
  variant?: 'primary' | 'ghost' | 'danger'; small?: boolean
}) {
  const base: React.CSSProperties = {
    padding: small ? '6px 14px' : '10px 20px',
    borderRadius: 100, cursor: 'pointer', fontSize: small ? 12 : 14,
    fontWeight: 500, fontFamily: 'inherit', border: 'none', transition: 'all 0.2s',
  }
  const variants = {
    primary: { background: '#c8f135', color: '#0a0a0a', border: 'none' },
    ghost:   { background: 'transparent', color: 'rgba(255,255,255,0.6)', border: '1px solid rgba(255,255,255,0.12)' },
    danger:  { background: 'rgba(255,80,80,0.1)', color: '#ff5050', border: '1px solid rgba(255,80,80,0.2)' },
  }
  return <button onClick={onClick} style={{ ...base, ...variants[variant] }}>{children}</button>
}

// ── Input ─────────────────────────────────────────────────────
export function Input({ value, onChange, placeholder, type = 'text' }: {
  value: string; onChange: (v: string) => void; placeholder?: string; type?: string
}) {
  return (
    <input
      type={type}
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      style={{
        padding: '9px 14px', borderRadius: 10,
        border: '1px solid rgba(255,255,255,0.1)',
        background: 'rgba(255,255,255,0.05)',
        color: '#fafaf8', fontSize: 14,
        outline: 'none', fontFamily: 'inherit', width: '100%',
      }}
    />
  )
}

// ── Section header ────────────────────────────────────────────
export function SectionHeader({ children }: { children: React.ReactNode }) {
  return <h2 style={{ fontSize: 16, fontWeight: 500, marginBottom: 16, color: '#fafaf8' }}>{children}</h2>
}

// ── Grid ──────────────────────────────────────────────────────
export function Grid({ cols = 4, gap = 12, children }: { cols?: number; gap?: number; children: React.ReactNode }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: `repeat(${cols}, minmax(0,1fr))`, gap }}>
      {children}
    </div>
  )
}

// ── Empty state ───────────────────────────────────────────────
export function Empty({ icon, text }: { icon: string; text: string }) {
  return (
    <div style={{ textAlign: 'center', padding: '48px 24px', color: 'rgba(255,255,255,0.25)' }}>
      <div style={{ fontSize: 32, marginBottom: 12 }}>{icon}</div>
      <div style={{ fontSize: 14 }}>{text}</div>
    </div>
  )
}
