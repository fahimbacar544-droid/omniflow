import { useUser } from '../lib/auth-context'
import { useRouter } from 'next/router'
import Link from 'next/link'
import React from 'react'

const NAV = [
  { section: 'Principal' },
  { href: '/dashboard',            icon: '▣',  label: 'Tableau de bord' },
  { href: '/dashboard/orders',     icon: '🛒', label: 'Commandes' },
  { href: '/dashboard/stocks',     icon: '📦', label: 'Stocks' },
  { href: '/dashboard/suppliers',  icon: '🤝', label: 'Fournisseurs' },
  { section: 'Logistique' },
  { href: '/dashboard/tracking',   icon: '🚚', label: 'Tracking' },
  { href: '/dashboard/automation', icon: '⚡', label: 'Automatisation' },
  { section: 'Intelligence' },
  { href: '/dashboard/ai',         icon: '🤖', label: 'Prévisions IA' },
  { href: '/dashboard/analytics',  icon: '📊', label: 'Analytics' },
  { section: 'Compte' },
  { href: '/dashboard/settings',   icon: '⚙️', label: 'Paramètres' },
]

const PLAN_COLORS: Record<string, string> = {
  FREE: '#888', STARTER: '#60a5fa', PRO: '#a78bfa',
  BUSINESS: '#c8f135', ENTERPRISE: '#f59e0b',
}

export default function DashboardLayout({ children, title }: { children: React.ReactNode; title?: string }) {
  const { user, logout } = useUser()
  const router = useRouter()

  return (
    <div style={s.app}>
      {/* Sidebar */}
      <aside style={s.sidebar}>
        <div style={s.sidebarTop}>
          <Link href="/dashboard" style={s.logo}>
            Omni<span style={{ color: '#c8f135' }}>Flow</span>
          </Link>
          {user && (
            <div style={s.planPill}>
              <span style={{ ...s.planDot, background: PLAN_COLORS[user.plan] || '#888' }} />
              {user.plan}
            </div>
          )}
        </div>

        <nav style={s.nav}>
          {NAV.map((item, i) => {
            if ('section' in item) {
              return <div key={i} style={s.navSection}>{item.section}</div>
            }
            const active = router.pathname === item.href
            return (
              <Link key={item.href} href={item.href} style={{ ...s.navItem, ...(active ? s.navItemActive : {}) }}>
                <span style={s.navIcon}>{item.icon}</span>
                {item.label}
              </Link>
            )
          })}
        </nav>

        <div style={s.sidebarBottom}>
          {user && (
            <>
              <div style={s.userEmail}>{user.email}</div>
              <button onClick={logout} style={s.btnLogout}>Déconnexion</button>
            </>
          )}
        </div>
      </aside>

      {/* Main */}
      <main style={s.main}>
        {title && (
          <div style={s.topbar}>
            <h1 style={s.topbarTitle}>{title}</h1>
          </div>
        )}
        <div style={s.content}>{children}</div>
      </main>
    </div>
  )
}

const s: Record<string, React.CSSProperties> = {
  app: { display: 'flex', minHeight: '100vh', background: '#0a0a0a', fontFamily: 'system-ui,sans-serif', color: '#fafaf8' },
  sidebar: {
    width: 220, flexShrink: 0, background: 'rgba(255,255,255,0.025)',
    borderRight: '1px solid rgba(255,255,255,0.07)',
    display: 'flex', flexDirection: 'column', position: 'sticky', top: 0, height: '100vh', overflow: 'hidden',
  },
  sidebarTop: { padding: '20px 16px 12px', borderBottom: '1px solid rgba(255,255,255,0.06)' },
  logo: { fontFamily: 'Georgia,serif', fontSize: 20, color: '#fafaf8', textDecoration: 'none', display: 'block', marginBottom: 10 },
  planPill: { display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11, color: 'rgba(255,255,255,0.4)', background: 'rgba(255,255,255,0.05)', padding: '3px 10px', borderRadius: 100 },
  planDot: { width: 6, height: 6, borderRadius: '50%', display: 'inline-block' },
  nav: { flex: 1, overflowY: 'auto', padding: '8px 0' },
  navSection: { padding: '14px 16px 4px', fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'rgba(255,255,255,0.25)', fontWeight: 500 },
  navItem: { display: 'flex', alignItems: 'center', gap: 9, padding: '8px 16px', fontSize: 13, color: 'rgba(255,255,255,0.5)', textDecoration: 'none', borderLeft: '2px solid transparent', transition: 'all 0.15s' },
  navItemActive: { color: '#c8f135', background: 'rgba(200,241,53,0.06)', borderLeftColor: '#c8f135' },
  navIcon: { fontSize: 14, width: 18, textAlign: 'center' },
  sidebarBottom: { padding: '16px', borderTop: '1px solid rgba(255,255,255,0.06)' },
  userEmail: { fontSize: 12, color: 'rgba(255,255,255,0.3)', marginBottom: 10, wordBreak: 'break-all' },
  btnLogout: { width: '100%', padding: '8px', borderRadius: 100, background: 'transparent', border: '1px solid rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.4)', cursor: 'pointer', fontSize: 12, fontFamily: 'inherit' },
  main: { flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, overflow: 'hidden' },
  topbar: { padding: '20px 32px', borderBottom: '1px solid rgba(255,255,255,0.06)', background: 'rgba(255,255,255,0.015)', flexShrink: 0 },
  topbarTitle: { fontSize: 20, fontWeight: 500, fontFamily: 'Georgia,serif', letterSpacing: '-0.5px' },
  content: { flex: 1, overflowY: 'auto', padding: '28px 32px' },
}
