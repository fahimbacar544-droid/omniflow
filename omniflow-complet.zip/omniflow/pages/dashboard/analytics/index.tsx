import { useEffect, useState } from 'react'
import DashboardLayout from '../../components/DashboardLayout'
import { Card, CardTitle, MetricCard, Grid, Empty } from '../../components/ui'
import { useRequireAuth } from '../../lib/auth-context'
import Head from 'next/head'

type Stats = {
  totalOrders: number; ordersThisMonth: number; orderDelta: number
  revenueThisMonth: number; revenueDelta: number
  pendingOrders: number; shippedOrders: number
  lowStockCount: number; totalProducts: number
  ordersByStatus: { status: string; _count: number }[]
  recentOrders: { id: string; total: number; status: string; createdAt: string; shop: { name: string; platform: string } }[]
}

const STATUS_LABELS: Record<string, string> = {
  PENDING: 'En attente', CONFIRMED: 'Confirmée', PROCESSING: 'En traitement',
  SHIPPED: 'Expédiée', DELIVERED: 'Livrée', CANCELLED: 'Annulée', REFUNDED: 'Remboursée',
}
const STATUS_COLORS: Record<string, string> = {
  PENDING: '#ffb432', CONFIRMED: '#60a5fa', PROCESSING: '#a78bfa',
  SHIPPED: '#64dc78', DELIVERED: '#c8f135', CANCELLED: '#ff5050', REFUNDED: '#888',
}

// Sparkline data simulée pour les 7 derniers jours
const WEEK = [12, 18, 14, 22, 19, 28, 24]
const MAX_W = Math.max(...WEEK)

export default function AnalyticsPage() {
  useRequireAuth()
  const [stats, setStats] = useState<Stats | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/analytics/stats')
      .then(r => r.json())
      .then(d => { setStats(d); setLoading(false) })
  }, [])

  if (loading) return (
    <DashboardLayout title="Analytics">
      <Empty icon="⏳" text="Chargement des données…" />
    </DashboardLayout>
  )

  if (!stats) return (
    <DashboardLayout title="Analytics">
      <Empty icon="📊" text="Impossible de charger les stats." />
    </DashboardLayout>
  )

  const totalByStatus = stats.ordersByStatus.reduce((s, o) => s + o._count, 0) || 1

  return (
    <>
      <Head><title>Analytics — OmniFlow</title></Head>
      <DashboardLayout title="Analytics">

        {/* KPIs */}
        <Grid cols={4} gap={12}>
          <MetricCard
            label="CA ce mois"
            value={`${stats.revenueThisMonth.toFixed(0)} €`}
            delta={`${stats.revenueDelta >= 0 ? '+' : ''}${stats.revenueDelta}% vs mois dernier`}
            deltaUp={stats.revenueDelta >= 0}
            color="#c8f135"
          />
          <MetricCard
            label="Commandes ce mois"
            value={stats.ordersThisMonth}
            delta={`${stats.orderDelta >= 0 ? '+' : ''}${stats.orderDelta}% vs mois dernier`}
            deltaUp={stats.orderDelta >= 0}
          />
          <MetricCard
            label="En attente"
            value={stats.pendingOrders}
            color={stats.pendingOrders > 0 ? '#ffb432' : undefined}
          />
          <MetricCard
            label="Stocks bas"
            value={stats.lowStockCount}
            color={stats.lowStockCount > 0 ? '#ff5050' : undefined}
          />
        </Grid>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 20 }}>

          {/* Commandes par statut */}
          <Card>
            <CardTitle>Répartition des commandes</CardTitle>
            {stats.ordersByStatus.length === 0
              ? <Empty icon="📊" text="Aucune donnée encore." />
              : stats.ordersByStatus.map(s => {
                const pct = Math.round((s._count / totalByStatus) * 100)
                const color = STATUS_COLORS[s.status] || '#888'
                return (
                  <div key={s.status} style={{ padding: '8px 0', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                      <span style={{ fontSize: 13, color: 'rgba(255,255,255,0.65)' }}>{STATUS_LABELS[s.status] || s.status}</span>
                      <span style={{ fontSize: 12, fontWeight: 500 }}>{s._count} ({pct}%)</span>
                    </div>
                    <div style={{ height: 5, background: 'rgba(255,255,255,0.07)', borderRadius: 3, overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: `${pct}%`, background: color, borderRadius: 3, transition: 'width 0.5s ease' }} />
                    </div>
                  </div>
                )
              })
            }
          </Card>

          {/* Volume 7 derniers jours */}
          <Card>
            <CardTitle>Volume · 7 derniers jours</CardTitle>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8, height: 100, marginBottom: 10 }}>
              {WEEK.map((v, i) => {
                const days = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim']
                return (
                  <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                    <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.3)' }}>{v}</div>
                    <div style={{
                      width: '100%', borderRadius: '4px 4px 0 0',
                      height: `${(v / MAX_W) * 80}%`, minHeight: 6,
                      background: i === 6 ? '#c8f135' : 'rgba(200,241,53,0.25)',
                    }} />
                    <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.3)' }}>{days[i]}</div>
                  </div>
                )
              })}
            </div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.35)', paddingTop: 8, borderTop: '1px solid rgba(255,255,255,0.05)' }}>
              Total 7j : <strong style={{ color: '#fafaf8' }}>{WEEK.reduce((a, v) => a + v, 0)} commandes</strong>
            </div>
          </Card>

          {/* Commandes récentes */}
          <Card style={{ gridColumn: '1 / -1' }}>
            <CardTitle>Commandes récentes</CardTitle>
            {stats.recentOrders.length === 0
              ? <Empty icon="🛒" text="Aucune commande récente." />
              : stats.recentOrders.map(o => (
                <div key={o.id} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '10px 0', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                  <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.35)', width: 100, flexShrink: 0 }}>
                    {new Date(o.createdAt).toLocaleDateString('fr-FR')}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13 }}>{o.shop.name}</div>
                    <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.35)' }}>{o.shop.platform}</div>
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 500 }}>{o.total.toFixed(2)} €</div>
                  <div style={{
                    fontSize: 11, padding: '3px 9px', borderRadius: 100,
                    background: `${STATUS_COLORS[o.status]}18`,
                    color: STATUS_COLORS[o.status] || '#888',
                  }}>
                    {STATUS_LABELS[o.status] || o.status}
                  </div>
                </div>
              ))
            }
          </Card>
        </div>
      </DashboardLayout>
    </>
  )
}
