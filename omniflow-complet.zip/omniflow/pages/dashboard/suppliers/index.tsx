import { useEffect, useState } from 'react'
import DashboardLayout from '../../components/DashboardLayout'
import { Card, CardTitle, Badge, Table, Empty, Btn } from '../../components/ui'
import { useRequireAuth } from '../../lib/auth-context'
import Head from 'next/head'

type Supplier = {
  id: string; name: string; type: string; country?: string
  email?: string; notes?: string; active: boolean; createdAt: string
}

const TYPE_LABELS: Record<string, string> = {
  ALIEXPRESS: 'AliExpress', CJ_DROPSHIPPING: 'CJ Dropshipping',
  ZENDROP: 'Zendrop', SPOCKET: 'Spocket',
  WHOLESALE: 'Grossiste', PRIVATE: 'Entrepôt privé', OTHER: 'Autre',
}
const TYPE_COLORS: Record<string, 'info' | 'success' | 'warning' | 'neutral'> = {
  ALIEXPRESS: 'danger' as any, CJ_DROPSHIPPING: 'info', ZENDROP: 'info',
  SPOCKET: 'warning', WHOLESALE: 'success', PRIVATE: 'neutral', OTHER: 'neutral',
}

export default function SuppliersPage() {
  useRequireAuth()
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ name: '', type: 'CJ_DROPSHIPPING', country: '', email: '', notes: '' })
  const [saving, setSaving] = useState(false)

  const load = () => {
    fetch('/api/suppliers').then(r => r.json()).then(d => {
      setSuppliers(Array.isArray(d) ? d : [])
      setLoading(false)
    })
  }
  useEffect(load, [])

  const save = async () => {
    if (!form.name) return
    setSaving(true)
    await fetch('/api/suppliers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
    setSaving(false)
    setShowForm(false)
    setForm({ name: '', type: 'CJ_DROPSHIPPING', country: '', email: '', notes: '' })
    load()
  }

  const rows = suppliers.map(s => [
    <div>
      <div style={{ fontSize: 13, fontWeight: 500 }}>{s.name}</div>
      {s.notes && <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.35)', marginTop: 2 }}>{s.notes}</div>}
    </div>,
    <Badge label={TYPE_LABELS[s.type] || s.type} type={TYPE_COLORS[s.type] || 'neutral'} />,
    <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.45)' }}>{s.country || '—'}</div>,
    <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.45)' }}>{s.email || '—'}</div>,
    <Badge label={s.active ? 'Actif' : 'Inactif'} type={s.active ? 'success' : 'neutral'} />,
    <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)' }}>
      {new Date(s.createdAt).toLocaleDateString('fr-FR')}
    </div>,
  ])

  return (
    <>
      <Head><title>Fournisseurs — OmniFlow</title></Head>
      <DashboardLayout title="Fournisseurs">

        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 20 }}>
          <Btn variant="primary" onClick={() => setShowForm(!showForm)}>
            {showForm ? '✕ Annuler' : '+ Ajouter un fournisseur'}
          </Btn>
        </div>

        {/* Formulaire d'ajout */}
        {showForm && (
          <Card style={{ marginBottom: 20 }}>
            <CardTitle>Nouveau fournisseur</CardTitle>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              {[
                { key: 'name', label: 'Nom *', placeholder: 'CJ Dropshipping' },
                { key: 'email', label: 'Email', placeholder: 'contact@fournisseur.com' },
                { key: 'country', label: 'Pays', placeholder: 'CN' },
              ].map(({ key, label, placeholder }) => (
                <div key={key}>
                  <div style={labelStyle}>{label}</div>
                  <input
                    value={(form as any)[key]}
                    onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                    placeholder={placeholder}
                    style={inputStyle}
                  />
                </div>
              ))}
              <div>
                <div style={labelStyle}>Type</div>
                <select
                  value={form.type}
                  onChange={e => setForm(f => ({ ...f, type: e.target.value }))}
                  style={inputStyle}
                >
                  {Object.entries(TYPE_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                </select>
              </div>
              <div style={{ gridColumn: '1 / -1' }}>
                <div style={labelStyle}>Notes</div>
                <input
                  value={form.notes}
                  onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                  placeholder="Délai moyen, conditions particulières…"
                  style={inputStyle}
                />
              </div>
            </div>
            <div style={{ marginTop: 16 }}>
              <Btn variant="primary" onClick={save}>{saving ? 'Enregistrement…' : 'Enregistrer'}</Btn>
            </div>
          </Card>
        )}

        <Card>
          <CardTitle>Mes fournisseurs ({suppliers.length})</CardTitle>
          {loading
            ? <Empty icon="⏳" text="Chargement…" />
            : rows.length === 0
            ? <Empty icon="🤝" text="Aucun fournisseur. Ajoutez-en un pour commencer." />
            : <Table headers={['Fournisseur', 'Type', 'Pays', 'Email', 'Statut', 'Ajouté le']} rows={rows} />
          }
        </Card>
      </DashboardLayout>
    </>
  )
}

const labelStyle: React.CSSProperties = { fontSize: 12, color: 'rgba(255,255,255,0.45)', marginBottom: 6 }
const inputStyle: React.CSSProperties = {
  width: '100%', padding: '9px 12px', borderRadius: 8,
  border: '1px solid rgba(255,255,255,0.1)', background: 'rgba(255,255,255,0.04)',
  color: '#fafaf8', fontSize: 13, fontFamily: 'inherit', outline: 'none',
}
