import { useEffect, useState } from 'react'
import DashboardLayout from '../../components/DashboardLayout'
import { MetricCard, Card, CardTitle, Badge, Grid, Empty } from '../../components/ui'
import { useRequireAuth, useUser } from '../../lib/auth-context'
import { useRouter } from 'next/router'
import Head from 'next/head'

type Stats = {
  totalOrders: number; ordersThisMonth: number; orderDelta: number
  revenueThisMonth: number; revenueDelta: number
  pendingOrders: number; lowStockCount: number
  recentOrders: {
    id: string; total: number; status: string; createdAt: string
    shop: { name: string; platform: string }
  }[]
}

const STATUS_MAP: Record<string, { label: string; type: 'success' | 'warning' | 'danger' | 'info' | 'neutral' }> = {
  PENDING:    { label: 'En attente',    type: 'warning' },
  CONFIRMED:  { label: 'Confirmée',     type: 'info' },
  PROCESSING: { label: 'En traitement', type: 'info' },
  SHIPPED:    { label: 'Expédiée',      type: 'success' },
  DELIVERED:  { label: 'Livrée',        type: 'success' },
  CANCELLED:  { label: 'Annulée',       type: 'danger' },
}

const QUICK_ACTIONS = [
  { label: 'Commandes',       href: '/dashboard/orders',     icon: '🛒' },
  { label: 'Stocks',          href: '/dashboard/stocks',     icon: '📦' },
  { label: 'Tracking',        href: '/dashboard/tracking',   icon: '🚚' },
  { label: 'Prévisions IA',   href: '/dashboard/ai',         icon: '🤖' },
  { label: 'Automatisations', href: '/dashboard/automation', icon: '⚡' },
  { label: 'Fournisseurs',    href: '/dashboard/suppliers',  icon: '🤝' },
]

export default function DashboardHome() {
  const { user } = useRequireAuth()
  const { refreshUser } = useUser()
  const router = useRouter()
  const [stats, setStats] = useState<Stats | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (router.query.success) refreshUser()
    fetch('/api/analytics/stats')
      .then(r => r.json())
      .then(d => { setStats(d); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  const isPaid = user?.plan !== 'FREE'

  return (
    <>
      <Head><title>Dashboard — OmniFlow</title></Head>
      <DashboardLayout title={`Bonjour${user?.name ? `, ${user.name}` : ''} 👋`}>

        {router.query.success && (
          <div style={{ padding: '14px 20px', background: 'rgba(200,241,53,0.07)', border: '1px solid rgba(200,241,53,0.2)', borderRadius: 12, color: '#c8f135', fontSize: 14, marginBottom: 24 }}>
            🎉 Plan <strong>{user?.plan}</strong> activé avec succès. Bienvenue sur OmniFlow !
          </div>
        )}

        {!isPaid && (
          <div style={{ padding: '18px 22px', marginBottom: 24, background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap' }}>
            <div>
              <div style={{ fontSize: 14, fontWeight: 500 }}>Vous êtes sur le plan gratuit</div>
              <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.4)', marginTop: 4 }}>Connectez vos boutiques et automatisez votre e-commerce.</div>
            </div>
            <button onClick={() => router.push('/pricing')} style={{ padding: '11px 24px', borderRadius: 100, background: '#c8f135', color: '#0a0a0a', border: 'none', fontWeight: 600, cursor: 'pointer', fontSize: 14, fontFamily: 'inherit' }}>
              Choisir un plan →
            </button>
          </div>
        )}

        <Grid cols={4} gap={12}>
          <MetricCard label="CA ce mois" value={loading ? '—' : `${(stats?.revenueThisMonth || 0).toFixed(0)} €`} delta={stats ? `${stats.revenueDelta >= 0 ? '+' : ''}${stats.revenueDelta}% vs mois dernier` : undefined} deltaUp={(stats?.revenueDelta || 0) >= 0} color="#c8f135" />
          <MetricCard label="Commandes ce mois" value={loading ? '—' : stats?.ordersThisMonth || 0} delta={stats ? `${stats.orderDelta >= 0 ? '+' : ''}${stats.orderDelta}% vs mois dernier` : undefined} deltaUp={(stats?.orderDelta || 0) >= 0} />
          <MetricCard label="En attente" value={loading ? '—' : stats?.pendingOrders || 0} color={(stats?.pendingOrders || 0) > 0 ? '#ffb432' : undefined} />
          <MetricCard label="Stocks bas" value={loading ? '—' : stats?.lowStockCount || 0} color={(stats?.lowStockCount || 0) > 0 ? '#ff5050' : undefined} />
        </Grid>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 20, marginTop: 20 }}>
          <Card>
            <CardTitle action="Tout voir →" onAction={() => router.push('/dashboard/orders')}>Commandes récentes</CardTitle>
            {loading
              ? <Empty icon="⏳" text="Chargement…" />
              : !stats?.recentOrders?.length
              ? <Empty icon="🛒" text="Aucune commande. Connectez vos boutiques dans les paramètres." />
              : stats.recentOrders.map(o => {
                const st = STATUS_MAP[o.status] || { label: o.status, type: 'neutral' as const }
                return (
                  <div key={o.id} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '10px 0', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ fontSize: 13, fontWeight: 500 }}>{o.shop.name}</span>
                        <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)' }}>{o.shop.platform}</span>
                      </div>
                      <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', marginTop: 2 }}>{new Date(o.createdAt).toLocaleDateString('fr-FR')}</div>
                    </div>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>{o.total.toFixed(2)} €</div>
                    <Badge label={st.label} type={st.type} />
                  </div>
                )
              })
            }
          </Card>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Card>
              <CardTitle>Accès rapide</CardTitle>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {QUICK_ACTIONS.map(a => (
                  <button key={a.href} onClick={() => router.push(a.href)} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 9, fontSize: 13, cursor: 'pointer', fontFamily: 'inherit', background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.06)', color: 'rgba(255,255,255,0.65)', textAlign: 'left' }}>
                    <span style={{ fontSize: 16 }}>{a.icon}</span>
                    {a.label}
                    <span style={{ marginLeft: 'auto', color: 'rgba(255,255,255,0.2)', fontSize: 12 }}>→</span>
                  </button>
                ))}
              </div>
            </Card>

            <Card>
              <CardTitle>Mon plan</CardTitle>
              <div style={{ fontSize: 22, fontFamily: 'Georgia,serif', letterSpacing: '-0.5px', marginBottom: 6 }}>{user?.plan}</div>
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.35)', marginBottom: 14 }}>
                {user?.subscriptionStatus === 'ACTIVE' ? '✓ Actif' : user?.subscriptionStatus}
                {user?.currentPeriodEnd && ` · ${new Date(user.currentPeriodEnd).toLocaleDateString('fr-FR')}`}
              </div>
              <button onClick={() => router.push('/dashboard/settings')} style={{ fontSize: 12, color: '#c8f135', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'inherit', padding: 0 }}>
                Gérer l'abonnement →
              </button>
            </Card>
          </div>
        </div>
      </DashboardLayout>
    </>
  )
}
