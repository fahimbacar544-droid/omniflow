import { useEffect, useState } from 'react'
import DashboardLayout from '../../components/DashboardLayout'
import { MetricCard, Card, CardTitle, Badge, Table, Grid, Empty } from '../../components/ui'
import { useRequireAuth } from '../../lib/auth-context'
import Head from 'next/head'

type Shipment = {
  id: string; carrier: string; trackingNumber?: string; status: string
  estimatedDelivery?: string; shippedAt?: string; deliveredAt?: string
  createdAt: string
  order: { id: string; customerName?: string; customerCountry?: string; total: number; shop: { name: string } }
  events: { id: string; status: string; location?: string; message?: string; happenedAt: string }[]
}

const CARRIER_FLAGS: Record<string, string> = {
  COLISSIMO: '🇫🇷', CHRONOPOST: '🇫🇷', DHL: '🇩🇪', UPS: '🇺🇸',
  FEDEX: '🇺🇸', YUNEXPRESS: '🇨🇳', FOURPX: '🇨🇳', CAINIAO: '🇨🇳', OTHER: '🌍',
}

const SHIP_STATUS: Record<string, { label: string; type: 'success' | 'info' | 'warning' | 'danger' | 'neutral' }> = {
  LABEL_CREATED:    { label: 'Étiquette créée',   type: 'neutral' },
  IN_TRANSIT:       { label: 'En transit',         type: 'info' },
  OUT_FOR_DELIVERY: { label: 'En livraison',        type: 'warning' },
  DELIVERED:        { label: 'Livré ✓',             type: 'success' },
  EXCEPTION:        { label: 'Anomalie !',           type: 'danger' },
  RETURNED:         { label: 'Retourné',             type: 'danger' },
}

export default function TrackingPage() {
  useRequireAuth()
  const [shipments, setShipments] = useState<Shipment[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<Shipment | null>(null)

  useEffect(() => {
    fetch('/api/tracking')
      .then(r => r.json())
      .then(data => { setShipments(Array.isArray(data) ? data : []); setLoading(false) })
  }, [])

  const inTransit  = shipments.filter(s => s.status === 'IN_TRANSIT').length
  const delivered  = shipments.filter(s => s.status === 'DELIVERED').length
  const exceptions = shipments.filter(s => s.status === 'EXCEPTION').length

  const rows = shipments.map(s => {
    const st = SHIP_STATUS[s.status] || { label: s.status, type: 'neutral' as const }
    return [
      <div>
        <div style={{ fontSize: 13, fontWeight: 500 }}>
          {CARRIER_FLAGS[s.carrier] || '📦'} {s.carrier}
        </div>
        <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.35)', marginTop: 2 }}>
          {s.trackingNumber || 'Sans numéro'}
        </div>
      </div>,
      <div style={{ fontSize: 13 }}>{s.order.customerName || s.order.id.slice(-8)}</div>,
      <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.45)' }}>{s.order.shop.name}</div>,
      <Badge label={st.label} type={st.type} />,
      <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>
        {s.estimatedDelivery
          ? new Date(s.estimatedDelivery).toLocaleDateString('fr-FR')
          : '—'}
      </div>,
      <button onClick={() => setSelected(s)} style={{
        padding: '4px 12px', borderRadius: 100, fontSize: 11, cursor: 'pointer',
        fontFamily: 'inherit', border: '1px solid rgba(255,255,255,0.12)',
        background: 'transparent', color: 'rgba(255,255,255,0.6)',
      }}>
        Détails
      </button>,
    ]
  })

  return (
    <>
      <Head><title>Tracking — OmniFlow</title></Head>
      <DashboardLayout title="Tracking colis">

        <Grid cols={4} gap={12}>
          <MetricCard label="Total colis" value={shipments.length} />
          <MetricCard label="En transit" value={inTransit} color="#60a5fa" />
          <MetricCard label="Livrés" value={delivered} color="#64dc78" />
          <MetricCard label="Anomalies" value={exceptions} color={exceptions > 0 ? '#ff5050' : undefined} />
        </Grid>

        <div style={{ display: 'grid', gridTemplateColumns: selected ? '1fr 340px' : '1fr', gap: 16, marginTop: 28 }}>
          <Card>
            <CardTitle>Tous les envois</CardTitle>
            {loading
              ? <Empty icon="⏳" text="Chargement…" />
              : rows.length === 0
              ? <Empty icon="🚚" text="Aucun colis. Les expéditions apparaîtront ici." />
              : <Table
                  headers={['Transporteur', 'Client', 'Boutique', 'Statut', 'Livraison prévue', 'Action']}
                  rows={rows}
                />
            }
          </Card>

          {/* Panneau détail */}
          {selected && (
            <Card style={{ alignSelf: 'start' }}>
              <CardTitle action="✕ Fermer" onAction={() => setSelected(null)}>
                Détail colis
              </CardTitle>
              <div style={{ fontSize: 13, marginBottom: 16 }}>
                <div style={{ color: 'rgba(255,255,255,0.5)', marginBottom: 4 }}>Numéro de suivi</div>
                <div style={{ fontWeight: 500 }}>{selected.trackingNumber || '—'}</div>
              </div>
              <div style={{ fontSize: 13, marginBottom: 16 }}>
                <div style={{ color: 'rgba(255,255,255,0.5)', marginBottom: 4 }}>Transporteur</div>
                <div>{CARRIER_FLAGS[selected.carrier]} {selected.carrier}</div>
              </div>
              <div style={{ fontSize: 13, marginBottom: 20 }}>
                <div style={{ color: 'rgba(255,255,255,0.5)', marginBottom: 4 }}>Client</div>
                <div>{selected.order.customerName || '—'}</div>
              </div>

              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.35)', marginBottom: 10, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                Historique
              </div>
              {selected.events.length === 0
                ? <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.3)' }}>Aucun événement</div>
                : selected.events.map(ev => (
                  <div key={ev.id} style={{ padding: '10px 0', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                    <div style={{ fontSize: 12, fontWeight: 500 }}>{ev.status}</div>
                    {ev.location && <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.35)', marginTop: 2 }}>{ev.location}</div>}
                    {ev.message && <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.4)', marginTop: 2 }}>{ev.message}</div>}
                    <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.25)', marginTop: 4 }}>
                      {new Date(ev.happenedAt).toLocaleString('fr-FR')}
                    </div>
                  </div>
                ))
              }
            </Card>
          )}
        </div>
      </DashboardLayout>
    </>
  )
}
