import { useEffect, useState } from 'react'
import DashboardLayout from '../../components/DashboardLayout'
import { MetricCard, Card, CardTitle, Badge, Table, Btn, Grid, Empty } from '../../components/ui'
import { useRequireAuth } from '../../lib/auth-context'
import Head from 'next/head'

type Stock = {
  id: string
  quantity: number
  reserved: number
  product: { id: string; name: string; sku: string; shop: { name: string; platform: string } }
  warehouse: { id: string; name: string; country: string }
}

function getStatus(qty: number): { label: string; type: 'success' | 'warning' | 'danger' } {
  if (qty === 0) return { label: 'Rupture', type: 'danger' }
  if (qty <= 5)  return { label: 'Critique', type: 'danger' }
  if (qty <= 15) return { label: 'Bas', type: 'warning' }
  return { label: 'OK', type: 'success' }
}

export default function StocksPage() {
  useRequireAuth()
  const [stocks, setStocks] = useState<Stock[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<'all' | 'low' | 'ok'>('all')
  const [search, setSearch] = useState('')

  useEffect(() => {
    fetch('/api/stocks')
      .then(r => r.json())
      .then(data => { setStocks(Array.isArray(data) ? data : []); setLoading(false) })
  }, [])

  const filtered = stocks.filter(s => {
    const matchSearch = s.product.name.toLowerCase().includes(search.toLowerCase()) ||
      s.product.sku.toLowerCase().includes(search.toLowerCase())
    if (filter === 'low') return matchSearch && s.quantity <= 15
    if (filter === 'ok')  return matchSearch && s.quantity > 15
    return matchSearch
  })

  const total = stocks.reduce((a, s) => a + s.quantity, 0)
  const lowCount = stocks.filter(s => s.quantity <= 15).length
  const outCount = stocks.filter(s => s.quantity === 0).length
  const products = new Set(stocks.map(s => s.product.id)).size

  const rows = filtered.map(s => {
    const avail = s.quantity - s.reserved
    const st = getStatus(s.quantity)
    return [
      <div>
        <div style={{ fontSize: 13, fontWeight: 500, color: '#fafaf8' }}>{s.product.name}</div>
        <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.35)', marginTop: 2 }}>SKU: {s.product.sku}</div>
      </div>,
      <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.45)' }}>{s.product.shop.name}</div>,
      <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.45)' }}>{s.warehouse.name} · {s.warehouse.country}</div>,
      <span style={{ fontSize: 14, fontWeight: 500 }}>{s.quantity}</span>,
      <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>{s.reserved}</span>,
      <span style={{ fontSize: 13, fontWeight: 500, color: avail > 0 ? '#fafaf8' : '#ff5050' }}>{avail}</span>,
      <Badge label={st.label} type={st.type} />,
    ]
  })

  return (
    <>
      <Head><title>Stocks — OmniFlow</title></Head>
      <DashboardLayout title="Gestion des stocks">

        <Grid cols={4} gap={12}>
          <MetricCard label="Stock total" value={total.toLocaleString()} />
          <MetricCard label="Produits actifs" value={products} />
          <MetricCard label="Stocks bas (≤15)" value={lowCount} color={lowCount > 0 ? '#ffb432' : undefined} />
          <MetricCard label="Ruptures" value={outCount} color={outCount > 0 ? '#ff5050' : undefined} />
        </Grid>

        <div style={{ marginTop: 28 }}>
          <Card>
            <CardTitle>Tous les stocks</CardTitle>

            {/* Filtres */}
            <div style={{ display: 'flex', gap: 10, marginBottom: 16, flexWrap: 'wrap', alignItems: 'center' }}>
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Chercher produit ou SKU…"
                style={{
                  flex: 1, minWidth: 200, padding: '8px 12px', borderRadius: 8,
                  border: '1px solid rgba(255,255,255,0.1)',
                  background: 'rgba(255,255,255,0.04)', color: '#fafaf8',
                  fontSize: 13, fontFamily: 'inherit', outline: 'none',
                }}
              />
              {(['all', 'low', 'ok'] as const).map(f => (
                <button key={f} onClick={() => setFilter(f)} style={{
                  padding: '7px 16px', borderRadius: 100, fontSize: 12, cursor: 'pointer',
                  fontFamily: 'inherit', border: '1px solid rgba(255,255,255,0.1)',
                  background: filter === f ? 'rgba(200,241,53,0.1)' : 'transparent',
                  color: filter === f ? '#c8f135' : 'rgba(255,255,255,0.5)',
                }}>
                  {f === 'all' ? 'Tous' : f === 'low' ? '⚠️ Bas' : '✓ OK'}
                </button>
              ))}
            </div>

            {loading
              ? <Empty icon="⏳" text="Chargement des stocks…" />
              : rows.length === 0
              ? <Empty icon="📦" text="Aucun stock trouvé. Ajoutez des boutiques et des produits." />
              : <Table
                  headers={['Produit', 'Boutique', 'Entrepôt', 'Quantité', 'Réservé', 'Disponible', 'Statut']}
                  rows={rows}
                />
            }
          </Card>
        </div>
      </DashboardLayout>
    </>
  )
}
