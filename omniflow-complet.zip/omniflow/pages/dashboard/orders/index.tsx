import { useEffect, useState } from 'react'
import DashboardLayout from '../../components/DashboardLayout'
import { MetricCard, Card, CardTitle, Badge, Table, Grid, Empty, Btn } from '../../components/ui'
import { useRequireAuth } from '../../lib/auth-context'
import Head from 'next/head'

type Order = {
  id: string; externalId?: string; status: string
  customerName?: string; customerEmail?: string; customerCountry?: string
  total: number; currency: string; createdAt: string
  shop: { name: string; platform: string }
  shipment?: { carrier: string; trackingNumber?: string; status: string }
}

const STATUS_MAP: Record<string, { label: string; type: 'success' | 'warning' | 'danger' | 'info' | 'neutral' }> = {
  PENDING:    { label: 'En attente',    type: 'warning' },
  CONFIRMED:  { label: 'Confirmée',     type: 'info' },
  PROCESSING: { label: 'En traitement', type: 'info' },
  SHIPPED:    { label: 'Expédiée',      type: 'success' },
  DELIVERED:  { label: 'Livrée',        type: 'success' },
  CANCELLED:  { label: 'Annulée',       type: 'danger' },
  REFUNDED:   { label: 'Remboursée',    type: 'neutral' },
}

export default function OrdersPage() {
  useRequireAuth()
  const [orders, setOrders] = useState<Order[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState('')

  const load = (status = '') => {
    setLoading(true)
    const url = status ? `/api/orders?status=${status}` : '/api/orders'
    fetch(url)
      .then(r => r.json())
      .then(data => {
        setOrders(data.orders || [])
        setTotal(data.total || 0)
        setLoading(false)
      })
  }

  useEffect(() => { load() }, [])

  const updateStatus = async (id: string, status: string) => {
    await fetch(`/api/orders/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    })
    load(statusFilter)
  }

  const pending   = orders.filter(o => o.status === 'PENDING').length
  const shipped   = orders.filter(o => o.status === 'SHIPPED').length
  const delivered = orders.filter(o => o.status === 'DELIVERED').length
  const ca        = orders.reduce((s, o) => s + o.total, 0)

  const statuses = ['', 'PENDING', 'CONFIRMED', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED']

  const rows = orders.map(o => {
    const st = STATUS_MAP[o.status] || { label: o.status, type: 'neutral' as const }
    return [
      <div>
        <div style={{ fontSize: 13, fontWeight: 500 }}>{o.externalId || o.id.slice(-8).toUpperCase()}</div>
        <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', marginTop: 2 }}>
          {new Date(o.createdAt).toLocaleDateString('fr-FR')}
        </div>
      </div>,
      <div style={{ fontSize: 13 }}>{o.customerName || '—'}</div>,
      <div>
        <div style={{ fontSize: 12 }}>{o.shop.name}</div>
        <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.35)' }}>{o.shop.platform}</div>
      </div>,
      <span style={{ fontSize: 13, fontWeight: 500 }}>{o.total.toFixed(2)} {o.currency}</span>,
      <Badge label={st.label} type={st.type} />,
      o.shipment
        ? <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.45)' }}>
            {o.shipment.carrier} · {o.shipment.trackingNumber || 'sans numéro'}
          </div>
        : <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.25)' }}>—</span>,
      <div style={{ display: 'flex', gap: 6 }}>
        {o.status === 'PENDING' && (
          <button onClick={() => updateStatus(o.id, 'CONFIRMED')} style={actionBtn}>
            Confirmer
          </button>
        )}
        {o.status === 'CONFIRMED' && (
          <button onClick={() => updateStatus(o.id, 'PROCESSING')} style={actionBtn}>
            Traiter
          </button>
        )}
        {o.status === 'PROCESSING' && (
          <button onClick={() => updateStatus(o.id, 'SHIPPED')} style={{ ...actionBtn, color: '#c8f135' }}>
            Expédier
          </button>
        )}
      </div>,
    ]
  })

  return (
    <>
      <Head><title>Commandes — OmniFlow</title></Head>
      <DashboardLayout title="Commandes">

        <Grid cols={4} gap={12}>
          <MetricCard label="Total commandes" value={total} />
          <MetricCard label="En attente" value={pending} color={pending > 0 ? '#ffb432' : undefined} />
          <MetricCard label="Expédiées" value={shipped} color="#60a5fa" />
          <MetricCard label="CA affiché" value={`${ca.toFixed(0)} €`} color="#c8f135" />
        </Grid>

        <div style={{ marginTop: 28 }}>
          <Card>
            <CardTitle>Toutes les commandes</CardTitle>

            {/* Filtres statut */}
            <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
              {statuses.map(s => (
                <button key={s} onClick={() => { setStatusFilter(s); load(s) }} style={{
                  padding: '6px 14px', borderRadius: 100, fontSize: 12, cursor: 'pointer',
                  fontFamily: 'inherit', border: '1px solid rgba(255,255,255,0.1)',
                  background: statusFilter === s ? 'rgba(200,241,53,0.1)' : 'transparent',
                  color: statusFilter === s ? '#c8f135' : 'rgba(255,255,255,0.5)',
                }}>
                  {s === '' ? 'Toutes' : STATUS_MAP[s]?.label || s}
                </button>
              ))}
            </div>

            {loading
              ? <Empty icon="⏳" text="Chargement des commandes…" />
              : rows.length === 0
              ? <Empty icon="🛒" text="Aucune commande. Connectez vos boutiques pour commencer." />
              : <Table
                  headers={['Référence', 'Client', 'Boutique', 'Total', 'Statut', 'Livraison', 'Action']}
                  rows={rows}
                />
            }
          </Card>
        </div>
      </DashboardLayout>
    </>
  )
}

const actionBtn: React.CSSProperties = {
  padding: '4px 12px', borderRadius: 100, fontSize: 11, cursor: 'pointer',
  fontFamily: 'inherit', border: '1px solid rgba(255,255,255,0.12)',
  background: 'transparent', color: 'rgba(255,255,255,0.6)',
}
