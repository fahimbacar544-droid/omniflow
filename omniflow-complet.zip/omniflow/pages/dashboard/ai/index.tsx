import { useEffect, useState } from 'react'
import DashboardLayout from '../../components/DashboardLayout'
import { Card, CardTitle, Badge, Empty, MetricCard, Grid } from '../../components/ui'
import { useRequireAuth } from '../../lib/auth-context'
import Head from 'next/head'

// Simule les prévisions IA côté front (en prod: appel à ton modèle ou OpenAI)
const AI_INSIGHTS = [
  {
    id: 1, type: 'RUPTURE', priority: 'high',
    title: 'Rupture prévue dans 6 jours',
    detail: 'Montre connectée · Entrepôt FR · stock actuel : 7 unités · vente moyenne : 1.2/jour',
    recommendation: 'Commander 150 unités chez CJ Dropshipping (délai 8-12j)',
    icon: '⚠️',
  },
  {
    id: 2, type: 'BESTSELLER', priority: 'medium',
    title: 'Best-seller émergent détecté',
    detail: 'Coque iPhone 15 · +340% de ventes sur les 7 derniers jours',
    recommendation: 'Augmenter le stock de 200 unités, activer FBA pour réduction délai',
    icon: '🚀',
  },
  {
    id: 3, type: 'SAISONNALITE', priority: 'medium',
    title: 'Saisonnalité détectée — été 2026',
    detail: 'Ventilateurs USB · pic attendu juin-août (+220%) basé sur données 2024-2025',
    recommendation: 'Précommander 500 unités en mai pour éviter la rupture estivale',
    icon: '☀️',
  },
  {
    id: 4, type: 'ANOMALIE', priority: 'high',
    title: 'Anomalie de ventes détectée',
    detail: 'Câble USB-C 2m · 0 vente depuis 4 jours sur Etsy (moyenne habituelle: 8/jour)',
    recommendation: 'Vérifier la visibilité du listing, possibilité de suspension de compte',
    icon: '🔍',
  },
  {
    id: 5, type: 'OPTIMISATION', priority: 'low',
    title: 'Optimisation fournisseur possible',
    detail: 'Lampe LED USB · CJ propose 0,85€/unité vs AliExpress actuel à 1,20€/unité',
    recommendation: 'Économie potentielle : 35% · Passer commande test de 50 unités',
    icon: '💰',
  },
  {
    id: 6, type: 'REAPPRO', priority: 'medium',
    title: 'Réapprovisionnement recommandé',
    detail: 'Sac à dos 20L · Stock FR : 54 unités · stock China : 380 · délai livraison France : 18j',
    recommendation: 'Transférer 200 unités Chine → France dès maintenant',
    icon: '📦',
  },
]

const PRIORITY: Record<string, { label: string; type: 'danger' | 'warning' | 'neutral' }> = {
  high:   { label: 'Urgent',  type: 'danger'  },
  medium: { label: 'Moyen',   type: 'warning' },
  low:    { label: 'Conseil', type: 'neutral' },
}

const MONTHS = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc']
const FORECAST = [42, 38, 55, 61, 78, 110, 135, 128, 89, 72, 95, 108]
const MAX_F = Math.max(...FORECAST)

export default function AIPage() {
  useRequireAuth()
  const [dismissed, setDismissed] = useState<number[]>([])
  const [applied, setApplied] = useState<number[]>([])

  const visible = AI_INSIGHTS.filter(i => !dismissed.includes(i.id))
  const urgent = visible.filter(i => i.priority === 'high').length

  return (
    <>
      <Head><title>Prévisions IA — OmniFlow</title></Head>
      <DashboardLayout title="Prévisions IA">

        <Grid cols={4} gap={12}>
          <MetricCard label="Insights actifs" value={visible.length} />
          <MetricCard label="Actions urgentes" value={urgent} color={urgent > 0 ? '#ff5050' : undefined} />
          <MetricCard label="Économies potentielles" value="~320€/mois" color="#c8f135" />
          <MetricCard label="Précision modèle" value="91%" color="#64dc78" />
        </Grid>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 20, marginTop: 28 }}>

          {/* Insights */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 4 }}>
              Recommandations IA ({visible.length})
            </div>

            {visible.length === 0
              ? <Card><Empty icon="🤖" text="Tout est en ordre. L'IA surveille en continu." /></Card>
              : visible.map(insight => {
                const prio = PRIORITY[insight.priority]
                const isApplied = applied.includes(insight.id)
                return (
                  <Card key={insight.id}>
                    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
                      <div style={{ fontSize: 28, flexShrink: 0 }}>{insight.icon}</div>
                      <div style={{ flex: 1 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6, flexWrap: 'wrap' }}>
                          <div style={{ fontSize: 14, fontWeight: 500 }}>{insight.title}</div>
                          <Badge label={prio.label} type={prio.type} />
                        </div>
                        <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.5)', marginBottom: 10, lineHeight: 1.5 }}>
                          {insight.detail}
                        </div>
                        <div style={{
                          padding: '10px 14px', borderRadius: 10,
                          background: 'rgba(200,241,53,0.05)',
                          border: '1px solid rgba(200,241,53,0.15)',
                          fontSize: 12, color: 'rgba(200,241,53,0.85)', lineHeight: 1.5, marginBottom: 12,
                        }}>
                          ✦ {insight.recommendation}
                        </div>
                        <div style={{ display: 'flex', gap: 8 }}>
                          <button
                            onClick={() => setApplied(a => isApplied ? a.filter(x => x !== insight.id) : [...a, insight.id])}
                            style={{
                              padding: '6px 16px', borderRadius: 100, fontSize: 12, cursor: 'pointer',
                              fontFamily: 'inherit', border: 'none',
                              background: isApplied ? 'rgba(100,220,120,0.15)' : 'rgba(200,241,53,0.12)',
                              color: isApplied ? '#64dc78' : '#c8f135',
                            }}
                          >
                            {isApplied ? '✓ Appliqué' : 'Appliquer la recommandation'}
                          </button>
                          <button
                            onClick={() => setDismissed(d => [...d, insight.id])}
                            style={{
                              padding: '6px 14px', borderRadius: 100, fontSize: 12, cursor: 'pointer',
                              fontFamily: 'inherit', border: '1px solid rgba(255,255,255,0.1)',
                              background: 'transparent', color: 'rgba(255,255,255,0.4)',
                            }}
                          >
                            Ignorer
                          </button>
                        </div>
                      </div>
                    </div>
                  </Card>
                )
              })
            }
          </div>

          {/* Sidebar prévision ventes */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Card>
              <CardTitle>Prévision des ventes 2026</CardTitle>
              <div style={{ display: 'flex', alignItems: 'flex-end', gap: 4, height: 120, marginBottom: 8 }}>
                {FORECAST.map((v, i) => {
                  const now = new Date().getMonth()
                  const isCurrent = i === now
                  const isFuture = i > now
                  return (
                    <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                      <div style={{
                        width: '100%',
                        height: `${(v / MAX_F) * 100}%`,
                        borderRadius: '3px 3px 0 0',
                        background: isCurrent
                          ? '#c8f135'
                          : isFuture
                          ? 'rgba(200,241,53,0.25)'
                          : 'rgba(255,255,255,0.15)',
                        minHeight: 4,
                      }} />
                    </div>
                  )
                })}
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                {MONTHS.map(m => (
                  <div key={m} style={{ fontSize: 9, color: 'rgba(255,255,255,0.25)', textAlign: 'center' }}>{m}</div>
                ))}
              </div>
              <div style={{ marginTop: 14, display: 'flex', gap: 12, fontSize: 11, color: 'rgba(255,255,255,0.35)' }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                  <span style={{ width: 8, height: 8, borderRadius: 2, background: '#c8f135', display: 'inline-block' }} /> Mois actuel
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                  <span style={{ width: 8, height: 8, borderRadius: 2, background: 'rgba(200,241,53,0.25)', display: 'inline-block' }} /> Prévision
                </span>
              </div>
            </Card>

            <Card>
              <CardTitle>Top produits prévus</CardTitle>
              {[
                { name: 'Coque iPhone 15', trend: '+34%', score: 92 },
                { name: 'Montre connectée', trend: '+18%', score: 78 },
                { name: 'Câble USB-C 2m', trend: '+12%', score: 65 },
                { name: 'Lampe LED USB', trend: '-8%', score: 41 },
              ].map(p => (
                <div key={p.name} style={{ padding: '10px 0', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                    <div style={{ fontSize: 13 }}>{p.name}</div>
                    <div style={{ fontSize: 12, color: p.trend.startsWith('+') ? '#64dc78' : '#ff6b6b' }}>{p.trend}</div>
                  </div>
                  <div style={{ height: 4, background: 'rgba(255,255,255,0.08)', borderRadius: 2, overflow: 'hidden' }}>
                    <div style={{ height: '100%', width: `${p.score}%`, background: p.score > 60 ? '#c8f135' : '#ffb432', borderRadius: 2 }} />
                  </div>
                </div>
              ))}
            </Card>
          </div>
        </div>
      </DashboardLayout>
    </>
  )
}
