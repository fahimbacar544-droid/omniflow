import { useEffect, useState } from 'react'
import DashboardLayout from '../../components/DashboardLayout'
import { Card, CardTitle, Badge, Empty, Btn } from '../../components/ui'
import { useRequireAuth } from '../../lib/auth-context'
import Head from 'next/head'

type Automation = {
  id: string; name: string; trigger: string; action: string
  active: boolean; runs: number; lastRunAt?: string; createdAt: string
}

const TEMPLATES = [
  {
    name: 'Commande France → Colissimo',
    trigger: { type: 'ORDER_CREATED', conditions: [{ field: 'country', op: 'eq', value: 'FR' }] },
    action:  { type: 'SET_CARRIER', params: { carrier: 'COLISSIMO' } },
    icon: '📦',
  },
  {
    name: 'Commande USA/UK → DHL',
    trigger: { type: 'ORDER_CREATED', conditions: [{ field: 'country', op: 'in', value: ['US', 'GB'] }] },
    action:  { type: 'SET_CARRIER', params: { carrier: 'DHL' } },
    icon: '✈️',
  },
  {
    name: 'Stock < 10 → Alerte + réappro',
    trigger: { type: 'STOCK_LOW', conditions: [{ field: 'quantity', op: 'lt', value: 10 }] },
    action:  { type: 'ALERT_AND_REORDER', params: { channel: 'email', qty: 100 } },
    icon: '⚠️',
  },
  {
    name: 'FBA vide → Basculer entrepôt FR',
    trigger: { type: 'STOCK_OUT', conditions: [{ field: 'warehouse', op: 'eq', value: 'FBA' }] },
    action:  { type: 'SWITCH_WAREHOUSE', params: { target: 'FR' } },
    icon: '🔄',
  },
  {
    name: 'Comparer fournisseurs → Moins cher',
    trigger: { type: 'ORDER_CONFIRMED', conditions: [] },
    action:  { type: 'BEST_SUPPLIER', params: { criteria: 'price' } },
    icon: '💰',
  },
  {
    name: 'Sync stocks toutes les 5 min',
    trigger: { type: 'SCHEDULE', conditions: [{ field: 'interval', op: 'eq', value: '5m' }] },
    action:  { type: 'SYNC_ALL_STOCKS', params: {} },
    icon: '🔁',
  },
]

export default function AutomationPage() {
  useRequireAuth()
  const [automations, setAutomations] = useState<Automation[]>([])
  const [loading, setLoading] = useState(true)

  const load = () => {
    fetch('/api/automations').then(r => r.json()).then(d => {
      setAutomations(Array.isArray(d) ? d : [])
      setLoading(false)
    })
  }
  useEffect(load, [])

  const addFromTemplate = async (t: typeof TEMPLATES[0]) => {
    await fetch('/api/automations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: t.name, trigger: t.trigger, action: t.action }),
    })
    load()
  }

  const toggle = async (id: string, active: boolean) => {
    await fetch(`/api/automations/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ active: !active }),
    })
    load()
  }

  const remove = async (id: string) => {
    if (!confirm('Supprimer cette automation ?')) return
    await fetch(`/api/automations/${id}`, { method: 'DELETE' })
    load()
  }

  const activeCount = automations.filter(a => a.active).length
  const totalRuns = automations.reduce((s, a) => s + a.runs, 0)

  return (
    <>
      <Head><title>Automatisation — OmniFlow</title></Head>
      <DashboardLayout title="Automatisation">

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 28 }}>
          <div style={statCard}>
            <div style={statLabel}>Automations actives</div>
            <div style={statVal}>{activeCount}</div>
          </div>
          <div style={statCard}>
            <div style={statLabel}>Total exécutions</div>
            <div style={statVal}>{totalRuns}</div>
          </div>
          <div style={statCard}>
            <div style={statLabel}>Automations créées</div>
            <div style={statVal}>{automations.length}</div>
          </div>
        </div>

        {/* Templates */}
        <Card style={{ marginBottom: 20 }}>
          <CardTitle>Modèles prêts à l'emploi</CardTitle>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 10 }}>
            {TEMPLATES.map(t => {
              const exists = automations.some(a => a.name === t.name)
              return (
                <div key={t.name} style={templateCard}>
                  <div style={{ fontSize: 20, marginBottom: 10 }}>{t.icon}</div>
                  <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 6 }}>{t.name}</div>
                  <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.35)', marginBottom: 14, lineHeight: 1.5 }}>
                    Si {t.trigger.type.replace(/_/g, ' ').toLowerCase()} → {t.action.type.replace(/_/g, ' ').toLowerCase()}
                  </div>
                  <button
                    onClick={() => !exists && addFromTemplate(t)}
                    disabled={exists}
                    style={{
                      padding: '6px 14px', borderRadius: 100, fontSize: 11, cursor: exists ? 'default' : 'pointer',
                      fontFamily: 'inherit', border: 'none',
                      background: exists ? 'rgba(100,220,120,0.1)' : 'rgba(200,241,53,0.1)',
                      color: exists ? '#64dc78' : '#c8f135',
                    }}
                  >
                    {exists ? '✓ Ajoutée' : '+ Activer'}
                  </button>
                </div>
              )
            })}
          </div>
        </Card>

        {/* Mes automations */}
        <Card>
          <CardTitle>Mes automations ({automations.length})</CardTitle>
          {loading
            ? <Empty icon="⏳" text="Chargement…" />
            : automations.length === 0
            ? <Empty icon="⚡" text="Aucune automation. Activez un modèle ci-dessus." />
            : automations.map(a => {
              const trigger = JSON.parse(a.trigger)
              const action  = JSON.parse(a.action)
              return (
                <div key={a.id} style={autoRow}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                      <div style={{ fontSize: 14, fontWeight: 500 }}>{a.name}</div>
                      <Badge label={a.active ? 'Actif' : 'Inactif'} type={a.active ? 'success' : 'neutral'} />
                    </div>
                    <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.35)' }}>
                      Déclencheur : <span style={{ color: 'rgba(255,255,255,0.55)' }}>{trigger.type}</span>
                      &nbsp;·&nbsp;
                      Action : <span style={{ color: 'rgba(255,255,255,0.55)' }}>{action.type}</span>
                      &nbsp;·&nbsp;
                      {a.runs} exécution{a.runs > 1 ? 's' : ''}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
                    <button onClick={() => toggle(a.id, a.active)} style={miniBtn}>
                      {a.active ? 'Désactiver' : 'Activer'}
                    </button>
                    <button onClick={() => remove(a.id)} style={{ ...miniBtn, color: '#ff5050', borderColor: 'rgba(255,80,80,0.2)' }}>
                      Supprimer
                    </button>
                  </div>
                </div>
              )
            })
          }
        </Card>
      </DashboardLayout>
    </>
  )
}

const statCard: React.CSSProperties = { background: 'rgba(255,255,255,0.04)', borderRadius: 12, padding: '16px 18px' }
const statLabel: React.CSSProperties = { fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'rgba(255,255,255,0.35)' }
const statVal: React.CSSProperties = { fontSize: 26, fontWeight: 500, marginTop: 6 }
const templateCard: React.CSSProperties = { background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 12, padding: '18px 16px' }
const autoRow: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 16, padding: '14px 0', borderBottom: '1px solid rgba(255,255,255,0.05)' }
const miniBtn: React.CSSProperties = { padding: '5px 12px', borderRadius: 100, fontSize: 11, cursor: 'pointer', fontFamily: 'inherit', border: '1px solid rgba(255,255,255,0.12)', background: 'transparent', color: 'rgba(255,255,255,0.55)' }
