import { useState } from 'react'
import DashboardLayout from '../../components/DashboardLayout'
import { Card, CardTitle, Btn } from '../../components/ui'
import { useRequireAuth, useUser } from '../../lib/auth-context'
import Head from 'next/head'

const PLATFORMS = [
  { id: 'SHOPIFY',      name: 'Shopify',      color: '#95BE46', doc: 'Admin → Apps → Private apps → API key' },
  { id: 'WOOCOMMERCE',  name: 'WooCommerce',  color: '#7F54B3', doc: 'WP Admin → WooCommerce → Settings → REST API' },
  { id: 'PRESTASHOP',   name: 'PrestaShop',   color: '#DF0067', doc: 'Admin → Paramètres avancés → Accès API' },
  { id: 'AMAZON_FBA',   name: 'Amazon FBA',   color: '#FF9900', doc: 'Seller Central → Settings → User Permissions → SP-API' },
  { id: 'ETSY',         name: 'Etsy',         color: '#F56400', doc: 'Etsy Developer Portal → Create App → API Key' },
  { id: 'TIKTOK_SHOP',  name: 'TikTok Shop',  color: '#FE2C55', doc: 'TikTok Seller Center → Developer → App Management' },
]

const WAREHOUSES_DEFAULT = [
  { name: 'Entrepôt France',  country: 'FR' },
  { name: 'Entrepôt Chine',   country: 'CN' },
  { name: 'Amazon FBA',       country: 'US' },
]

type Shop = { name: string; platform: string; apiKey: string }

export default function SettingsPage() {
  const { user, logout } = useUser()
  useRequireAuth()

  const [tab, setTab] = useState<'profile' | 'shops' | 'warehouses' | 'billing' | 'api'>('profile')

  // Profile
  const [name, setName] = useState(user?.name || '')
  const [profileSaved, setProfileSaved] = useState(false)

  // Shops
  const [shops, setShops] = useState<Shop[]>([])
  const [newShop, setNewShop] = useState({ name: '', platform: 'SHOPIFY', apiKey: '' })
  const [shopSaving, setShopSaving] = useState(false)

  // Warehouses
  const [warehouses, setWarehouses] = useState(WAREHOUSES_DEFAULT)
  const [newWH, setNewWH] = useState({ name: '', country: 'FR' })

  const saveProfile = async () => {
    // En prod : PATCH /api/auth/profile
    setProfileSaved(true)
    setTimeout(() => setProfileSaved(false), 2000)
  }

  const addShop = async () => {
    if (!newShop.name || !newShop.apiKey) return
    setShopSaving(true)
    // En prod : POST /api/shops
    await new Promise(r => setTimeout(r, 600))
    setShops(s => [...s, { ...newShop }])
    setNewShop({ name: '', platform: 'SHOPIFY', apiKey: '' })
    setShopSaving(false)
  }

  const addWarehouse = () => {
    if (!newWH.name) return
    setWarehouses(w => [...w, { ...newWH }])
    setNewWH({ name: '', country: 'FR' })
  }

  const openBillingPortal = async () => {
    const res = await fetch('/api/stripe/portal', { method: 'POST' })
    const data = await res.json()
    if (data.url) window.location.href = data.url
  }

  const TABS: { id: typeof tab; label: string; icon: string }[] = [
    { id: 'profile',    label: 'Profil',      icon: '👤' },
    { id: 'shops',      label: 'Boutiques',   icon: '🏪' },
    { id: 'warehouses', label: 'Entrepôts',   icon: '🏭' },
    { id: 'billing',    label: 'Abonnement',  icon: '💳' },
    { id: 'api',        label: 'API',         icon: '⚙️' },
  ]

  return (
    <>
      <Head><title>Paramètres — OmniFlow</title></Head>
      <DashboardLayout title="Paramètres">
        <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr', gap: 24, alignItems: 'start' }}>

          {/* Tab nav */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {TABS.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)} style={{
                display: 'flex', alignItems: 'center', gap: 9,
                padding: '9px 14px', borderRadius: 8, fontSize: 13,
                cursor: 'pointer', fontFamily: 'inherit', border: 'none', textAlign: 'left',
                background: tab === t.id ? 'rgba(200,241,53,0.08)' : 'transparent',
                color: tab === t.id ? '#c8f135' : 'rgba(255,255,255,0.5)',
                borderLeft: tab === t.id ? '2px solid #c8f135' : '2px solid transparent',
              }}>
                <span>{t.icon}</span>{t.label}
              </button>
            ))}
          </div>

          {/* Tab content */}
          <div>

            {/* PROFIL */}
            {tab === 'profile' && (
              <Card>
                <CardTitle>Mon profil</CardTitle>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 18, maxWidth: 480 }}>
                  <div>
                    <div style={lbl}>Nom</div>
                    <input value={name} onChange={e => setName(e.target.value)} placeholder="Jean Dupont" style={inp} />
                  </div>
                  <div>
                    <div style={lbl}>Email</div>
                    <input value={user?.email || ''} disabled style={{ ...inp, opacity: 0.5 }} />
                    <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', marginTop: 5 }}>L'email ne peut pas être modifié pour l'instant</div>
                  </div>
                  <div>
                    <div style={lbl}>Nouveau mot de passe</div>
                    <input type="password" placeholder="Laisser vide pour ne pas modifier" style={inp} />
                  </div>
                  <div>
                    <Btn variant="primary" onClick={saveProfile}>
                      {profileSaved ? '✓ Sauvegardé !' : 'Enregistrer les modifications'}
                    </Btn>
                  </div>
                </div>
              </Card>
            )}

            {/* BOUTIQUES */}
            {tab === 'shops' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                <Card>
                  <CardTitle>Connecter une boutique</CardTitle>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 16 }}>
                    <div>
                      <div style={lbl}>Nom de la boutique</div>
                      <input value={newShop.name} onChange={e => setNewShop(s => ({ ...s, name: e.target.value }))} placeholder="Ma boutique Shopify" style={inp} />
                    </div>
                    <div>
                      <div style={lbl}>Plateforme</div>
                      <select value={newShop.platform} onChange={e => setNewShop(s => ({ ...s, platform: e.target.value }))} style={inp}>
                        {PLATFORMS.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                      </select>
                    </div>
                    <div style={{ gridColumn: '1 / -1' }}>
                      <div style={lbl}>Clé API</div>
                      <input value={newShop.apiKey} onChange={e => setNewShop(s => ({ ...s, apiKey: e.target.value }))} placeholder="sk_..." style={inp} />
                      <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', marginTop: 5 }}>
                        {PLATFORMS.find(p => p.id === newShop.platform)?.doc}
                      </div>
                    </div>
                  </div>
                  <Btn variant="primary" onClick={addShop}>{shopSaving ? 'Connexion…' : '+ Connecter la boutique'}</Btn>
                </Card>

                {/* Liste des boutiques connectées */}
                <Card>
                  <CardTitle>Boutiques connectées ({shops.length})</CardTitle>
                  {shops.length === 0
                    ? <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.3)', padding: '20px 0', textAlign: 'center' }}>
                        Aucune boutique connectée. Ajoutez-en une ci-dessus.
                      </div>
                    : shops.map((s, i) => {
                      const platform = PLATFORMS.find(p => p.id === s.platform)
                      return (
                        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 0', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                          <div style={{ width: 10, height: 10, borderRadius: '50%', background: platform?.color || '#888', flexShrink: 0 }} />
                          <div style={{ flex: 1 }}>
                            <div style={{ fontSize: 13, fontWeight: 500 }}>{s.name}</div>
                            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.35)' }}>{platform?.name}</div>
                          </div>
                          <div style={{ fontSize: 11, color: '#64dc78' }}>● Connecté</div>
                          <button onClick={() => setShops(sh => sh.filter((_, j) => j !== i))} style={{ ...miniBtn, color: '#ff5050' }}>Retirer</button>
                        </div>
                      )
                    })
                  }
                </Card>

                {/* Guides par plateforme */}
                <Card>
                  <CardTitle>Guides de connexion</CardTitle>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 10 }}>
                    {PLATFORMS.map(p => (
                      <div key={p.id} style={{ padding: '14px', background: 'rgba(255,255,255,0.025)', borderRadius: 10, border: '1px solid rgba(255,255,255,0.07)' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                          <div style={{ width: 8, height: 8, borderRadius: '50%', background: p.color }} />
                          <div style={{ fontSize: 13, fontWeight: 500 }}>{p.name}</div>
                        </div>
                        <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.35)', lineHeight: 1.5 }}>{p.doc}</div>
                      </div>
                    ))}
                  </div>
                </Card>
              </div>
            )}

            {/* ENTREPÔTS */}
            {tab === 'warehouses' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                <Card>
                  <CardTitle>Ajouter un entrepôt</CardTitle>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 120px', gap: 14, marginBottom: 16 }}>
                    <div>
                      <div style={lbl}>Nom de l'entrepôt</div>
                      <input value={newWH.name} onChange={e => setNewWH(w => ({ ...w, name: e.target.value }))} placeholder="Entrepôt Mayotte" style={inp} />
                    </div>
                    <div>
                      <div style={lbl}>Pays (ISO)</div>
                      <input value={newWH.country} onChange={e => setNewWH(w => ({ ...w, country: e.target.value.toUpperCase() }))} placeholder="FR" maxLength={2} style={inp} />
                    </div>
                  </div>
                  <Btn variant="primary" onClick={addWarehouse}>+ Ajouter l'entrepôt</Btn>
                </Card>

                <Card>
                  <CardTitle>Mes entrepôts ({warehouses.length})</CardTitle>
                  {warehouses.map((w, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 0', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                      <div style={{ fontSize: 20 }}>🏭</div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 13, fontWeight: 500 }}>{w.name}</div>
                        <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.35)', marginTop: 2 }}>Pays : {w.country}</div>
                      </div>
                      <button onClick={() => setWarehouses(wh => wh.filter((_, j) => j !== i))} style={{ ...miniBtn, color: '#ff5050' }}>Retirer</button>
                    </div>
                  ))}
                </Card>
              </div>
            )}

            {/* BILLING */}
            {tab === 'billing' && (
              <Card>
                <CardTitle>Abonnement & facturation</CardTitle>
                <div style={{ display: 'flex', alignItems: 'center', gap: 20, padding: '20px', background: 'rgba(200,241,53,0.04)', border: '1px solid rgba(200,241,53,0.15)', borderRadius: 12, marginBottom: 24 }}>
                  <div style={{ fontSize: 32 }}>💳</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 16, fontWeight: 500 }}>Plan {user?.plan}</div>
                    <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.45)', marginTop: 4 }}>
                      Statut : {user?.subscriptionStatus === 'ACTIVE' ? '✓ Actif' : user?.subscriptionStatus}
                    </div>
                    {user?.currentPeriodEnd && (
                      <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.35)', marginTop: 4 }}>
                        Prochain renouvellement : {new Date(user.currentPeriodEnd).toLocaleDateString('fr-FR')}
                      </div>
                    )}
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    <Btn variant="primary" onClick={openBillingPortal}>Gérer l'abonnement</Btn>
                    <Btn variant="ghost" onClick={() => window.location.href = '/pricing'}>Changer de plan</Btn>
                  </div>
                </div>

                <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.35)', lineHeight: 1.8 }}>
                  <div>• Paiement sécurisé via Stripe</div>
                  <div>• Annulation à tout moment depuis le portail Stripe</div>
                  <div>• Factures disponibles dans le portail Stripe</div>
                  <div>• Support : support@omniflow.app</div>
                </div>
              </Card>
            )}

            {/* API */}
            {tab === 'api' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                <Card>
                  <CardTitle>Clé API OmniFlow</CardTitle>
                  <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.45)', marginBottom: 16, lineHeight: 1.6 }}>
                    Utilisez cette clé pour intégrer OmniFlow à vos propres outils. Disponible sur le plan Business et Enterprise.
                  </div>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 20 }}>
                    <input
                      readOnly
                      value={user?.plan === 'BUSINESS' || user?.plan === 'ENTERPRISE' ? 'omf_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx' : 'Plan Business requis'}
                      style={{ ...inp, fontFamily: 'monospace', fontSize: 12, color: user?.plan === 'BUSINESS' || user?.plan === 'ENTERPRISE' ? '#c8f135' : 'rgba(255,255,255,0.3)' }}
                    />
                    <Btn variant="ghost" small>Copier</Btn>
                    <Btn variant="ghost" small>Régénérer</Btn>
                  </div>
                  {user?.plan !== 'BUSINESS' && user?.plan !== 'ENTERPRISE' && (
                    <div style={{ padding: '12px 16px', background: 'rgba(255,180,50,0.08)', border: '1px solid rgba(255,180,50,0.2)', borderRadius: 10, fontSize: 13, color: '#ffb432' }}>
                      ⚠️ L'accès API nécessite le plan Business (149€/mois) ou Enterprise.
                      <button onClick={() => window.location.href = '/pricing'} style={{ background: 'none', border: 'none', color: '#c8f135', cursor: 'pointer', fontSize: 13, marginLeft: 8, fontFamily: 'inherit' }}>
                        Upgrader →
                      </button>
                    </div>
                  )}
                </Card>

                <Card>
                  <CardTitle>Webhooks</CardTitle>
                  <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.45)', marginBottom: 16 }}>
                    Recevez des événements en temps réel sur votre endpoint HTTPS.
                  </div>
                  <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
                    <input placeholder="https://votre-app.com/webhook/omniflow" style={{ ...inp, flex: 1 }} />
                    <Btn variant="primary" small>+ Ajouter</Btn>
                  </div>
                  <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.3)', lineHeight: 2 }}>
                    Événements disponibles : <code style={{ color: '#c8f135' }}>order.created</code> · <code style={{ color: '#c8f135' }}>stock.low</code> · <code style={{ color: '#c8f135' }}>shipment.updated</code> · <code style={{ color: '#c8f135' }}>subscription.changed</code>
                  </div>
                </Card>

                <Card>
                  <CardTitle>Documentation rapide</CardTitle>
                  <div style={{ fontFamily: 'monospace', fontSize: 12, color: '#c8f135', background: 'rgba(0,0,0,0.3)', padding: '16px', borderRadius: 10, lineHeight: 2 }}>
                    <div style={{ color: 'rgba(255,255,255,0.3)' }}># Récupérer les commandes</div>
                    <div>GET https://api.omniflow.app/v1/orders</div>
                    <div style={{ color: 'rgba(255,255,255,0.3)', marginTop: 8 }}># Headers requis</div>
                    <div>Authorization: Bearer omf_live_xxx</div>
                    <div style={{ color: 'rgba(255,255,255,0.3)', marginTop: 8 }}># Mettre à jour un stock</div>
                    <div>PATCH https://api.omniflow.app/v1/stocks/:id</div>
                  </div>
                </Card>
              </div>
            )}

          </div>
        </div>
      </DashboardLayout>
    </>
  )
}

const lbl: React.CSSProperties = { fontSize: 12, color: 'rgba(255,255,255,0.45)', marginBottom: 7, fontWeight: 500 }
const inp: React.CSSProperties = {
  width: '100%', padding: '9px 12px', borderRadius: 8,
  border: '1px solid rgba(255,255,255,0.1)', background: 'rgba(255,255,255,0.04)',
  color: '#fafaf8', fontSize: 13, fontFamily: 'inherit', outline: 'none',
}
const miniBtn: React.CSSProperties = {
  padding: '5px 12px', borderRadius: 100, fontSize: 11, cursor: 'pointer',
  fontFamily: 'inherit', border: '1px solid rgba(255,255,255,0.12)',
  background: 'transparent', color: 'rgba(255,255,255,0.55)',
}
