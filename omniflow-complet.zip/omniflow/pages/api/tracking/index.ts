import { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { requireAuth } from '../../../lib/auth'

export default requireAuth(async (req, res, authUser) => {

  if (req.method === 'GET') {
    const shipments = await prisma.shipment.findMany({
      where: { order: { shop: { userId: authUser.userId } } },
      include: {
        order: { include: { shop: true } },
        events: { orderBy: { happenedAt: 'desc' } },
      },
      orderBy: { createdAt: 'desc' },
    })
    return res.status(200).json(shipments)
  }

  // POST - créer une expédition pour une commande
  if (req.method === 'POST') {
    const { orderId, carrier, trackingNumber, estimatedDelivery } = req.body

    const order = await prisma.order.findFirst({
      where: { id: orderId, shop: { userId: authUser.userId } }
    })
    if (!order) return res.status(404).json({ error: 'Commande introuvable' })

    const shipment = await prisma.shipment.create({
      data: {
        orderId,
        carrier,
        trackingNumber,
        estimatedDelivery: estimatedDelivery ? new Date(estimatedDelivery) : null,
        shippedAt: new Date(),
        status: 'LABEL_CREATED',
        events: {
          create: {
            status: 'Étiquette créée',
            message: `Expédition créée via ${carrier}`,
          }
        }
      },
      include: { order: true, events: true },
    })

    // Mettre à jour le statut de la commande
    await prisma.order.update({
      where: { id: orderId },
      data: { status: 'SHIPPED' },
    })

    return res.status(201).json(shipment)
  }

  return res.status(405).end()
})
