import { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { requireAuth } from '../../../lib/auth'

export default requireAuth(async (req, res, authUser) => {

  if (req.method === 'GET') {
    const suppliers = await prisma.supplier.findMany({
      where: { userId: authUser.userId },
      orderBy: { createdAt: 'desc' },
    })
    return res.status(200).json(suppliers)
  }

  if (req.method === 'POST') {
    const { name, type, country, apiKey, email, notes } = req.body
    if (!name || !type) return res.status(400).json({ error: 'Nom et type requis' })

    const supplier = await prisma.supplier.create({
      data: { userId: authUser.userId, name, type, country, apiKey, email, notes },
    })
    return res.status(201).json(supplier)
  }

  return res.status(405).end()
})
