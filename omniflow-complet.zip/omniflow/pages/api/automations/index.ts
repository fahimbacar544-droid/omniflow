import { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { requireAuth } from '../../../lib/auth'

export default requireAuth(async (req, res, authUser) => {

  if (req.method === 'GET') {
    const automations = await prisma.automation.findMany({
      where: { userId: authUser.userId },
      orderBy: { createdAt: 'desc' },
    })
    return res.status(200).json(automations)
  }

  if (req.method === 'POST') {
    const { name, trigger, action } = req.body
    if (!name || !trigger || !action) return res.status(400).json({ error: 'Champs requis manquants' })

    const automation = await prisma.automation.create({
      data: {
        userId: authUser.userId,
        name,
        trigger: JSON.stringify(trigger),
        action: JSON.stringify(action),
      },
    })
    return res.status(201).json(automation)
  }

  return res.status(405).end()
})
