import { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { requireAuth } from '../../../lib/auth'

export default requireAuth(async (req, res, authUser) => {
  const { id } = req.query

  const automation = await prisma.automation.findFirst({
    where: { id: id as string, userId: authUser.userId }
  })
  if (!automation) return res.status(404).json({ error: 'Automation introuvable' })

  if (req.method === 'PATCH') {
    const updated = await prisma.automation.update({
      where: { id: id as string },
      data: req.body,
    })
    return res.status(200).json(updated)
  }

  if (req.method === 'DELETE') {
    await prisma.automation.delete({ where: { id: id as string } })
    return res.status(200).json({ ok: true })
  }

  return res.status(405).end()
})
