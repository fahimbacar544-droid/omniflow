import { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { requireAuth } from '../../../lib/auth'

export default requireAuth(async (req, res, authUser) => {

  // GET - liste tous les stocks avec produits et entrepôts
  if (req.method === 'GET') {
    const stocks = await prisma.stock.findMany({
      where: {
        product: { shop: { userId: authUser.userId } }
      },
      include: {
        product: { include: { shop: true } },
        warehouse: true,
      },
      orderBy: { product: { name: 'asc' } },
    })
    return res.status(200).json(stocks)
  }

  // POST - créer/mettre à jour un stock
  if (req.method === 'POST') {
    const { productId, warehouseId, quantity, reserved } = req.body

    // Vérifier que le produit appartient à l'user
    const product = await prisma.product.findFirst({
      where: { id: productId, shop: { userId: authUser.userId } }
    })
    if (!product) return res.status(404).json({ error: 'Produit introuvable' })

    const stock = await prisma.stock.upsert({
      where: { productId_warehouseId: { productId, warehouseId } },
      update: { quantity: quantity ?? 0, reserved: reserved ?? 0 },
      create: { productId, warehouseId, quantity: quantity ?? 0, reserved: reserved ?? 0 },
      include: { product: true, warehouse: true },
    })
    return res.status(200).json(stock)
  }

  return res.status(405).end()
})
