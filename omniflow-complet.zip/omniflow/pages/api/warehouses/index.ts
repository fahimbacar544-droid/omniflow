import { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { requireAuth } from '../../../lib/auth'

export default requireAuth(async (req, res, authUser) => {

  if (req.method === 'GET') {
    const warehouses = await prisma.warehouse.findMany({
      where: { userId: authUser.userId },
      include: { _count: { select: { stocks: true } } },
      orderBy: { createdAt: 'asc' },
    })
    return res.status(200).json(warehouses)
  }

  if (req.method === 'POST') {
    const { name, country, address } = req.body
    if (!name) return res.status(400).json({ error: 'Nom requis' })

    const wh = await prisma.warehouse.create({
      data: { userId: authUser.userId, name, country: country || 'FR', address },
    })
    return res.status(201).json(wh)
  }

  return res.status(405).end()
})
