import { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { requireAuth } from '../../../lib/auth'

export default requireAuth(async (req, res, authUser) => {

  if (req.method === 'GET') {
    const shops = await prisma.shop.findMany({
      where: { userId: authUser.userId },
      include: { _count: { select: { orders: true, products: true } } },
      orderBy: { createdAt: 'desc' },
    })
    return res.status(200).json(shops)
  }

  if (req.method === 'POST') {
    const { name, platform, url, apiKey } = req.body
    if (!name || !platform) return res.status(400).json({ error: 'Nom et plateforme requis' })

    const shop = await prisma.shop.create({
      data: { userId: authUser.userId, name, platform, url, apiKey },
    })
    return res.status(201).json(shop)
  }

  return res.status(405).end()
})
