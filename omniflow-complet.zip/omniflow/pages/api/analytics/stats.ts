import { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { requireAuth } from '../../../lib/auth'

export default requireAuth(async (req, res, authUser) => {
  if (req.method !== 'GET') return res.status(405).end()

  const now = new Date()
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)
  const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1)
  const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0)

  const [
    totalOrders,
    ordersThisMonth,
    ordersLastMonth,
    revenueThisMonth,
    revenueLastMonth,
    pendingOrders,
    shippedOrders,
    lowStockCount,
    totalProducts,
    recentOrders,
    ordersByStatus,
  ] = await Promise.all([
    prisma.order.count({ where: { shop: { userId: authUser.userId } } }),
    prisma.order.count({ where: { shop: { userId: authUser.userId }, createdAt: { gte: startOfMonth } } }),
    prisma.order.count({ where: { shop: { userId: authUser.userId }, createdAt: { gte: startOfLastMonth, lte: endOfLastMonth } } }),
    prisma.order.aggregate({ where: { shop: { userId: authUser.userId }, createdAt: { gte: startOfMonth } }, _sum: { total: true } }),
    prisma.order.aggregate({ where: { shop: { userId: authUser.userId }, createdAt: { gte: startOfLastMonth, lte: endOfLastMonth } }, _sum: { total: true } }),
    prisma.order.count({ where: { shop: { userId: authUser.userId }, status: 'PENDING' } }),
    prisma.order.count({ where: { shop: { userId: authUser.userId }, status: 'SHIPPED' } }),
    prisma.stock.count({ where: { product: { shop: { userId: authUser.userId } }, quantity: { lte: 5 } } }),
    prisma.product.count({ where: { shop: { userId: authUser.userId }, active: true } }),
    prisma.order.findMany({
      where: { shop: { userId: authUser.userId } },
      include: { shop: true, shipment: true },
      orderBy: { createdAt: 'desc' },
      take: 10,
    }),
    prisma.order.groupBy({
      by: ['status'],
      where: { shop: { userId: authUser.userId } },
      _count: true,
    }),
  ])

  const revThis = revenueThisMonth._sum.total || 0
  const revLast = revenueLastMonth._sum.total || 0
  const revDelta = revLast > 0 ? Math.round(((revThis - revLast) / revLast) * 100) : 0
  const orderDelta = ordersLastMonth > 0 ? Math.round(((ordersThisMonth - ordersLastMonth) / ordersLastMonth) * 100) : 0

  return res.status(200).json({
    totalOrders,
    ordersThisMonth,
    orderDelta,
    revenueThisMonth: revThis,
    revenueDelta: revDelta,
    pendingOrders,
    shippedOrders,
    lowStockCount,
    totalProducts,
    recentOrders,
    ordersByStatus,
  })
})
