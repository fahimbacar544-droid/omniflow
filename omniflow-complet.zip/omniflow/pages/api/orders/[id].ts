import { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { requireAuth } from '../../../lib/auth'

export default requireAuth(async (req, res, authUser) => {
  const { id } = req.query

  const order = await prisma.order.findFirst({
    where: { id: id as string, shop: { userId: authUser.userId } },
    include: { shipment: true, items: { include: { product: true } }, shop: true },
  })
  if (!order) return res.status(404).json({ error: 'Commande introuvable' })

  // GET - détail commande
  if (req.method === 'GET') return res.status(200).json(order)

  // PATCH - mettre à jour le statut
  if (req.method === 'PATCH') {
    const { status, notes } = req.body
    const updated = await prisma.order.update({
      where: { id: id as string },
      data: { ...(status && { status }), ...(notes !== undefined && { notes }) },
      include: { shipment: true, items: { include: { product: true } }, shop: true },
    })
    return res.status(200).json(updated)
  }

  // DELETE
  if (req.method === 'DELETE') {
    await prisma.order.delete({ where: { id: id as string } })
    return res.status(200).json({ ok: true })
  }

  return res.status(405).end()
})
