import { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { requireAuth } from '../../../lib/auth'

export default requireAuth(async (req, res, authUser) => {

  if (req.method === 'GET') {
    const { status, shopId, page = '1', limit = '50' } = req.query
    const skip = (parseInt(page as string) - 1) * parseInt(limit as string)

    const where: any = { shop: { userId: authUser.userId } }
    if (status) where.status = status
    if (shopId) where.shopId = shopId

    const [orders, total] = await Promise.all([
      prisma.order.findMany({
        where,
        include: {
          shop: true,
          items: { include: { product: true } },
          shipment: true,
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: parseInt(limit as string),
      }),
      prisma.order.count({ where }),
    ])

    return res.status(200).json({ orders, total, page: parseInt(page as string) })
  }

  if (req.method === 'POST') {
    const { shopId, customerName, customerEmail, customerAddress, customerCountry, total, currency, items, notes } = req.body

    // Vérifier que la boutique appartient à l'user
    const shop = await prisma.shop.findFirst({
      where: { id: shopId, userId: authUser.userId }
    })
    if (!shop) return res.status(404).json({ error: 'Boutique introuvable' })

    const order = await prisma.order.create({
      data: {
        shopId,
        customerName,
        customerEmail,
        customerAddress,
        customerCountry: customerCountry || 'FR',
        total: total || 0,
        currency: currency || 'EUR',
        notes,
        items: {
          create: (items || []).map((item: any) => ({
            productId: item.productId,
            quantity: item.quantity,
            price: item.price,
          })),
        },
      },
      include: { items: { include: { product: true } }, shop: true },
    })
    return res.status(201).json(order)
  }

  return res.status(405).end()
})
