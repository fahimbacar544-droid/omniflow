async function apiFetch(url: string, options?: RequestInit) {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  })
  const data = await res.json()
  if (!res.ok) throw new Error(data.error || 'Erreur serveur')
  return data
}

export const api = {
  // Auth
  register: (body: { name: string; email: string; password: string }) =>
    apiFetch('/api/auth/register', { method: 'POST', body: JSON.stringify(body) }),

  login: (body: { email: string; password: string }) =>
    apiFetch('/api/auth/login', { method: 'POST', body: JSON.stringify(body) }),

  logout: () =>
    apiFetch('/api/auth/me', { method: 'POST' }),

  // Stripe
  createCheckout: (plan: string) =>
    apiFetch('/api/stripe/checkout', { method: 'POST', body: JSON.stringify({ plan }) }),

  openPortal: () =>
    apiFetch('/api/stripe/portal', { method: 'POST' }),

  // Orders
  getOrders: (params?: Record<string, string>) => {
    const q = params ? '?' + new URLSearchParams(params).toString() : ''
    return apiFetch(`/api/orders${q}`)
  },
  createOrder: (body: Record<string, unknown>) =>
    apiFetch('/api/orders', { method: 'POST', body: JSON.stringify(body) }),
  updateOrder: (id: string, body: Record<string, unknown>) =>
    apiFetch(`/api/orders/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
  deleteOrder: (id: string) =>
    apiFetch(`/api/orders/${id}`, { method: 'DELETE' }),

  // Stocks
  createProduct: (body: Record<string, unknown>) =>
    apiFetch('/api/stocks', { method: 'POST', body: JSON.stringify(body) }),

  // Tracking
  createTracking: (body: Record<string, unknown>) =>
    apiFetch('/api/tracking', { method: 'POST', body: JSON.stringify(body) }),

  // Suppliers
  createSupplier: (body: Record<string, unknown>) =>
    apiFetch('/api/suppliers', { method: 'POST', body: JSON.stringify(body) }),

  // Automations
  createAutomation: (body: Record<string, unknown>) =>
    apiFetch('/api/automations', { method: 'POST', body: JSON.stringify(body) }),
  toggleAutomation: (id: string, active: boolean) =>
    apiFetch(`/api/automations/${id}`, { method: 'PATCH', body: JSON.stringify({ active }) }),
  deleteAutomation: (id: string) =>
    apiFetch(`/api/automations/${id}`, { method: 'DELETE' }),

  // Shops & Warehouses
  createShop: (body: Record<string, unknown>) =>
    apiFetch('/api/shops', { method: 'POST', body: JSON.stringify(body) }),
  createWarehouse: (body: Record<string, unknown>) =>
    apiFetch('/api/warehouses', { method: 'POST', body: JSON.stringify(body) }),
}
