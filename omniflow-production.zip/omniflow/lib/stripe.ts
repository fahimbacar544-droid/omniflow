import Stripe from 'stripe'

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-04-10',
  typescript: true,
})

export const PLANS = {
  STARTER: {
    name: 'Starter',
    price: 29,
    priceId: process.env.STRIPE_PRICE_STARTER!,
    features: ['1 boutique', '300 commandes/mois', 'Tracking simple', 'Support email'],
    limits: { shops: 1, orders: 300 },
  },
  PRO: {
    name: 'Pro',
    price: 79,
    priceId: process.env.STRIPE_PRICE_PRO!,
    features: ['3 boutiques', '2 000 commandes/mois', 'Auto fournisseurs', 'Multi-entrepôts'],
    limits: { shops: 3, orders: 2000 },
  },
  BUSINESS: {
    name: 'Business',
    price: 149,
    priceId: process.env.STRIPE_PRICE_BUSINESS!,
    features: ['Boutiques illimitées', 'IA avancée', 'Multi-plateformes', 'Support 24/7'],
    limits: { shops: -1, orders: -1 },
  },
  ENTERPRISE: {
    name: 'Enterprise',
    price: 499,
    priceId: process.env.STRIPE_PRICE_ENTERPRISE!,
    features: ['API privée', 'SLA 99.99%', 'Account manager', 'Onboarding dédié'],
    limits: { shops: -1, orders: -1 },
  },
} as const

export type PlanKey = keyof typeof PLANS

export function getPlanFromPriceId(priceId: string): PlanKey | null {
  for (const [key, plan] of Object.entries(PLANS)) {
    if (plan.priceId === priceId) return key as PlanKey
  }
  return null
}
