import useSWR from 'swr'
import { useRouter } from 'next/router'
import { useEffect } from 'react'

const fetcher = (url: string) =>
  fetch(url).then(r => {
    if (!r.ok) throw new Error('Fetch error')
    return r.json()
  })

export function useUser() {
  const { data, error, mutate } = useSWR('/api/auth/me', fetcher, {
    revalidateOnFocus: false,
    shouldRetryOnError: false,
  })
  return {
    user: data?.user,
    loading: !data && !error,
    error,
    mutate,
  }
}

export function useRequireAuth() {
  const { user, loading } = useUser()
  const router = useRouter()
  useEffect(() => {
    if (!loading && !user) router.replace('/login')
  }, [user, loading, router])
  return { user, loading }
}

export function useRequireNoAuth() {
  const { user, loading } = useUser()
  const router = useRouter()
  useEffect(() => {
    if (!loading && user) router.replace('/dashboard')
  }, [user, loading, router])
  return { user, loading }
}

export function useOrders(params?: Record<string, string>) {
  const query = params ? '?' + new URLSearchParams(params).toString() : ''
  return useSWR(`/api/orders${query}`, fetcher)
}

export function useStocks() {
  return useSWR('/api/stocks', fetcher)
}

export function useTrackings() {
  return useSWR('/api/tracking', fetcher)
}

export function useSuppliers() {
  return useSWR('/api/suppliers', fetcher)
}

export function useAutomations() {
  return useSWR('/api/automations', fetcher)
}

export function useAnalytics() {
  return useSWR('/api/analytics/stats', fetcher, {
    refreshInterval: 60000, // refresh every 60s
  })
}

export function useShops() {
  return useSWR('/api/shops', fetcher)
}

export function useWarehouses() {
  return useSWR('/api/warehouses', fetcher)
}
