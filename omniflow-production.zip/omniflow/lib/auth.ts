import jwt from 'jsonwebtoken'
import bcrypt from 'bcryptjs'
import { serialize, parse } from 'cookie'
import type { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from './prisma'

const JWT_SECRET = process.env.JWT_SECRET!
const COOKIE_NAME = 'omniflow_token'

export interface JWTPayload {
  userId: string
  email: string
  name: string
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12)
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash)
}

export function signToken(payload: JWTPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' })
}

export function verifyToken(token: string): JWTPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as JWTPayload
  } catch {
    return null
  }
}

export function setAuthCookie(res: NextApiResponse, token: string) {
  res.setHeader('Set-Cookie', serialize(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 60 * 60 * 24 * 7, // 7 days
    path: '/',
  }))
}

export function clearAuthCookie(res: NextApiResponse) {
  res.setHeader('Set-Cookie', serialize(COOKIE_NAME, '', {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 0,
    path: '/',
  }))
}

export function getTokenFromRequest(req: NextApiRequest): string | null {
  const cookies = parse(req.headers.cookie || '')
  return cookies[COOKIE_NAME] || null
}

export async function requireAuth(req: NextApiRequest, res: NextApiResponse) {
  const token = getTokenFromRequest(req)
  if (!token) {
    res.status(401).json({ error: 'Non authentifié' })
    return null
  }
  const payload = verifyToken(token)
  if (!payload) {
    res.status(401).json({ error: 'Session expirée' })
    return null
  }
  const user = await prisma.user.findUnique({
    where: { id: payload.userId },
    include: { subscription: true },
  })
  if (!user) {
    res.status(401).json({ error: 'Utilisateur introuvable' })
    return null
  }
  return user
}
