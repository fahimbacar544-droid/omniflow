import { useEffect, useState, createContext, useContext, useCallback, ReactNode } from 'react'

interface ToastMsg { id: number; icon: string; text: string }

const ToastCtx = createContext<(icon: string, text: string) => void>(() => {})

export function useToast() { return useContext(ToastCtx) }

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastMsg[]>([])
  let counter = 0

  const show = useCallback((icon: string, text: string) => {
    const id = ++counter
    setToasts(t => [...t, { id, icon, text }])
    setTimeout(() => setToasts(t => t.filter(m => m.id !== id)), 3500)
  }, [])

  return (
    <ToastCtx.Provider value={show}>
      {children}
      <div style={{ position: 'fixed', bottom: 24, right: 24, zIndex: 9999, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {toasts.map(t => (
          <div key={t.id} className="toast">
            <span style={{ fontSize: 16 }}>{t.icon}</span>
            <span>{t.text}</span>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  )
}
