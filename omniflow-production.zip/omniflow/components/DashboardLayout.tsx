import { useRouter } from 'next/router'
import { useUser } from '../lib/hooks'
import { api } from '../lib/api'
import { useToast } from './Toast'
import { ReactNode } from 'react'

const NAV = [
  { id: 'overview',     label: 'Vue d\'ensemble', icon: '⊞', href: '/dashboard' },
  { id: 'orders',       label: 'Commandes',       icon: '📋', href: '/dashboard/orders' },
  { id: 'stocks',       label: 'Stocks',           icon: '📦', href: '/dashboard/stocks' },
  { id: 'tracking',     label: 'Tracking',         icon: '🚚', href: '/dashboard/tracking' },
  { id: 'suppliers',    label: 'Fournisseurs',     icon: '🤝', href: '/dashboard/suppliers' },
  { id: 'automation',   label: 'Automatisation',   icon: '⚡', href: '/dashboard/automation' },
  { id: 'ai',           label: 'IA & Prévisions',  icon: '🤖', href: '/dashboard/ai' },
  { id: 'analytics',    label: 'Analytics',        icon: '📊', href: '/dashboard/analytics' },
  { id: 'integrations', label: 'Intégrations',     icon: '🔌', href: '/dashboard/integrations' },
  { id: 'settings',     label: 'Paramètres',       icon: '⚙',  href: '/dashboard/settings' },
]

const PLAN_LABELS: Record<string, string> = {
  STARTER: 'Starter — 29€/mois',
  PRO: 'Pro — 79€/mois',
  BUSINESS: 'Business — 149€/mois',
  ENTERPRISE: 'Enterprise — 499€/mois',
}

interface Props {
  children: ReactNode
  title: string
  subtitle?: string
  active: string
  actions?: ReactNode
}

export default function DashboardLayout({ children, title, subtitle, active, actions }: Props) {
  const router = useRouter()
  const { user } = useUser()
  const toast = useToast()

  async function handleLogout() {
    await fetch('/api/auth/me', { method: 'POST' })
    router.push('/')
  }

  const planLabel = user?.plan ? PLAN_LABELS[user.plan] || user.plan : 'Aucun plan'
  const initials = user?.name ? user.name.charAt(0).toUpperCase() : '?'

  return (
    <div className="dash-layout">
      {/* SIDEBAR */}
      <div className="dash-sidebar">
        <div className="sidebar-logo">
          Omni<span>Flow</span>
        </div>

        {user?.plan && (
          <div className="sidebar-plan">
            <div className="plan-label">Votre plan</div>
            <div className="plan-name">{planLabel.split(' —')[0]}</div>
          </div>
        )}

        <nav className="sidebar-nav">
          {NAV.map(item => (
            <a
              key={item.id}
              className={`nav-item${active === item.id ? ' active' : ''}`}
              onClick={() => router.push(item.href)}
            >
              <span className="nav-item-icon">{item.icon}</span>
              {item.label}
            </a>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="user-chip">
            <div className="user-avatar">{initials}</div>
            <span className="user-name">{user?.name || user?.email || '...'}</span>
            <span className="user-logout" onClick={handleLogout} title="Déconnexion">⏻</span>
          </div>
        </div>
      </div>

      {/* MAIN */}
      <div className="dash-main">
        <div className="dash-header">
          <div>
            <div className="dash-title">{title}</div>
            {subtitle && <div className="dash-subtitle">{subtitle}</div>}
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            {actions}
          </div>
        </div>
        <div className="dash-content">{children}</div>
      </div>
    </div>
  )
}
