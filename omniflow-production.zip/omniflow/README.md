# OmniFlow — Guide de déploiement complet

## Résultat final
Une vraie application SaaS e-commerce avec :
- Auth sécurisée (email + mot de passe, JWT httpOnly)
- Paiements Stripe réels (Checkout → Webhook → activation plan)
- Base de données PostgreSQL (Supabase gratuit)
- Dashboard complet : commandes, stocks, tracking, fournisseurs, IA, analytics
- Page tracking publique (`/t/[slug]`)
- Déploiement Vercel gratuit

---

## ÉTAPE 1 — Créer la base de données (Supabase) — 5 min

1. Allez sur **https://supabase.com** → "Start for free"
2. Créez un projet (choisissez Europe comme région)
3. Dans votre projet → **Settings** → **Database**
4. Copiez ces deux URLs :
   - **Connection string (Transaction)** → `DATABASE_URL`
   - **Connection string (Session)** → `DIRECT_URL`
5. Remplacez `[YOUR-PASSWORD]` par le mot de passe que vous avez choisi

---

## ÉTAPE 2 — Configurer Stripe — 5 min

### Créer les produits Stripe :
1. Allez sur **https://dashboard.stripe.com/products**
2. Créez 4 produits avec abonnement mensuel :
   | Produit    | Prix/mois |
   |------------|-----------|
   | Starter    | 29€       |
   | Pro        | 79€       |
   | Business   | 149€      |
   | Enterprise | 499€      |
3. Copiez l'**ID de prix** (`price_xxx`) de chaque produit

### Récupérer vos clés API :
1. **https://dashboard.stripe.com/apikeys**
2. Copiez `Publishable key` (pk_live_xxx) et `Secret key` (sk_live_xxx)

### Configurer le webhook :
1. **https://dashboard.stripe.com/webhooks** → "Add endpoint"
2. URL : `https://VOTRE-APP.vercel.app/api/webhooks/stripe`
3. Événements à écouter :
   - `checkout.session.completed`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_failed`
4. Copiez le **Signing secret** (`whsec_xxx`)

---

## ÉTAPE 3 — Déployer sur Vercel — 5 min

1. Allez sur **https://vercel.com** → "New Project"
2. Importez ce projet depuis GitHub (ou uploadez le ZIP)
3. Dans **Environment Variables**, ajoutez toutes ces variables :

```
DATABASE_URL=postgresql://postgres.[ref]:[password]@aws-0-eu-central-1.pooler.supabase.com:6543/postgres?pgbouncer=true
DIRECT_URL=postgresql://postgres.[ref]:[password]@aws-0-eu-central-1.pooler.supabase.com:5432/postgres
JWT_SECRET=un-secret-aleatoire-minimum-32-caracteres-ex-abc123xyz456
STRIPE_SECRET_KEY=sk_live_xxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxx
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_xxxxx
STRIPE_PRICE_STARTER=price_xxxxx
STRIPE_PRICE_PRO=price_xxxxx
STRIPE_PRICE_BUSINESS=price_xxxxx
STRIPE_PRICE_ENTERPRISE=price_xxxxx
NEXT_PUBLIC_APP_URL=https://omniflow.vercel.app
```

4. Cliquez **Deploy** → attendez 2-3 minutes

---

## ÉTAPE 4 — Initialiser la base de données — 1 min

Après le premier déploiement, dans Vercel :
1. Allez dans votre projet → **Functions** → **Run a query** (ou utilisez le terminal Supabase)
2. Ou dans le dashboard Supabase → **SQL Editor**, exécutez le schéma Prisma

Alternative avec Vercel CLI :
```bash
npx vercel env pull .env.local
npx prisma db push
```

---

## ÉTAPE 5 — Tester les paiements

1. Allez sur votre app → cliquez "Commencer" sur un plan
2. Créez un compte
3. Vous serez redirigé vers Stripe Checkout (vrai paiement)
4. Après paiement → webhook → plan activé automatiquement
5. Accès immédiat au dashboard complet

---

## Architecture technique

```
omniflow/
├── pages/
│   ├── index.tsx              # Landing page
│   ├── register.tsx           # Inscription
│   ├── login.tsx              # Connexion
│   ├── checkout.tsx           # Paiement Stripe
│   ├── t/[slug].tsx           # Tracking public
│   ├── api/
│   │   ├── auth/              # register, login, me
│   │   ├── stripe/            # checkout, portal
│   │   ├── webhooks/stripe.ts # Webhook Stripe (activation plan)
│   │   ├── orders/            # CRUD commandes
│   │   ├── stocks/            # CRUD produits/stocks
│   │   ├── tracking/          # CRUD + page publique
│   │   ├── suppliers/         # CRUD fournisseurs
│   │   ├── automations/       # CRUD + toggle
│   │   ├── shops/             # CRUD boutiques
│   │   ├── warehouses/        # CRUD entrepôts
│   │   └── analytics/stats.ts # Stats réelles DB
│   └── dashboard/
│       ├── index.tsx          # Vue d'ensemble
│       ├── orders.tsx         # Commandes
│       ├── stocks.tsx         # Stocks multi-entrepôts
│       ├── tracking.tsx       # Tracking
│       ├── suppliers.tsx      # Fournisseurs
│       ├── automation.tsx     # Règles auto
│       ├── ai.tsx             # Insights IA
│       ├── analytics.tsx      # Analytics
│       ├── integrations.tsx   # Connecteurs
│       └── settings.tsx       # Paramètres + Stripe portal
├── lib/
│   ├── prisma.ts              # Client DB singleton
│   ├── auth.ts                # JWT + bcrypt + cookies
│   ├── stripe.ts              # Config Stripe + plans
│   ├── hooks.ts               # SWR data hooks
│   └── api.ts                 # Client API frontend
├── components/
│   ├── DashboardLayout.tsx    # Sidebar + layout
│   └── Toast.tsx              # Notifications
├── prisma/schema.prisma       # Schéma DB complet
├── styles/globals.css         # Design system complet
├── .env.example               # Variables à remplir
└── vercel.json                # Config déploiement
```

---

## Support

Pour toute question sur le déploiement ou les intégrations API (Shopify, Amazon, AfterShip), revenez sur OmniFlow.
