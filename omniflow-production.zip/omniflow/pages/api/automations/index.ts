import type { NextApiRequest, NextApiResponse } from 'next'
import { requireAuth } from '../../../lib/auth'
import { prisma } from '../../../lib/prisma'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const user = await requireAuth(req, res)
  if (!user) return

  if (req.method === 'GET') {
    const automations = await prisma.automation.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
    })
    return res.status(200).json({ automations })
  }

  if (req.method === 'POST') {
    const { name, description, trigger, action, conditions } = req.body
    if (!name || !trigger || !action) {
      return res.status(400).json({ error: 'Nom, déclencheur et action requis' })
    }
    const automation = await prisma.automation.create({
      data: { userId: user.id, name, description, trigger, action, conditions },
    })
    return res.status(201).json({ automation })
  }

  return res.status(405).end()
}
