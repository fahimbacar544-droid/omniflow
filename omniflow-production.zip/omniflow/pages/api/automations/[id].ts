import type { NextApiRequest, NextApiResponse } from 'next'
import { requireAuth } from '../../../lib/auth'
import { prisma } from '../../../lib/prisma'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const user = await requireAuth(req, res)
  if (!user) return

  const { id } = req.query as { id: string }

  const automation = await prisma.automation.findFirst({ where: { id, userId: user.id } })
  if (!automation) return res.status(404).json({ error: 'Automation introuvable' })

  if (req.method === 'PATCH') {
    const { active, name, description, trigger, action, conditions } = req.body
    const updated = await prisma.automation.update({
      where: { id },
      data: {
        ...(active !== undefined && { active }),
        ...(name && { name }),
        ...(description !== undefined && { description }),
        ...(trigger && { trigger }),
        ...(action && { action }),
        ...(conditions !== undefined && { conditions }),
      },
    })
    return res.status(200).json({ automation: updated })
  }

  if (req.method === 'DELETE') {
    await prisma.automation.delete({ where: { id } })
    return res.status(200).json({ ok: true })
  }

  return res.status(405).end()
}
