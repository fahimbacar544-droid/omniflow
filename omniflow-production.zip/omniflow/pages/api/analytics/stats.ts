import type { NextApiRequest, NextApiResponse } from 'next'
import { requireAuth } from '../../../lib/auth'
import { prisma } from '../../../lib/prisma'
import { startOfDay, subDays, startOfMonth } from 'date-fns'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') return res.status(405).end()
  const user = await requireAuth(req, res)
  if (!user) return

  const now = new Date()
  const todayStart = startOfDay(now)
  const monthStart = startOfMonth(now)
  const last7 = subDays(now, 7)

  const [
    ordersToday,
    ordersMonth,
    revenueToday,
    revenueMonth,
    ordersInTransit,
    ordersPending,
    ordersDelivered,
    lowStockProducts,
    last7DaysOrders,
    platformBreakdown,
  ] = await Promise.all([
    prisma.order.count({ where: { userId: user.id, createdAt: { gte: todayStart } } }),
    prisma.order.count({ where: { userId: user.id, createdAt: { gte: monthStart } } }),
    prisma.order.aggregate({ where: { userId: user.id, createdAt: { gte: todayStart } }, _sum: { totalAmount: true } }),
    prisma.order.aggregate({ where: { userId: user.id, createdAt: { gte: monthStart } }, _sum: { totalAmount: true } }),
    prisma.order.count({ where: { userId: user.id, status: 'IN_TRANSIT' } }),
    prisma.order.count({ where: { userId: user.id, status: 'PENDING' } }),
    prisma.order.count({ where: { userId: user.id, status: 'DELIVERED' } }),
    prisma.productStock.findMany({
      where: { product: { userId: user.id } },
      include: { product: true, warehouse: true },
    }),
    prisma.order.groupBy({
      by: ['createdAt'],
      where: { userId: user.id, createdAt: { gte: last7 } },
      _count: true,
      _sum: { totalAmount: true },
    }),
    prisma.order.groupBy({
      by: ['platform'],
      where: { userId: user.id, createdAt: { gte: monthStart } },
      _count: true,
      _sum: { totalAmount: true },
    }),
  ])

  // Build daily revenue for last 7 days
  const dailyRevenue: Record<string, number> = {}
  for (let i = 6; i >= 0; i--) {
    const d = subDays(now, i)
    const key = d.toISOString().split('T')[0]
    dailyRevenue[key] = 0
  }
  last7DaysOrders.forEach(row => {
    const key = new Date(row.createdAt).toISOString().split('T')[0]
    if (key in dailyRevenue) dailyRevenue[key] += row._sum.totalAmount ?? 0
  })

  // Low stock
  const criticalStocks = lowStockProducts
    .filter(s => s.quantity <= s.minLevel)
    .map(s => ({
      productName: s.product.name,
      sku: s.product.sku,
      quantity: s.quantity,
      minLevel: s.minLevel,
      warehouseName: s.warehouse.name,
      isRupture: s.quantity === 0,
    }))

  return res.status(200).json({
    kpis: {
      ordersToday,
      ordersMonth,
      revenueToday: revenueToday._sum.totalAmount ?? 0,
      revenueMonth: revenueMonth._sum.totalAmount ?? 0,
      ordersInTransit,
      ordersPending,
      ordersDelivered,
      ruptureCount: criticalStocks.filter(s => s.isRupture).length,
      lowStockCount: criticalStocks.length,
    },
    dailyRevenue,
    platformBreakdown: platformBreakdown.map(p => ({
      platform: p.platform,
      count: p._count,
      revenue: p._sum.totalAmount ?? 0,
    })),
    criticalStocks,
  })
}
