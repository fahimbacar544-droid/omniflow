import type { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { hashPassword, signToken, setAuthCookie } from '../../../lib/auth'
import { stripe } from '../../../lib/stripe'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()

  const { name, email, password } = req.body

  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Tous les champs sont requis' })
  }
  if (password.length < 8) {
    return res.status(400).json({ error: 'Mot de passe trop court (8 caractères minimum)' })
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: 'Email invalide' })
  }

  const existing = await prisma.user.findUnique({ where: { email: email.toLowerCase() } })
  if (existing) {
    return res.status(409).json({ error: 'Cet email est déjà utilisé' })
  }

  // Create Stripe customer
  let stripeCustomerId: string | undefined
  try {
    const customer = await stripe.customers.create({ email: email.toLowerCase(), name })
    stripeCustomerId = customer.id
  } catch (err) {
    console.error('Stripe customer creation failed:', err)
  }

  const passwordHash = await hashPassword(password)

  const user = await prisma.user.create({
    data: {
      name,
      email: email.toLowerCase(),
      passwordHash,
      stripeCustomerId,
    },
  })

  const token = signToken({ userId: user.id, email: user.email, name: user.name })
  setAuthCookie(res, token)

  return res.status(201).json({
    user: { id: user.id, name: user.name, email: user.email },
  })
}
