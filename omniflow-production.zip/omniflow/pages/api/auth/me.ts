import type { NextApiRequest, NextApiResponse } from 'next'
import { clearAuthCookie, requireAuth } from '../../../lib/auth'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    clearAuthCookie(res)
    return res.status(200).json({ ok: true })
  }
  if (req.method === 'GET') {
    const user = await requireAuth(req, res)
    if (!user) return
    return res.status(200).json({
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        plan: (user as any).subscription?.plan ?? null,
        subscriptionStatus: (user as any).subscription?.status ?? null,
      },
    })
  }
  return res.status(405).end()
}
