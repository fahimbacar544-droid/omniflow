import type { NextApiRequest, NextApiResponse } from 'next'
import { Readable } from 'stream'
import Stripe from 'stripe'
import { stripe, getPlanFromPriceId } from '../../../lib/stripe'
import { prisma } from '../../../lib/prisma'
import { Plan, SubStatus } from '@prisma/client'

export const config = { api: { bodyParser: false } }

async function buffer(readable: Readable) {
  const chunks: Buffer[] = []
  for await (const chunk of readable) {
    chunks.push(typeof chunk === 'string' ? Buffer.from(chunk) : chunk)
  }
  return Buffer.concat(chunks)
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()

  const buf = await buffer(req)
  const sig = req.headers['stripe-signature']!

  let event: Stripe.Event
  try {
    event = stripe.webhooks.constructEvent(buf, sig, process.env.STRIPE_WEBHOOK_SECRET!)
  } catch (err: any) {
    console.error('Webhook signature verification failed:', err.message)
    return res.status(400).json({ error: `Webhook Error: ${err.message}` })
  }

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.Checkout.Session
      await handleCheckoutCompleted(session)
      break
    }
    case 'customer.subscription.updated': {
      const sub = event.data.object as Stripe.Subscription
      await handleSubscriptionUpdated(sub)
      break
    }
    case 'customer.subscription.deleted': {
      const sub = event.data.object as Stripe.Subscription
      await handleSubscriptionDeleted(sub)
      break
    }
    case 'invoice.payment_failed': {
      const invoice = event.data.object as Stripe.Invoice
      await handlePaymentFailed(invoice)
      break
    }
  }

  return res.status(200).json({ received: true })
}

async function handleCheckoutCompleted(session: Stripe.Checkout.Session) {
  const userId = session.metadata?.userId
  if (!userId || !session.subscription) return

  const stripeSub = await stripe.subscriptions.retrieve(session.subscription as string)
  const priceId = stripeSub.items.data[0]?.price.id
  const planKey = getPlanFromPriceId(priceId)
  if (!planKey) return

  // Update Stripe customer ID on user
  if (session.customer) {
    await prisma.user.update({
      where: { id: userId },
      data: { stripeCustomerId: session.customer as string },
    })
  }

  await prisma.subscription.upsert({
    where: { userId },
    create: {
      userId,
      stripeSubscriptionId: stripeSub.id,
      stripePriceId: priceId,
      plan: planKey as Plan,
      status: SubStatus.ACTIVE,
      currentPeriodEnd: new Date(stripeSub.current_period_end * 1000),
    },
    update: {
      stripeSubscriptionId: stripeSub.id,
      stripePriceId: priceId,
      plan: planKey as Plan,
      status: SubStatus.ACTIVE,
      currentPeriodEnd: new Date(stripeSub.current_period_end * 1000),
    },
  })
}

async function handleSubscriptionUpdated(sub: Stripe.Subscription) {
  const existing = await prisma.subscription.findUnique({
    where: { stripeSubscriptionId: sub.id },
  })
  if (!existing) return

  const priceId = sub.items.data[0]?.price.id
  const planKey = getPlanFromPriceId(priceId)

  const statusMap: Record<string, SubStatus> = {
    active: SubStatus.ACTIVE,
    past_due: SubStatus.PAST_DUE,
    canceled: SubStatus.CANCELED,
    trialing: SubStatus.TRIALING,
  }

  await prisma.subscription.update({
    where: { stripeSubscriptionId: sub.id },
    data: {
      plan: planKey ? (planKey as Plan) : existing.plan,
      stripePriceId: priceId || existing.stripePriceId,
      status: statusMap[sub.status] ?? existing.status,
      currentPeriodEnd: new Date(sub.current_period_end * 1000),
      cancelAtPeriodEnd: sub.cancel_at_period_end,
    },
  })
}

async function handleSubscriptionDeleted(sub: Stripe.Subscription) {
  await prisma.subscription.updateMany({
    where: { stripeSubscriptionId: sub.id },
    data: { status: SubStatus.CANCELED },
  })
}

async function handlePaymentFailed(invoice: Stripe.Invoice) {
  if (!invoice.subscription) return
  await prisma.subscription.updateMany({
    where: { stripeSubscriptionId: invoice.subscription as string },
    data: { status: SubStatus.PAST_DUE },
  })
}
