import type { NextApiRequest, NextApiResponse } from 'next'
import { requireAuth } from '../../../lib/auth'
import { stripe, PLANS, PlanKey } from '../../../lib/stripe'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()

  const user = await requireAuth(req, res)
  if (!user) return

  const { plan } = req.body as { plan: PlanKey }
  const planConfig = PLANS[plan]
  if (!planConfig) {
    return res.status(400).json({ error: 'Plan invalide' })
  }

  const appUrl = process.env.NEXT_PUBLIC_APP_URL

  const session = await stripe.checkout.sessions.create({
    customer: user.stripeCustomerId ?? undefined,
    customer_email: user.stripeCustomerId ? undefined : user.email,
    mode: 'subscription',
    payment_method_types: ['card'],
    line_items: [{ price: planConfig.priceId, quantity: 1 }],
    success_url: `${appUrl}/dashboard?success=1&plan=${plan}`,
    cancel_url: `${appUrl}/pricing?canceled=1`,
    subscription_data: {
      metadata: { userId: user.id, plan },
    },
    metadata: { userId: user.id, plan },
    allow_promotion_codes: true,
    billing_address_collection: 'auto',
    locale: 'fr',
  })

  return res.status(200).json({ url: session.url })
}
