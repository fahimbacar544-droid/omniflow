import type { NextApiRequest, NextApiResponse } from 'next'
import { requireAuth } from '../../../lib/auth'
import { prisma } from '../../../lib/prisma'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const user = await requireAuth(req, res)
  if (!user) return

  if (req.method === 'GET') {
    const trackings = await prisma.tracking.findMany({
      where: { userId: user.id },
      include: {
        events: { orderBy: { occurredAt: 'desc' }, take: 1 },
        order: { select: { customerName: true, id: true } },
      },
      orderBy: { updatedAt: 'desc' },
    })
    return res.status(200).json({ trackings })
  }

  if (req.method === 'POST') {
    const { trackingNumber, carrier, orderId } = req.body
    if (!trackingNumber || !carrier) {
      return res.status(400).json({ error: 'Numéro de suivi et transporteur requis' })
    }

    const tracking = await prisma.tracking.create({
      data: {
        userId: user.id,
        trackingNumber,
        carrier,
        orderId: orderId || null,
        events: {
          create: { event: 'Colis enregistré', location: 'OmniFlow' },
        },
      },
      include: { events: true },
    })
    return res.status(201).json({ tracking })
  }

  return res.status(405).end()
}
