import type { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'

// Public endpoint - no auth required
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') return res.status(405).end()

  const { slug } = req.query as { slug: string }

  const tracking = await prisma.tracking.findUnique({
    where: { publicSlug: slug },
    include: {
      events: { orderBy: { occurredAt: 'asc' } },
      order: { select: { customerName: true, items: { select: { name: true, quantity: true } } } },
    },
  })

  if (!tracking) {
    return res.status(404).json({ error: 'Suivi introuvable' })
  }

  return res.status(200).json({
    tracking: {
      trackingNumber: tracking.trackingNumber,
      carrier: tracking.carrier,
      status: tracking.status,
      currentEvent: tracking.currentEvent,
      estimatedDate: tracking.estimatedDate,
      deliveredAt: tracking.deliveredAt,
      events: tracking.events,
      order: tracking.order,
    },
  })
}
