import type { NextApiRequest, NextApiResponse } from 'next'
import { requireAuth } from '../../../lib/auth'
import { prisma } from '../../../lib/prisma'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const user = await requireAuth(req, res)
  if (!user) return

  if (req.method === 'GET') {
    const products = await prisma.product.findMany({
      where: { userId: user.id },
      include: {
        stocks: { include: { warehouse: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    const enriched = products.map(p => {
      const totalStock = p.stocks.reduce((sum, s) => sum + s.quantity, 0)
      const minLevel = p.stocks.reduce((min, s) => Math.min(min, s.minLevel), 10)
      const status = totalStock === 0 ? 'RUPTURE' : totalStock <= minLevel ? 'BAS' : 'OK'
      return { ...p, totalStock, status }
    })

    return res.status(200).json({ products: enriched })
  }

  if (req.method === 'POST') {
    const { name, sku, description, costPrice, sellPrice, weight, warehouseId, quantity, minLevel } = req.body
    if (!name || !sku) return res.status(400).json({ error: 'Nom et SKU requis' })

    const product = await prisma.product.create({
      data: {
        userId: user.id,
        name,
        sku,
        description,
        costPrice: costPrice ? Number(costPrice) : null,
        sellPrice: sellPrice ? Number(sellPrice) : null,
        weight: weight ? Number(weight) : null,
        stocks: warehouseId ? {
          create: { warehouseId, quantity: Number(quantity) || 0, minLevel: Number(minLevel) || 10 },
        } : undefined,
      },
      include: { stocks: { include: { warehouse: true } } },
    })
    return res.status(201).json({ product })
  }

  return res.status(405).end()
}
