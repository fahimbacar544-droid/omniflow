import type { NextApiRequest, NextApiResponse } from 'next'
import { requireAuth } from '../../../lib/auth'
import { prisma } from '../../../lib/prisma'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const user = await requireAuth(req, res)
  if (!user) return

  if (req.method === 'GET') {
    const shops = await prisma.shop.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
    })
    return res.status(200).json({ shops })
  }

  if (req.method === 'POST') {
    const { name, platform, url, apiKey, apiSecret } = req.body
    if (!name || !platform) return res.status(400).json({ error: 'Nom et plateforme requis' })

    const shop = await prisma.shop.create({
      data: { userId: user.id, name, platform, url, apiKey, apiSecret },
    })
    return res.status(201).json({ shop })
  }

  return res.status(405).end()
}
