import type { NextApiRequest, NextApiResponse } from 'next'
import { requireAuth } from '../../../lib/auth'
import { prisma } from '../../../lib/prisma'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const user = await requireAuth(req, res)
  if (!user) return

  if (req.method === 'GET') {
    const suppliers = await prisma.supplier.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
    })
    return res.status(200).json({ suppliers })
  }

  if (req.method === 'POST') {
    const { name, type, apiKey, website, email, phone, country } = req.body
    if (!name) return res.status(400).json({ error: 'Nom requis' })

    const supplier = await prisma.supplier.create({
      data: { userId: user.id, name, type: type || 'DROPSHIPPING', apiKey, website, email, phone, country },
    })
    return res.status(201).json({ supplier })
  }

  return res.status(405).end()
}
