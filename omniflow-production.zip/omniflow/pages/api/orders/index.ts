import type { NextApiRequest, NextApiResponse } from 'next'
import { requireAuth } from '../../../lib/auth'
import { prisma } from '../../../lib/prisma'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const user = await requireAuth(req, res)
  if (!user) return

  if (req.method === 'GET') {
    const { status, platform, search, page = '1', limit = '20' } = req.query
    const skip = (Number(page) - 1) * Number(limit)

    const where: any = { userId: user.id }
    if (status) where.status = status
    if (platform) where.platform = platform
    if (search) {
      where.OR = [
        { customerName: { contains: search as string, mode: 'insensitive' } },
        { customerEmail: { contains: search as string, mode: 'insensitive' } },
        { trackingNumber: { contains: search as string, mode: 'insensitive' } },
      ]
    }

    const [orders, total] = await Promise.all([
      prisma.order.findMany({
        where,
        include: { items: true, shop: true, tracking: true },
        orderBy: { createdAt: 'desc' },
        skip,
        take: Number(limit),
      }),
      prisma.order.count({ where }),
    ])

    return res.status(200).json({ orders, total, page: Number(page), limit: Number(limit) })
  }

  if (req.method === 'POST') {
    const { customerName, customerEmail, customerAddress, totalAmount, platform, shopId, items, carrier, trackingNumber, notes } = req.body

    if (!customerName || !totalAmount) {
      return res.status(400).json({ error: 'Champs requis manquants' })
    }

    const order = await prisma.order.create({
      data: {
        userId: user.id,
        shopId: shopId || null,
        customerName,
        customerEmail,
        customerAddress,
        totalAmount: Number(totalAmount),
        platform: platform || 'MANUAL',
        carrier,
        trackingNumber,
        notes,
        items: {
          create: items?.map((item: any) => ({
            name: item.name,
            sku: item.sku,
            quantity: Number(item.quantity),
            unitPrice: Number(item.unitPrice),
            productId: item.productId || null,
          })) || [],
        },
      },
      include: { items: true },
    })

    return res.status(201).json({ order })
  }

  return res.status(405).end()
}
