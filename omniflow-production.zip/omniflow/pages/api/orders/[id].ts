import type { NextApiRequest, NextApiResponse } from 'next'
import { requireAuth } from '../../../lib/auth'
import { prisma } from '../../../lib/prisma'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const user = await requireAuth(req, res)
  if (!user) return

  const { id } = req.query as { id: string }

  const order = await prisma.order.findFirst({
    where: { id, userId: user.id },
    include: { items: { include: { product: true } }, shop: true, tracking: { include: { events: { orderBy: { occurredAt: 'desc' } } } } },
  })

  if (!order) return res.status(404).json({ error: 'Commande introuvable' })

  if (req.method === 'GET') {
    return res.status(200).json({ order })
  }

  if (req.method === 'PATCH') {
    const { status, carrier, trackingNumber, notes } = req.body
    const updated = await prisma.order.update({
      where: { id },
      data: {
        ...(status && { status }),
        ...(carrier !== undefined && { carrier }),
        ...(trackingNumber !== undefined && { trackingNumber }),
        ...(notes !== undefined && { notes }),
      },
      include: { items: true, tracking: true },
    })
    return res.status(200).json({ order: updated })
  }

  if (req.method === 'DELETE') {
    await prisma.order.delete({ where: { id } })
    return res.status(200).json({ ok: true })
  }

  return res.status(405).end()
}
