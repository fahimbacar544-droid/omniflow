import type { NextApiRequest, NextApiResponse } from 'next'
import { requireAuth } from '../../../lib/auth'
import { prisma } from '../../../lib/prisma'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const user = await requireAuth(req, res)
  if (!user) return

  if (req.method === 'GET') {
    const warehouses = await prisma.warehouse.findMany({
      where: { userId: user.id },
      include: { _count: { select: { stocks: true } } },
      orderBy: { createdAt: 'desc' },
    })
    return res.status(200).json({ warehouses })
  }

  if (req.method === 'POST') {
    const { name, country, city, address, isDefault } = req.body
    if (!name || !country) return res.status(400).json({ error: 'Nom et pays requis' })

    if (isDefault) {
      await prisma.warehouse.updateMany({ where: { userId: user.id }, data: { isDefault: false } })
    }
    const warehouse = await prisma.warehouse.create({
      data: { userId: user.id, name, country, city, address, isDefault: !!isDefault },
    })
    return res.status(201).json({ warehouse })
  }

  return res.status(405).end()
}
