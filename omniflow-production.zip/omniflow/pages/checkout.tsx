import Head from 'next/head'
import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import { api } from '../lib/api'
import { useRequireAuth } from '../lib/hooks'

const PLAN_LABELS: Record<string, { name: string; price: number; features: string[] }> = {
  STARTER:    { name: 'Starter',    price: 29,  features: ['1 boutique','300 commandes/mois','Tracking simple'] },
  PRO:        { name: 'Pro',        price: 79,  features: ['3 boutiques','2 000 commandes/mois','Multi-entrepôts'] },
  BUSINESS:   { name: 'Business',   price: 149, features: ['Boutiques illimitées','IA avancée','Support 24/7'] },
  ENTERPRISE: { name: 'Enterprise', price: 499, features: ['API privée','SLA 99.99%','Account manager'] },
}

export default function Checkout() {
  const { user, loading } = useRequireAuth()
  const router = useRouter()
  const { plan } = router.query as { plan: string }
  const [processing, setProcessing] = useState(false)
  const [error, setError] = useState('')

  const planInfo = PLAN_LABELS[plan] || PLAN_LABELS['BUSINESS']

  async function handleCheckout() {
    setProcessing(true)
    setError('')
    try {
      const { url } = await api.createCheckout(plan || 'BUSINESS')
      window.location.href = url
    } catch (err: any) {
      setError(err.message)
      setProcessing(false)
    }
  }

  if (loading) return <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><span className="spinner" style={{ width: 32, height: 32, borderWidth: 3, borderTopColor: 'var(--accent)' }} /></div>

  return (
    <>
      <Head><title>Abonnement — OmniFlow</title></Head>
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
        <div style={{ width: '100%', maxWidth: 480 }}>
          <div style={{ fontFamily: 'var(--serif)', fontSize: 24, color: 'var(--white)', marginBottom: 32, cursor: 'pointer' }} onClick={() => router.push('/')}>
            Omni<span style={{ color: 'var(--accent)' }}>Flow</span>
          </div>

          <div style={{ background: 'rgba(200,241,53,0.05)', border: '1px solid rgba(200,241,53,0.2)', borderRadius: 16, padding: 28, marginBottom: 24 }}>
            <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.1em', color: 'rgba(200,241,53,0.6)', marginBottom: 8 }}>Plan sélectionné</div>
            <div style={{ fontFamily: 'var(--serif)', fontSize: 36, color: 'var(--white)', letterSpacing: -1, marginBottom: 4 }}>
              {planInfo.price}€<span style={{ fontFamily: 'var(--sans)', fontSize: 16, color: 'rgba(255,255,255,0.4)' }}>/mois</span>
            </div>
            <div style={{ fontSize: 16, fontWeight: 500, color: 'var(--accent)', marginBottom: 16 }}>{planInfo.name}</div>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 8 }}>
              {planInfo.features.map(f => (
                <li key={f} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14, color: 'rgba(255,255,255,0.6)' }}>
                  <span style={{ color: 'var(--accent)' }}>✓</span>{f}
                </li>
              ))}
            </ul>
          </div>

          <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid var(--border)', borderRadius: 12, padding: '14px 18px', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontSize: 14 }}>👤</span>
            <span style={{ fontSize: 14, color: 'rgba(255,255,255,0.6)' }}>Connecté en tant que <strong style={{ color: 'var(--white)' }}>{user?.email}</strong></span>
          </div>

          {error && <div className="auth-error" style={{ marginBottom: 16 }}>{error}</div>}

          <button className="btn-auth" onClick={handleCheckout} disabled={processing}>
            {processing ? <span className="spinner" /> : `Payer ${planInfo.price}€/mois avec Stripe →`}
          </button>

          <p style={{ textAlign: 'center', fontSize: 12, color: 'rgba(255,255,255,0.2)', marginTop: 16 }}>
            🔒 Paiement 100% sécurisé via Stripe · Annulable à tout moment · 14 jours satisfait ou remboursé
          </p>
          <p style={{ textAlign: 'center', marginTop: 12 }}>
            <a onClick={() => router.push('/dashboard')} style={{ fontSize: 13, color: 'rgba(255,255,255,0.3)', cursor: 'pointer' }}>Continuer sans abonnement →</a>
          </p>
        </div>
      </div>
    </>
  )
}
