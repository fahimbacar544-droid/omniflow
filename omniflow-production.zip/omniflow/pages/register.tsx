import Head from 'next/head'
import { useRouter } from 'next/router'
import { useState } from 'react'
import { api } from '../lib/api'
import { useRequireNoAuth } from '../lib/hooks'

export default function Register() {
  useRequireNoAuth()
  const router = useRouter()
  const { plan } = router.query

  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (!form.name || !form.email || !form.password) { setError('Tous les champs sont requis'); return }
    if (form.password.length < 8) { setError('Mot de passe minimum 8 caractères'); return }

    setLoading(true)
    try {
      await api.register(form)
      // If plan selected, go to checkout; else go to dashboard
      if (plan && plan !== 'undefined') {
        router.push(`/checkout?plan=${plan}`)
      } else {
        router.push('/dashboard')
      }
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <Head><title>Créer un compte — OmniFlow</title></Head>
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
        <div style={{ width: '100%', maxWidth: 420 }}>
          <div style={{ fontFamily: 'var(--serif)', fontSize: 28, color: 'var(--white)', marginBottom: 6, cursor: 'pointer' }} onClick={() => router.push('/')}>
            Omni<span style={{ color: 'var(--accent)' }}>Flow</span>
          </div>
          <p style={{ fontSize: 14, color: 'rgba(255,255,255,0.4)', marginBottom: 32 }}>
            {plan ? `Créez votre compte pour accéder au plan ${plan}` : 'Créez votre compte gratuitement'}
          </p>
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {error && <div className="auth-error">{error}</div>}
            <div className="field">
              <label>Nom complet</label>
              <input type="text" placeholder="Jean Dupont" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} autoFocus />
            </div>
            <div className="field">
              <label>Email</label>
              <input type="email" placeholder="vous@exemple.com" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
            </div>
            <div className="field">
              <label>Mot de passe</label>
              <input type="password" placeholder="Minimum 8 caractères" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} />
            </div>
            <button type="submit" className="btn-auth" disabled={loading}>
              {loading ? <span className="spinner" /> : 'Créer mon compte →'}
            </button>
          </form>
          <p className="auth-switch">Déjà un compte ? <a onClick={() => router.push(plan ? `/login?plan=${plan}` : '/login')}>Se connecter</a></p>
          <p style={{ textAlign: 'center', fontSize: 11, color: 'rgba(255,255,255,0.2)', marginTop: 24 }}>
            En créant un compte, vous acceptez nos CGU et politique de confidentialité.
          </p>
        </div>
      </div>
    </>
  )
}
