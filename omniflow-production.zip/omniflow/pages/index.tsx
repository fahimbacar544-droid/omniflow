import Head from 'next/head'
import { useRouter } from 'next/router'
import { useEffect, useRef } from 'react'

const LOGOS = [
  { name: 'Shopify',        color: '#95BE46' },
  { name: 'Amazon FBA',     color: '#FF9900' },
  { name: 'WooCommerce',    color: '#7F54B3' },
  { name: 'TikTok Shop',    color: '#FE2C55' },
  { name: 'Etsy',           color: '#F56400' },
  { name: 'PrestaShop',     color: '#DF0067' },
  { name: 'AliExpress',     color: '#E21111' },
  { name: 'CJ Dropshipping',color: '#3A6EA5' },
  { name: 'Zendrop',        color: '#00b4d8' },
  { name: 'Spocket',        color: '#6366f1' },
  { name: 'Colissimo',      color: '#e63e27' },
  { name: 'DHL Express',    color: '#cc0000' },
  { name: 'UPS',            color: '#351c15' },
  { name: 'FedEx',          color: '#4d148c' },
]

const FEATURES = [
  { icon: '📦', title: 'Stocks multi-entrepôts',   desc: 'Sync automatique entre tous vos entrepôts (France, Chine, FBA). Stock global calculé en temps réel.' },
  { icon: '🔄', title: 'Sync multi-plateformes',   desc: 'Une vente sur Shopify met à jour Amazon, WooCommerce et TikTok Shop en moins de 5 secondes.' },
  { icon: '🤖', title: 'Prévisions IA',            desc: 'Anticipez les ruptures, détectez les best-sellers, identifiez la saisonnalité. Réappro automatique.' },
  { icon: '🚚', title: 'Tracking unifié',          desc: 'Colissimo, DHL, UPS, YunExpress, 4PX… Toutes les livraisons dans un tableau de bord. Page tracking brandée.' },
  { icon: '⚡', title: 'Automatisation avancée',   desc: 'Règles personnalisées : "si commande France → Colissimo", "si stock < 10 → alerte + réappro auto".' },
  { icon: '🤝', title: 'Gestion fournisseurs',     desc: 'Comparateur de prix automatique, envoi commandes aux fournisseurs, récupération trackings en temps réel.' },
]

const PRICING = [
  { key: 'STARTER',    label: 'Starter',    price: 29,  desc: 'Pour tester et lancer',      featured: false, features: ['1 boutique connectée','300 commandes / mois','Tracking simple','Sync stocks','Support email'] },
  { key: 'PRO',        label: 'Pro',        price: 79,  desc: 'Pour scaler votre business',  featured: false, features: ['3 boutiques connectées','2 000 commandes / mois','Automatisation fournisseurs','Multi-entrepôts','Tracking personnalisé'] },
  { key: 'BUSINESS',   label: 'Business',   price: 149, desc: 'Pour les marques sérieuses',  featured: true,  features: ['Boutiques illimitées','IA avancée + prévisions','Multi-plateformes complet','API webhooks','Support 24/7'] },
  { key: 'ENTERPRISE', label: 'Enterprise', price: 499, desc: 'Pour les grandes marques',    featured: false, features: ['API privée dédiée','Entrepôts multiples illimités','Onboarding personnalisé','SLA 99.99%','Account manager dédié'] },
]

export default function Home() {
  const router = useRouter()
  const revealRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); obs.unobserve(e.target) } })
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' })
    document.querySelectorAll('.reveal').forEach(el => obs.observe(el))
    return () => obs.disconnect()
  }, [])

  async function handlePricingClick(planKey: string) {
    // Check if logged in first
    const res = await fetch('/api/auth/me')
    if (res.ok) {
      const { data } = await res.json().catch(() => ({}))
      router.push(`/checkout?plan=${planKey}`)
    } else {
      router.push(`/register?plan=${planKey}`)
    }
  }

  return (
    <>
      <Head>
        <title>OmniFlow — Le centre nerveux de votre e-commerce</title>
        <meta name="description" content="OmniFlow connecte toutes vos boutiques, synchronise vos stocks en temps réel et automatise vos commandes." />
      </Head>

      {/* NAV */}
      <nav style={{ position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100, padding: '20px 48px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)', borderBottom: '1px solid var(--border)', background: 'rgba(10,10,10,0.7)' }}>
        <a style={{ fontFamily: 'var(--serif)', fontSize: 22, color: 'var(--white)', cursor: 'pointer' }} onClick={() => router.push('/')}>
          Omni<span style={{ color: 'var(--accent)' }}>Flow</span>
        </a>
        <ul style={{ display: 'flex', alignItems: 'center', gap: 36, listStyle: 'none' }}>
          {[['#features','Fonctionnalités'],['#workflow','Comment ça marche'],['#pricing','Tarifs']].map(([href, label]) => (
            <li key={href}><a href={href} style={{ color: 'rgba(255,255,255,0.55)', fontSize: 14 }}>{label}</a></li>
          ))}
        </ul>
        <div style={{ display: 'flex', gap: 12 }}>
          <button className="btn-ghost" onClick={() => router.push('/login')}>Se connecter</button>
          <button className="btn-primary" onClick={() => router.push('/register')}>Démarrer gratuitement</button>
        </div>
      </nav>

      {/* HERO */}
      <section style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: '120px 48px 80px', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: '10%', left: '50%', transform: 'translateX(-50%)', width: 800, height: 500, background: 'radial-gradient(ellipse at center, rgba(200,241,53,0.12) 0%, transparent 70%)', pointerEvents: 'none' }} />
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 16px 6px 8px', border: '1px solid rgba(200,241,53,0.25)', borderRadius: 100, background: 'rgba(200,241,53,0.06)', fontSize: 13, color: 'var(--accent)', marginBottom: 36, animation: 'fadeUp 0.8s ease both' }}>
          <div style={{ width: 6, height: 6, background: 'var(--accent)', borderRadius: '50%', animation: 'pulse 2s ease infinite' }} />
          Sync temps réel · Shopify · Amazon · TikTok · WooCommerce
        </div>
        <h1 style={{ fontFamily: 'var(--serif)', fontSize: 'clamp(52px,8vw,96px)', fontWeight: 400, lineHeight: 1.02, letterSpacing: -2, color: 'var(--white)', maxWidth: 900, animation: 'fadeUp 0.8s ease 0.1s both' }}>
          Toute votre logistique,<br /><em style={{ fontStyle: 'italic', color: 'var(--accent)' }}>un seul endroit.</em>
        </h1>
        <p style={{ fontSize: 18, color: 'rgba(255,255,255,0.5)', maxWidth: 520, lineHeight: 1.65, marginTop: 24, fontWeight: 300, animation: 'fadeUp 0.8s ease 0.2s both' }}>
          OmniFlow connecte toutes vos boutiques, synchronise vos stocks en temps réel et automatise vos commandes — de AliExpress à Amazon FBA.
        </p>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 40, animation: 'fadeUp 0.8s ease 0.3s both' }}>
          <button className="btn-hero" onClick={() => router.push('/register')}>Commencer gratuitement</button>
          <button className="btn-hero-ghost" onClick={() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' })}>Voir les plans →</button>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 40, marginTop: 72, paddingTop: 40, borderTop: '1px solid var(--border)', animation: 'fadeUp 0.8s ease 0.4s both' }}>
          {[['12+','Plateformes connectées'],['5 min','Pour démarrer'],['99.9%','Uptime garanti'],['IA','Prévisions rupture']].map(([num, label]) => (
            <div key={label}>
              <div style={{ fontFamily: 'var(--serif)', fontSize: 34, color: 'var(--white)', letterSpacing: -1 }}>{num}</div>
              <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.4)', marginTop: 2 }}>{label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* LOGOS */}
      <div style={{ padding: '48px', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)', textAlign: 'center' }}>
        <p style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.1em', color: 'rgba(255,255,255,0.3)', marginBottom: 28 }}>Compatible avec toutes vos plateformes</p>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', gap: '10px 6px' }}>
          {LOGOS.map(l => (
            <div key={l.name} style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '8px 16px', border: '1px solid var(--border)', borderRadius: 100, background: 'var(--card-bg)', fontSize: 13, color: 'rgba(255,255,255,0.45)' }}>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: l.color, flexShrink: 0 }} />{l.name}
            </div>
          ))}
        </div>
      </div>

      {/* FEATURES */}
      <section id="features" style={{ padding: '100px 48px', maxWidth: 1200, margin: '0 auto' }}>
        <span className="section-label reveal" style={{ display: 'inline-block', fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--accent)', marginBottom: 20 }}>Tout ce dont vous avez besoin</span>
        <h2 className="reveal" style={{ fontFamily: 'var(--serif)', fontSize: 'clamp(38px,5vw,58px)', fontWeight: 400, lineHeight: 1.08, letterSpacing: -1.5, color: 'var(--white)', maxWidth: 680, marginBottom: 60 }}>
          Une plateforme. <em style={{ fontStyle: 'italic', color: 'rgba(255,255,255,0.45)' }}>Zéro friction.</em>
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 1, border: '1px solid var(--border)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
          {FEATURES.map((f, i) => (
            <div key={f.title} className="reveal" style={{ padding: '36px 32px', background: 'rgba(255,255,255,0.025)', transition: 'background 0.25s', transitionDelay: `${i*0.08}s` }}>
              <div style={{ width: 40, height: 40, borderRadius: 10, background: 'rgba(200,241,53,0.1)', border: '1px solid rgba(200,241,53,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, marginBottom: 20 }}>{f.icon}</div>
              <div style={{ fontSize: 16, fontWeight: 500, color: 'var(--white)', marginBottom: 10 }}>{f.title}</div>
              <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.45)', lineHeight: 1.65 }}>{f.desc}</div>
            </div>
          ))}
        </div>
      </section>

      {/* WORKFLOW */}
      <section id="workflow" style={{ padding: '100px 48px', borderTop: '1px solid var(--border)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 60 }}>
            <span className="reveal" style={{ display: 'inline-block', fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--accent)', marginBottom: 16 }}>Comment ça marche</span>
            <h2 className="reveal" style={{ fontFamily: 'var(--serif)', fontSize: 'clamp(38px,5vw,58px)', fontWeight: 400, letterSpacing: -1.5, color: 'var(--white)' }}>
              Opérationnel en <em style={{ fontStyle: 'italic', color: 'rgba(255,255,255,0.45)' }}>5 minutes</em>
            </h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 16 }}>
            {[
              { n:'01', title:'Connectez vos plateformes', desc:'Shopify, Amazon, WooCommerce, TikTok — one-click OAuth. Vos données arrivent en temps réel.' },
              { n:'02', title:'Configurez vos règles', desc:'Définissez votre logistique en langage naturel. OmniFlow applique vos règles automatiquement.' },
              { n:'03', title:'L\'IA prend le relais', desc:'Prévisions de stocks, détection d\'anomalies, comparaison fournisseurs. Tout est automatisé.' },
              { n:'04', title:'Pilotez depuis un écran', desc:'Commandes, stocks, tracking, fournisseurs — tout votre e-commerce dans un tableau de bord unifié.' },
            ].map((s, i) => (
              <div key={s.n} className="reveal" style={{ padding: '32px 28px', background: 'rgba(255,255,255,0.02)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', transitionDelay: `${i*0.1}s` }}>
                <div style={{ fontFamily: 'var(--serif)', fontSize: 48, color: 'rgba(255,255,255,0.06)', fontStyle: 'italic', lineHeight: 1, marginBottom: 16 }}>{s.n}</div>
                <div style={{ fontSize: 15, fontWeight: 500, color: 'var(--white)', marginBottom: 10 }}>{s.title}</div>
                <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.4)', lineHeight: 1.6 }}>{s.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" style={{ padding: '100px 48px', borderTop: '1px solid var(--border)' }}>
        <div style={{ maxWidth: 1100, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 60 }}>
            <span className="reveal" style={{ display: 'inline-block', fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--accent)', marginBottom: 16 }}>Tarifs transparents</span>
            <h2 className="reveal" style={{ fontFamily: 'var(--serif)', fontSize: 'clamp(38px,5vw,58px)', fontWeight: 400, letterSpacing: -1.5, color: 'var(--white)' }}>
              Un plan pour <em style={{ fontStyle: 'italic', color: 'rgba(255,255,255,0.45)' }}>chaque étape</em>
            </h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 16 }}>
            {PRICING.map((p, i) => (
              <div key={p.key} className="reveal" style={{ background: p.featured ? 'rgba(200,241,53,0.05)' : 'rgba(255,255,255,0.03)', border: `1px solid ${p.featured ? 'rgba(200,241,53,0.3)' : 'var(--border)'}`, borderRadius: 'var(--radius)', padding: '32px 28px', position: 'relative', transition: 'all 0.25s', transitionDelay: `${i*0.1}s` }}>
                {p.featured && <div style={{ position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)', background: 'var(--accent)', color: 'var(--black)', fontSize: 11, fontWeight: 500, padding: '4px 14px', borderRadius: 100, whiteSpace: 'nowrap' }}>Le plus populaire</div>}
                <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.1em', color: 'rgba(255,255,255,0.4)', marginBottom: 14 }}>{p.label}</div>
                <div style={{ fontFamily: 'var(--serif)', fontSize: 42, color: 'var(--white)', letterSpacing: -1, lineHeight: 1, marginBottom: 4 }}>{p.price}<span style={{ fontFamily: 'var(--sans)', fontSize: 16, color: 'rgba(255,255,255,0.4)', letterSpacing: 0 }}>€/mois</span></div>
                <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.35)', marginBottom: 20 }}>{p.desc}</div>
                <div style={{ height: 1, background: 'var(--border)', marginBottom: 20 }} />
                <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 28 }}>
                  {p.features.map(f => (
                    <li key={f} style={{ display: 'flex', alignItems: 'flex-start', gap: 10, fontSize: 13, color: 'rgba(255,255,255,0.55)' }}>
                      <span style={{ color: 'var(--accent)', flexShrink: 0 }}>✓</span>{f}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => router.push(`/register?plan=${p.key}`)}
                  style={{ width: '100%', padding: 12, borderRadius: 100, fontFamily: 'var(--sans)', fontSize: 14, fontWeight: 500, cursor: 'pointer', transition: 'all 0.2s', background: p.featured ? 'var(--accent)' : 'transparent', color: p.featured ? 'var(--black)' : 'rgba(255,255,255,0.7)', border: p.featured ? 'none' : '1px solid var(--border)' }}
                >
                  {p.key === 'ENTERPRISE' ? 'Contacter les ventes →' : 'Commencer →'}
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: '100px 48px', borderTop: '1px solid var(--border)', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', bottom: -100, left: '50%', transform: 'translateX(-50%)', width: 700, height: 400, background: 'radial-gradient(ellipse, rgba(200,241,53,0.1) 0%, transparent 70%)', pointerEvents: 'none' }} />
        <h2 className="reveal" style={{ fontFamily: 'var(--serif)', fontSize: 'clamp(42px,6vw,72px)', fontWeight: 400, letterSpacing: -2, lineHeight: 1.05, maxWidth: 700, margin: '0 auto 16px' }}>
          Centralisez tout.<br /><em style={{ fontStyle: 'italic', color: 'var(--accent)' }}>Vendez partout.</em>
        </h2>
        <p className="reveal" style={{ fontSize: 16, color: 'rgba(255,255,255,0.4)', marginBottom: 36 }}>14 jours gratuits · Sans carte bancaire · Setup en 5 minutes</p>
        <div className="reveal" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14 }}>
          <button className="btn-hero" onClick={() => router.push('/register')}>Créer mon compte gratuitement</button>
          <button className="btn-hero-ghost" onClick={() => router.push('/login')}>Se connecter</button>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ padding: '40px 48px', borderTop: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontFamily: 'var(--serif)', fontSize: 18, color: 'rgba(255,255,255,0.5)' }}>Omni<span style={{ color: 'var(--accent)' }}>Flow</span></div>
        <ul style={{ display: 'flex', gap: 28, listStyle: 'none' }}>
          {['Fonctionnalités','Tarifs','Documentation','Blog','Mentions légales','Confidentialité'].map(l => (
            <li key={l}><a href="#" style={{ fontSize: 13, color: 'rgba(255,255,255,0.3)' }}>{l}</a></li>
          ))}
        </ul>
        <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.2)' }}>© 2026 OmniFlow. Tous droits réservés.</div>
      </footer>
    </>
  )
}
