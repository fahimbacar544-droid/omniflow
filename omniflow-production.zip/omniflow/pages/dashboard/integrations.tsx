import Head from 'next/head'
import DashboardLayout from '../../components/DashboardLayout'
import { useRequireAuth, useShops } from '../../lib/hooks'
import { useRouter } from 'next/router'

const INTEGRATIONS = [
  { name: 'Shopify', color: '#95BE46', desc: 'Boutique + webhooks', category: 'marketplace', docsUrl: 'https://shopify.dev/docs/api' },
  { name: 'Amazon SP-API', color: '#FF9900', desc: 'FBA + Marketplace', category: 'marketplace', docsUrl: 'https://developer-docs.amazon.com/sp-api' },
  { name: 'TikTok Shop', color: '#FE2C55', desc: 'Shop API', category: 'marketplace', docsUrl: 'https://partner.tiktokshop.com/doc' },
  { name: 'WooCommerce', color: '#7F54B3', desc: 'REST API v3', category: 'marketplace', docsUrl: 'https://woocommerce.github.io/woocommerce-rest-api-docs' },
  { name: 'Etsy', color: '#F56400', desc: 'Open API v3', category: 'marketplace', docsUrl: 'https://developers.etsy.com/documentation' },
  { name: 'PrestaShop', color: '#DF0067', desc: 'Web Services', category: 'marketplace', docsUrl: 'https://devdocs.prestashop-project.org' },
  { name: 'Colissimo', color: '#e63e27', desc: 'API Pro La Poste', category: 'carrier', docsUrl: 'https://www.colissimo.entreprise.laposte.fr' },
  { name: 'DHL Express', color: '#cc0000', desc: 'Parcel API', category: 'carrier', docsUrl: 'https://developer.dhl.com' },
  { name: 'UPS', color: '#351c15', desc: 'Shipping API', category: 'carrier', docsUrl: 'https://developer.ups.com' },
  { name: 'FedEx', color: '#4d148c', desc: 'Ship API', category: 'carrier', docsUrl: 'https://developer.fedex.com' },
  { name: 'AfterShip', color: '#64b4ff', desc: 'Tracking unifié 900+ carriers', category: 'tracking', docsUrl: 'https://www.aftership.com/docs' },
  { name: 'CJ Dropshipping', color: '#3A6EA5', desc: 'Auto-fulfillment API', category: 'supplier', docsUrl: 'https://cjdropshipping.com/api' },
  { name: 'AliExpress', color: '#E21111', desc: 'Open Platform API', category: 'supplier', docsUrl: 'https://developers.aliexpress.com' },
  { name: 'Zendrop', color: '#00b4d8', desc: 'Fast shipping US/EU', category: 'supplier', docsUrl: 'https://zendrop.com/api' },
  { name: 'Stripe', color: '#6772e5', desc: 'Paiements & abonnements', category: 'payment', docsUrl: 'https://stripe.com/docs' },
]

const CATEGORIES = [
  { key: 'marketplace', label: 'Marketplaces', icon: '🏪' },
  { key: 'carrier', label: 'Transporteurs', icon: '🚚' },
  { key: 'tracking', label: 'Tracking', icon: '📍' },
  { key: 'supplier', label: 'Fournisseurs', icon: '🤝' },
  { key: 'payment', label: 'Paiements', icon: '💳' },
]

export default function Integrations() {
  const { loading: authLoading } = useRequireAuth()
  const { data: shopsData } = useShops()
  const router = useRouter()
  const connectedShops = shopsData?.shops || []

  if (authLoading) return null

  return (
    <>
      <Head><title>Intégrations — OmniFlow</title></Head>
      <DashboardLayout title="Intégrations" subtitle="Connecteurs et API" active="integrations"
        actions={<button className="btn-sm accent" onClick={() => router.push('/dashboard/settings')}>+ Connecter une boutique</button>}
      >
        <div style={{ marginBottom: 24, padding: '16px 20px', background: 'rgba(200,241,53,0.05)', border: '1px solid rgba(200,241,53,0.15)', borderRadius: 14, display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(200,241,53,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 }}>⚡</div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--white)', marginBottom: 2 }}>
              {connectedShops.length} boutique{connectedShops.length !== 1 ? 's' : ''} connectée{connectedShops.length !== 1 ? 's' : ''}
            </div>
            <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.4)' }}>
              Pour ajouter une intégration réelle, connectez une boutique dans les Paramètres avec votre clé API.
            </div>
          </div>
          <button className="btn-sm" style={{ marginLeft: 'auto', flexShrink: 0 }} onClick={() => router.push('/dashboard/settings')}>Gérer →</button>
        </div>

        {CATEGORIES.map(cat => (
          <div key={cat.key} style={{ marginBottom: 32 }}>
            <div style={{ fontSize: 13, fontWeight: 500, color: 'rgba(255,255,255,0.45)', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 8, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
              <span>{cat.icon}</span>{cat.label}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10 }}>
              {INTEGRATIONS.filter(i => i.category === cat.key).map(intg => {
                const isConnected = connectedShops.some((s: any) => s.platform === intg.name.toUpperCase().replace(' ', '').replace('-', '')) || intg.name === 'Stripe'
                return (
                  <div key={intg.name} style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid var(--border)', borderRadius: 12, padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12, transition: 'all 0.2s', cursor: 'pointer' }}
                    onMouseEnter={e => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.12)')}
                    onMouseLeave={e => (e.currentTarget.style.borderColor = 'var(--border)')}
                    onClick={() => window.open(intg.docsUrl, '_blank')}
                  >
                    <div style={{ width: 10, height: 10, borderRadius: '50%', background: intg.color, flexShrink: 0 }} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13, color: 'var(--white)', fontWeight: 500 }}>{intg.name}</div>
                      <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', marginTop: 2 }}>{intg.desc}</div>
                    </div>
                    <span className={`badge ${isConnected ? 'badge-green' : 'badge-gray'}`} style={{ fontSize: 10, flexShrink: 0 }}>
                      {isConnected ? 'Connecté' : 'Docs ↗'}
                    </span>
                  </div>
                )
              })}
            </div>
          </div>
        ))}
      </DashboardLayout>
    </>
  )
}
