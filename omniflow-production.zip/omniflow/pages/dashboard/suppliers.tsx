import Head from 'next/head'
import { useState } from 'react'
import DashboardLayout from '../../components/DashboardLayout'
import { useRequireAuth, useSuppliers } from '../../lib/hooks'
import { api } from '../../lib/api'

const TYPE_LABELS: Record<string, string> = { DROPSHIPPING: 'Dropshipping', WHOLESALE: 'Grossiste', MANUFACTURER: 'Fabricant', FBA: 'Amazon FBA' }
const TYPE_COLORS: Record<string, string> = { DROPSHIPPING: '#64b4ff', WHOLESALE: '#ffb432', MANUFACTURER: '#b464ff', FBA: '#FF9900' }

export default function Suppliers() {
  const { loading: authLoading } = useRequireAuth()
  const { data, isLoading, mutate } = useSuppliers()
  const [showAdd, setShowAdd] = useState(false)
  const [form, setForm] = useState({ name: '', type: 'DROPSHIPPING', website: '', email: '', phone: '', country: '', apiKey: '' })
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')

  const suppliers = data?.suppliers || []
  if (authLoading) return null

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    try {
      await api.createSupplier(form)
      mutate()
      setShowAdd(false)
      setForm({ name: '', type: 'DROPSHIPPING', website: '', email: '', phone: '', country: '', apiKey: '' })
      setMsg('Fournisseur ajouté ✓')
      setTimeout(() => setMsg(''), 3000)
    } catch (err: any) { setMsg(err.message) }
    finally { setSaving(false) }
  }

  return (
    <>
      <Head><title>Fournisseurs — OmniFlow</title></Head>
      <DashboardLayout title="Fournisseurs" subtitle="Gestion et comparaison fournisseurs" active="suppliers"
        actions={<button className="btn-sm accent" onClick={() => setShowAdd(true)}>+ Ajouter fournisseur</button>}
      >
        {msg && <div style={{ background: 'rgba(200,241,53,0.08)', border: '1px solid rgba(200,241,53,0.2)', borderRadius: 10, padding: '10px 16px', fontSize: 13, color: 'var(--accent)', marginBottom: 16 }}>{msg}</div>}

        <div className="kpi-grid">
          <div className="kpi-card"><div className="kpi-label">Fournisseurs actifs</div><div className="kpi-value">{suppliers.filter((s: any) => s.active).length}</div></div>
          <div className="kpi-card"><div className="kpi-label">Dropshipping</div><div className="kpi-value">{suppliers.filter((s: any) => s.type === 'DROPSHIPPING').length}</div></div>
          <div className="kpi-card"><div className="kpi-label">Grossistes</div><div className="kpi-value">{suppliers.filter((s: any) => s.type === 'WHOLESALE').length}</div></div>
          <div className="kpi-card"><div className="kpi-label">Avec API</div><div className="kpi-value">{suppliers.filter((s: any) => s.apiKey).length}</div><div className="kpi-change up">Auto-fulfillment</div></div>
        </div>

        {isLoading ? (
          <div style={{ padding: 40, textAlign: 'center' }}><span className="spinner" style={{ width: 24, height: 24, borderTopColor: 'var(--accent)' }} /></div>
        ) : suppliers.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state-icon">🤝</div>
            Aucun fournisseur — ajoutez votre premier fournisseur
            <br />
            <button className="btn-sm accent" style={{ marginTop: 16 }} onClick={() => setShowAdd(true)}>+ Ajouter un fournisseur</button>
          </div>
        ) : (
          <div className="grid-3" style={{ marginBottom: 24 }}>
            {suppliers.map((s: any) => (
              <div key={s.id} className="dash-card" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                  <div>
                    <div style={{ fontSize: 15, fontWeight: 500, color: 'var(--white)', marginBottom: 4 }}>{s.name}</div>
                    <span className="badge" style={{ background: `${TYPE_COLORS[s.type]}18`, color: TYPE_COLORS[s.type], fontSize: 11 }}>{TYPE_LABELS[s.type]}</span>
                  </div>
                  <span className={`badge ${s.active ? 'badge-green' : 'badge-gray'}`}>{s.active ? 'Actif' : 'Inactif'}</span>
                </div>
                {s.website && <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.35)', fontFamily: 'monospace' }}>{s.website}</div>}
                {s.email && <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.35)' }}>✉ {s.email}</div>}
                {s.country && <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.35)' }}>📍 {s.country}</div>}
                {s.apiKey && (
                  <div style={{ padding: '8px 12px', background: 'rgba(200,241,53,0.05)', border: '1px solid rgba(200,241,53,0.15)', borderRadius: 8, fontSize: 11, color: 'rgba(200,241,53,0.7)' }}>
                    ⚡ Auto-fulfillment activé
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {showAdd && (
          <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) setShowAdd(false) }}>
            <div className="modal-box" style={{ maxWidth: 480 }}>
              <button className="modal-close" onClick={() => setShowAdd(false)}>✕</button>
              <div style={{ fontFamily: 'var(--serif)', fontSize: 20, color: 'var(--white)', marginBottom: 20 }}>Nouveau fournisseur</div>
              <form onSubmit={handleAdd} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="field"><label>Nom *</label><input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="CJ Dropshipping" autoFocus /></div>
                  <div className="field"><label>Type</label>
                    <select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))}>
                      {Object.entries(TYPE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                    </select>
                  </div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="field"><label>Site web</label><input value={form.website} onChange={e => setForm(f => ({ ...f, website: e.target.value }))} placeholder="https://cjdropshipping.com" /></div>
                  <div className="field"><label>Email contact</label><input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="contact@fournisseur.com" /></div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="field"><label>Pays</label><input value={form.country} onChange={e => setForm(f => ({ ...f, country: e.target.value }))} placeholder="CN" maxLength={2} /></div>
                  <div className="field"><label>Téléphone</label><input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="+86 XXX XXX" /></div>
                </div>
                <div className="field">
                  <label>Clé API (pour auto-fulfillment)</label>
                  <input value={form.apiKey} onChange={e => setForm(f => ({ ...f, apiKey: e.target.value }))} placeholder="Clé API du fournisseur" />
                  <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.25)', marginTop: 4 }}>Optionnel — permet l'envoi automatique des commandes</span>
                </div>
                <button type="submit" className="btn-auth" disabled={saving}>{saving ? <span className="spinner" /> : 'Ajouter le fournisseur →'}</button>
              </form>
            </div>
          </div>
        )}
      </DashboardLayout>
    </>
  )
}
