import Head from 'next/head'
import { useState } from 'react'
import DashboardLayout from '../../components/DashboardLayout'
import { useRequireAuth, useStocks, useWarehouses } from '../../lib/hooks'
import { api } from '../../lib/api'

export default function Stocks() {
  const { loading: authLoading } = useRequireAuth()
  const { data, isLoading, mutate } = useStocks()
  const { data: whData } = useWarehouses()
  const [showAdd, setShowAdd] = useState(false)
  const [showAddWH, setShowAddWH] = useState(false)
  const [form, setForm] = useState({ name: '', sku: '', costPrice: '', sellPrice: '', warehouseId: '', quantity: '', minLevel: '10' })
  const [whForm, setWHForm] = useState({ name: '', country: 'FR', city: '', isDefault: false })
  const [saving, setSaving] = useState(false)

  const products = data?.products || []
  const warehouses = whData?.warehouses || []

  if (authLoading) return null

  async function handleAddProduct(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    try {
      await api.createProduct(form)
      mutate()
      setShowAdd(false)
    } catch (err: any) { alert(err.message) }
    finally { setSaving(false) }
  }

  async function handleAddWarehouse(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    try {
      await api.createWarehouse(whForm)
      setShowAddWH(false)
    } catch (err: any) { alert(err.message) }
    finally { setSaving(false) }
  }

  const ruptures = products.filter((p: any) => p.status === 'RUPTURE').length
  const bas = products.filter((p: any) => p.status === 'BAS').length
  const total = products.reduce((s: number, p: any) => s + p.totalStock, 0)

  return (
    <>
      <Head><title>Stocks — OmniFlow</title></Head>
      <DashboardLayout title="Stocks" subtitle="Inventaire multi-entrepôts synchronisé" active="stocks"
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn-sm" onClick={() => setShowAddWH(true)}>+ Entrepôt</button>
            <button className="btn-sm accent" onClick={() => setShowAdd(true)}>+ Produit</button>
          </div>
        }
      >
        <div className="kpi-grid">
          <div className="kpi-card"><div className="kpi-label">Produits actifs</div><div className="kpi-value">{products.length}</div></div>
          <div className="kpi-card"><div className="kpi-label">Stock total</div><div className="kpi-value">{total.toLocaleString('fr-FR')}</div><div className="kpi-change up">Tous entrepôts</div></div>
          <div className="kpi-card"><div className="kpi-label">Ruptures</div><div className="kpi-value" style={{ color: ruptures > 0 ? '#ff6b6b' : 'var(--white)' }}>{ruptures}</div>{ruptures > 0 && <div className="kpi-change warn">⚠ Urgent</div>}</div>
          <div className="kpi-card"><div className="kpi-label">Entrepôts</div><div className="kpi-value">{warehouses.length}</div></div>
        </div>

        {warehouses.length > 0 && (
          <div style={{ display: 'flex', gap: 10, marginBottom: 20, flexWrap: 'wrap' }}>
            {warehouses.map((w: any) => (
              <div key={w.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 14px', background: 'rgba(255,255,255,0.03)', border: '1px solid var(--border)', borderRadius: 10, fontSize: 13, color: 'rgba(255,255,255,0.6)' }}>
                <span>🏭</span>{w.name} <span style={{ color: 'rgba(255,255,255,0.25)', fontSize: 11 }}>({w.country})</span>
                {w.isDefault && <span className="badge badge-green" style={{ fontSize: 10, padding: '2px 8px' }}>Défaut</span>}
              </div>
            ))}
          </div>
        )}

        <div className="table-wrap">
          <div className="table-header"><div className="table-title">Inventaire</div></div>
          {isLoading ? (
            <div style={{ padding: 40, textAlign: 'center' }}><span className="spinner" style={{ width: 24, height: 24, borderTopColor: 'var(--accent)' }} /></div>
          ) : products.length === 0 ? (
            <div className="empty-state">
              <div className="empty-state-icon">📦</div>
              Aucun produit — commencez par en ajouter un
              <br />
              <button className="btn-sm accent" style={{ marginTop: 16 }} onClick={() => setShowAdd(true)}>+ Ajouter un produit</button>
            </div>
          ) : (
            <table>
              <thead><tr><th>Produit</th><th>SKU</th>
                {warehouses.map((w: any) => <th key={w.id}>{w.name}</th>)}
                <th>Total</th><th>Statut</th><th>Action</th>
              </tr></thead>
              <tbody>
                {products.map((p: any) => (
                  <tr key={p.id}>
                    <td style={{ color: 'rgba(255,255,255,0.85)', fontWeight: 500 }}>{p.name}</td>
                    <td style={{ fontFamily: 'monospace', fontSize: 12, color: 'rgba(255,255,255,0.3)' }}>{p.sku}</td>
                    {warehouses.map((w: any) => {
                      const s = p.stocks.find((st: any) => st.warehouseId === w.id)
                      return <td key={w.id} style={{ fontSize: 13, color: 'rgba(255,255,255,0.5)' }}>{s?.quantity ?? 0}</td>
                    })}
                    <td style={{ fontWeight: 500, color: p.status === 'RUPTURE' ? '#ff5050' : p.status === 'BAS' ? '#ffb432' : '#64dc78' }}>{p.totalStock}</td>
                    <td><span className={`badge ${p.status === 'RUPTURE' ? 'badge-red' : p.status === 'BAS' ? 'badge-orange' : 'badge-green'}`}>{p.status === 'RUPTURE' ? 'Rupture' : p.status === 'BAS' ? 'Bas' : 'OK'}</span></td>
                    <td>
                      {p.status !== 'OK' && <button className="btn-sm accent" style={{ fontSize: 11 }}>Réappro.</button>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Add Product Modal */}
        {showAdd && (
          <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) setShowAdd(false) }}>
            <div className="modal-box">
              <button className="modal-close" onClick={() => setShowAdd(false)}>✕</button>
              <div style={{ fontFamily: 'var(--serif)', fontSize: 20, color: 'var(--white)', marginBottom: 20 }}>Nouveau produit</div>
              <form onSubmit={handleAddProduct} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="field"><label>Nom *</label><input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Sneaker Air Max" /></div>
                  <div className="field"><label>SKU *</label><input required value={form.sku} onChange={e => setForm(f => ({ ...f, sku: e.target.value }))} placeholder="SKU-001" /></div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="field"><label>Prix achat (€)</label><input type="number" step="0.01" value={form.costPrice} onChange={e => setForm(f => ({ ...f, costPrice: e.target.value }))} placeholder="31.20" /></div>
                  <div className="field"><label>Prix vente (€)</label><input type="number" step="0.01" value={form.sellPrice} onChange={e => setForm(f => ({ ...f, sellPrice: e.target.value }))} placeholder="89.00" /></div>
                </div>
                {warehouses.length > 0 && (
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
                    <div className="field"><label>Entrepôt</label>
                      <select value={form.warehouseId} onChange={e => setForm(f => ({ ...f, warehouseId: e.target.value }))}>
                        <option value="">— Aucun</option>
                        {warehouses.map((w: any) => <option key={w.id} value={w.id}>{w.name}</option>)}
                      </select>
                    </div>
                    <div className="field"><label>Quantité</label><input type="number" min="0" value={form.quantity} onChange={e => setForm(f => ({ ...f, quantity: e.target.value }))} placeholder="0" /></div>
                    <div className="field"><label>Seuil alerte</label><input type="number" min="0" value={form.minLevel} onChange={e => setForm(f => ({ ...f, minLevel: e.target.value }))} placeholder="10" /></div>
                  </div>
                )}
                <button type="submit" className="btn-auth" disabled={saving}>{saving ? <span className="spinner" /> : 'Ajouter le produit →'}</button>
              </form>
            </div>
          </div>
        )}

        {/* Add Warehouse Modal */}
        {showAddWH && (
          <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) setShowAddWH(false) }}>
            <div className="modal-box">
              <button className="modal-close" onClick={() => setShowAddWH(false)}>✕</button>
              <div style={{ fontFamily: 'var(--serif)', fontSize: 20, color: 'var(--white)', marginBottom: 20 }}>Nouvel entrepôt</div>
              <form onSubmit={handleAddWarehouse} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <div className="field"><label>Nom *</label><input required value={whForm.name} onChange={e => setWHForm(f => ({ ...f, name: e.target.value }))} placeholder="Entrepôt France" /></div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="field"><label>Pays *</label><input required value={whForm.country} onChange={e => setWHForm(f => ({ ...f, country: e.target.value }))} placeholder="FR" maxLength={2} /></div>
                  <div className="field"><label>Ville</label><input value={whForm.city} onChange={e => setWHForm(f => ({ ...f, city: e.target.value }))} placeholder="Paris" /></div>
                </div>
                <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13, color: 'rgba(255,255,255,0.6)', cursor: 'pointer' }}>
                  <input type="checkbox" checked={whForm.isDefault} onChange={e => setWHForm(f => ({ ...f, isDefault: e.target.checked }))} />
                  Entrepôt par défaut
                </label>
                <button type="submit" className="btn-auth" disabled={saving}>{saving ? <span className="spinner" /> : 'Créer l\'entrepôt →'}</button>
              </form>
            </div>
          </div>
        )}
      </DashboardLayout>
    </>
  )
}
