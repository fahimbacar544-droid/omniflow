import Head from 'next/head'
import { useState } from 'react'
import DashboardLayout from '../../components/DashboardLayout'
import { useRequireAuth, useTrackings } from '../../lib/hooks'
import { api } from '../../lib/api'
import { format } from 'date-fns'
import { fr } from 'date-fns/locale'

const STATUS_BADGE: Record<string, string> = { PENDING:'badge-gray',IN_TRANSIT:'badge-blue',OUT_FOR_DELIVERY:'badge-orange',DELIVERED:'badge-green',EXCEPTION:'badge-red',RETURNED:'badge-purple' }
const STATUS_LABEL: Record<string, string> = { PENDING:'En attente',IN_TRANSIT:'En transit',OUT_FOR_DELIVERY:'En livraison',DELIVERED:'Livré',EXCEPTION:'Problème',RETURNED:'Retourné' }

export default function Tracking() {
  const { loading: authLoading } = useRequireAuth()
  const { data, isLoading, mutate } = useTrackings()
  const [showAdd, setShowAdd] = useState(false)
  const [form, setForm] = useState({ trackingNumber: '', carrier: '' })
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')

  const trackings = data?.trackings || []

  if (authLoading) return null

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    try {
      await api.createTracking(form)
      mutate()
      setShowAdd(false)
      setForm({ trackingNumber: '', carrier: '' })
      setMsg('Colis ajouté ✓')
      setTimeout(() => setMsg(''), 3000)
    } catch (err: any) { setMsg(err.message) }
    finally { setSaving(false) }
  }

  const inTransit = trackings.filter((t: any) => t.status === 'IN_TRANSIT').length
  const delivered = trackings.filter((t: any) => t.status === 'DELIVERED').length
  const problems  = trackings.filter((t: any) => t.status === 'EXCEPTION').length

  return (
    <>
      <Head><title>Tracking — OmniFlow</title></Head>
      <DashboardLayout title="Tracking & Livraisons" subtitle="Suivi des colis en temps réel" active="tracking"
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn-sm" onClick={() => window.open('/t', '_blank')}>Page publique ↗</button>
            <button className="btn-sm accent" onClick={() => setShowAdd(true)}>+ Ajouter colis</button>
          </div>
        }
      >
        {msg && <div style={{ background: 'rgba(200,241,53,0.08)', border: '1px solid rgba(200,241,53,0.2)', borderRadius: 10, padding: '10px 16px', fontSize: 13, color: 'var(--accent)', marginBottom: 16 }}>{msg}</div>}

        <div className="kpi-grid">
          <div className="kpi-card"><div className="kpi-label">Colis actifs</div><div className="kpi-value">{trackings.length}</div></div>
          <div className="kpi-card"><div className="kpi-label">En transit</div><div className="kpi-value">{inTransit}</div></div>
          <div className="kpi-card"><div className="kpi-label">Livrés</div><div className="kpi-value">{delivered}</div><div className="kpi-change up">✓</div></div>
          <div className="kpi-card"><div className="kpi-label">Problèmes</div><div className="kpi-value" style={{ color: problems > 0 ? '#ff6b6b' : 'var(--white)' }}>{problems}</div>{problems > 0 && <div className="kpi-change warn">⚠ Attention</div>}</div>
        </div>

        <div className="table-wrap">
          <div className="table-header"><div className="table-title">Tous les colis</div></div>
          {isLoading ? (
            <div style={{ padding: 40, textAlign: 'center' }}><span className="spinner" style={{ width: 24, height: 24, borderTopColor: 'var(--accent)' }} /></div>
          ) : trackings.length === 0 ? (
            <div className="empty-state">
              <div className="empty-state-icon">🚚</div>
              Aucun colis suivi — ajoutez un numéro de suivi
              <br />
              <button className="btn-sm accent" style={{ marginTop: 16 }} onClick={() => setShowAdd(true)}>+ Ajouter un colis</button>
            </div>
          ) : (
            <table>
              <thead><tr><th>N° suivi</th><th>Transporteur</th><th>Client</th><th>Dernier événement</th><th>Statut</th><th>Lien public</th></tr></thead>
              <tbody>
                {trackings.map((t: any) => (
                  <tr key={t.id}>
                    <td style={{ fontFamily: 'monospace', color: 'var(--accent)', fontSize: 12 }}>{t.trackingNumber}</td>
                    <td style={{ color: 'rgba(255,255,255,0.6)' }}>{t.carrier}</td>
                    <td style={{ fontSize: 13 }}>{t.order?.customerName || '—'}</td>
                    <td style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>
                      {t.events?.[0]?.event || '—'}
                      {t.events?.[0]?.occurredAt && <span style={{ marginLeft: 6, color: 'rgba(255,255,255,0.2)' }}>{format(new Date(t.events[0].occurredAt), 'd MMM', { locale: fr })}</span>}
                    </td>
                    <td><span className={`badge ${STATUS_BADGE[t.status] || 'badge-gray'}`}>{STATUS_LABEL[t.status] || t.status}</span></td>
                    <td>
                      <button className="btn-sm" onClick={() => { navigator.clipboard.writeText(`${process.env.NEXT_PUBLIC_APP_URL}/t/${t.publicSlug}`); setMsg('Lien copié ✓'); setTimeout(() => setMsg(''), 2000) }}>
                        Copier lien
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {showAdd && (
          <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) setShowAdd(false) }}>
            <div className="modal-box">
              <button className="modal-close" onClick={() => setShowAdd(false)}>✕</button>
              <div style={{ fontFamily: 'var(--serif)', fontSize: 20, color: 'var(--white)', marginBottom: 20 }}>Suivre un colis</div>
              <form onSubmit={handleAdd} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <div className="field"><label>Numéro de suivi *</label><input required value={form.trackingNumber} onChange={e => setForm(f => ({ ...f, trackingNumber: e.target.value }))} placeholder="CF123456789FR" autoFocus /></div>
                <div className="field">
                  <label>Transporteur *</label>
                  <select required value={form.carrier} onChange={e => setForm(f => ({ ...f, carrier: e.target.value }))}>
                    <option value="">— Choisir</option>
                    {['Colissimo','DHL','UPS','FedEx','Chronopost','YunExpress','4PX','Cainiao','La Poste'].map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <button type="submit" className="btn-auth" disabled={saving}>{saving ? <span className="spinner" /> : 'Ajouter le suivi →'}</button>
              </form>
            </div>
          </div>
        )}
      </DashboardLayout>
    </>
  )
}
