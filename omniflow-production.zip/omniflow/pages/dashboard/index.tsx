import Head from 'next/head'
import { useRouter } from 'next/router'
import DashboardLayout from '../../components/DashboardLayout'
import { useRequireAuth, useAnalytics, useOrders } from '../../lib/hooks'
import { format } from 'date-fns'
import { fr } from 'date-fns/locale'

function fmt(n: number) {
  return new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(n)
}

const STATUS_BADGE: Record<string, string> = {
  PENDING: 'badge-orange', PROCESSING: 'badge-blue', SHIPPED: 'badge-blue',
  IN_TRANSIT: 'badge-blue', DELIVERED: 'badge-green', RETURNED: 'badge-gray', CANCELED: 'badge-red',
}
const STATUS_LABEL: Record<string, string> = {
  PENDING: 'En attente', PROCESSING: 'Traitement', SHIPPED: 'Expédié',
  IN_TRANSIT: 'En transit', DELIVERED: 'Livré', RETURNED: 'Retourné', CANCELED: 'Annulé',
}
const PLATFORM_COLORS: Record<string, string> = {
  SHOPIFY: '#95BE46', AMAZON: '#FF9900', WOOCOMMERCE: '#7F54B3',
  TIKTOK: '#FE2C55', ETSY: '#F56400', PRESTASHOP: '#DF0067', MANUAL: '#888',
}

export default function Dashboard() {
  const { user, loading: authLoading } = useRequireAuth()
  const { data: stats, isLoading: statsLoading } = useAnalytics()
  const { data: ordersData } = useOrders({ limit: '6' })
  const router = useRouter()

  if (authLoading) return <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><span className="spinner" style={{ width: 32, height: 32, borderWidth: 3, borderTopColor: 'var(--accent)' }} /></div>

  const kpis = stats?.kpis
  const dailyRevenue = stats?.dailyRevenue || {}
  const revenueValues = Object.values(dailyRevenue) as number[]
  const maxRevenue = Math.max(...revenueValues, 1)
  const orders = ordersData?.orders || []

  return (
    <>
      <Head><title>Vue d'ensemble — OmniFlow</title></Head>
      <DashboardLayout
        title="Vue d'ensemble"
        subtitle={format(new Date(), "EEEE d MMMM yyyy", { locale: fr })}
        active="overview"
        actions={
          <button className="btn-sm accent" onClick={() => window.location.reload()}>↻ Actualiser</button>
        }
      >
        {/* KPIs */}
        <div className="kpi-grid">
          <div className="kpi-card">
            <div className="kpi-label">Commandes aujourd'hui</div>
            <div className="kpi-value">{statsLoading ? '—' : fmt(kpis?.ordersToday ?? 0)}</div>
            <div className="kpi-change up">{kpis?.ordersMonth ? `${fmt(kpis.ordersMonth)} ce mois` : '—'}</div>
          </div>
          <div className="kpi-card">
            <div className="kpi-label">Chiffre d'affaires aujourd'hui</div>
            <div className="kpi-value">{statsLoading ? '—' : fmt(kpis?.revenueToday ?? 0) + '€'}</div>
            <div className="kpi-change up">{kpis?.revenueMonth ? fmt(kpis.revenueMonth) + '€ ce mois' : '—'}</div>
          </div>
          <div className="kpi-card">
            <div className="kpi-label">Ruptures de stock</div>
            <div className="kpi-value" style={{ color: (kpis?.ruptureCount ?? 0) > 0 ? '#ff6b6b' : 'var(--white)' }}>{statsLoading ? '—' : kpis?.ruptureCount ?? 0}</div>
            <div className={`kpi-change ${(kpis?.lowStockCount ?? 0) > 0 ? 'warn' : 'up'}`}>{kpis?.lowStockCount ? `${kpis.lowStockCount} produits bas` : 'Tout OK'}</div>
          </div>
          <div className="kpi-card">
            <div className="kpi-label">En transit</div>
            <div className="kpi-value">{statsLoading ? '—' : fmt(kpis?.ordersInTransit ?? 0)}</div>
            <div className="kpi-change up">{kpis?.ordersDelivered ? fmt(kpis.ordersDelivered) + ' livrées' : '—'}</div>
          </div>
        </div>

        <div className="grid-2">
          {/* Recent Orders */}
          <div className="table-wrap">
            <div className="table-header">
              <div className="table-title">Dernières commandes</div>
              <button className="btn-sm" onClick={() => router.push('/dashboard/orders')}>Voir tout</button>
            </div>
            {orders.length === 0 ? (
              <div className="empty-state">
                <div className="empty-state-icon">📋</div>
                Aucune commande pour l'instant
                <br />
                <button className="btn-sm accent" style={{ marginTop: 16 }} onClick={() => router.push('/dashboard/orders')}>Ajouter une commande</button>
              </div>
            ) : (
              <table>
                <thead><tr><th>Client</th><th>Plateforme</th><th>Montant</th><th>Statut</th></tr></thead>
                <tbody>
                  {orders.map((o: any) => (
                    <tr key={o.id} style={{ cursor: 'pointer' }} onClick={() => router.push('/dashboard/orders')}>
                      <td style={{ color: 'rgba(255,255,255,0.85)' }}>{o.customerName}</td>
                      <td>
                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 12 }}>
                          <span style={{ width: 6, height: 6, borderRadius: '50%', background: PLATFORM_COLORS[o.platform] || '#888', flexShrink: 0, display: 'inline-block' }} />
                          {o.platform}
                        </span>
                      </td>
                      <td style={{ fontWeight: 500, color: 'var(--white)' }}>{fmt(o.totalAmount)}€</td>
                      <td><span className={`badge ${STATUS_BADGE[o.status] || 'badge-gray'}`}>{STATUS_LABEL[o.status] || o.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          <div>
            {/* Revenue chart */}
            <div className="dash-card" style={{ marginBottom: 16 }}>
              <div className="card-title">Revenus — 7 derniers jours</div>
              {revenueValues.length === 0 ? (
                <div style={{ height: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'rgba(255,255,255,0.2)', fontSize: 13 }}>Pas encore de données</div>
              ) : (
                <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height: 100, paddingBottom: 8 }}>
                  {Object.entries(dailyRevenue).map(([date, val]) => {
                    const h = Math.max(4, Math.round(((val as number) / maxRevenue) * 90))
                    const d = new Date(date)
                    return (
                      <div key={date} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                        <div title={`${fmt(val as number)}€`} style={{ width: '100%', height: h, background: 'rgba(200,241,53,0.3)', borderRadius: '3px 3px 0 0', transition: 'all 0.3s', cursor: 'pointer' }} />
                        <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.25)' }}>{format(d, 'EEE', { locale: fr })}</div>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>

            {/* Critical stocks */}
            {stats?.criticalStocks?.length > 0 && (
              <div className="dash-card">
                <div className="card-title">Stocks critiques</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  {stats.criticalStocks.slice(0, 4).map((s: any) => (
                    <div key={s.sku}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 5 }}>
                        <span style={{ color: 'rgba(255,255,255,0.7)' }}>{s.productName}</span>
                        <span style={{ color: s.isRupture ? '#ff5050' : '#ffb432', fontWeight: 500 }}>{s.quantity} u.</span>
                      </div>
                      <div className="progress-bar">
                        <div className="progress-fill" style={{ width: `${Math.min(100, (s.quantity / s.minLevel) * 100)}%`, background: s.isRupture ? '#ff5050' : '#ffb432' }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Platform breakdown */}
            {stats?.platformBreakdown?.length > 0 && (
              <div className="dash-card" style={{ marginTop: 16 }}>
                <div className="card-title">Ventes par plateforme</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {stats.platformBreakdown.map((p: any) => {
                    const total = stats.platformBreakdown.reduce((s: number, x: any) => s + x.count, 0)
                    const pct = total > 0 ? Math.round((p.count / total) * 100) : 0
                    return (
                      <div key={p.platform} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <div style={{ width: 8, height: 8, borderRadius: '50%', background: PLATFORM_COLORS[p.platform] || '#888', flexShrink: 0 }} />
                        <span style={{ fontSize: 13, color: 'rgba(255,255,255,0.65)', flex: 1 }}>{p.platform}</span>
                        <div style={{ flex: 1, background: 'rgba(255,255,255,0.06)', borderRadius: 100, height: 4 }}>
                          <div style={{ width: `${pct}%`, height: '100%', background: PLATFORM_COLORS[p.platform] || '#888', borderRadius: 100 }} />
                        </div>
                        <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', minWidth: 32, textAlign: 'right' }}>{pct}%</span>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      </DashboardLayout>
    </>
  )
}
