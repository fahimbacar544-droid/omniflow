import Head from 'next/head'
import DashboardLayout from '../../components/DashboardLayout'
import { useRequireAuth, useAnalytics } from '../../lib/hooks'
import { format, subDays } from 'date-fns'
import { fr } from 'date-fns/locale'

function fmt(n: number) {
  return new Intl.NumberFormat('fr-FR').format(Math.round(n))
}

const PLATFORM_COLORS: Record<string, string> = {
  SHOPIFY: '#95BE46', AMAZON: '#FF9900', WOOCOMMERCE: '#7F54B3',
  TIKTOK: '#FE2C55', ETSY: '#F56400', PRESTASHOP: '#DF0067', MANUAL: '#888',
}

export default function Analytics() {
  const { loading: authLoading } = useRequireAuth()
  const { data: stats, isLoading } = useAnalytics()

  if (authLoading) return null

  const kpis = stats?.kpis
  const dailyRevenue = stats?.dailyRevenue || {}
  const revenueValues = Object.values(dailyRevenue) as number[]
  const maxRevenue = Math.max(...revenueValues, 1)
  const totalRevenue = revenueValues.reduce((s, v) => s + v, 0)
  const platformBreakdown = stats?.platformBreakdown || []
  const totalOrders = platformBreakdown.reduce((s: number, p: any) => s + p.count, 0)

  return (
    <>
      <Head><title>Analytics — OmniFlow</title></Head>
      <DashboardLayout title="Analytics" subtitle="Performance et chiffres clés" active="analytics">
        <div className="kpi-grid">
          <div className="kpi-card"><div className="kpi-label">CA ce mois</div><div className="kpi-value">{isLoading ? '—' : fmt(kpis?.revenueMonth ?? 0) + '€'}</div></div>
          <div className="kpi-card"><div className="kpi-label">Commandes ce mois</div><div className="kpi-value">{isLoading ? '—' : fmt(kpis?.ordersMonth ?? 0)}</div></div>
          <div className="kpi-card"><div className="kpi-label">Panier moyen</div>
            <div className="kpi-value">{isLoading || !kpis?.ordersMonth ? '—' : fmt((kpis?.revenueMonth ?? 0) / (kpis?.ordersMonth || 1)) + '€'}</div>
          </div>
          <div className="kpi-card"><div className="kpi-label">Taux livraison</div>
            <div className="kpi-value">{isLoading || !kpis ? '—' : kpis.ordersDelivered + kpis.ordersMonth === 0 ? '—' : Math.round((kpis.ordersDelivered / Math.max(kpis.ordersMonth, 1)) * 100) + '%'}</div>
          </div>
        </div>

        {/* Revenue chart */}
        <div className="table-wrap" style={{ marginBottom: 20 }}>
          <div className="table-header">
            <div className="table-title">Revenus — 7 derniers jours</div>
            <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.4)' }}>Total : <strong style={{ color: 'var(--white)' }}>{fmt(totalRevenue)}€</strong></div>
          </div>
          <div style={{ padding: '20px 20px 12px' }}>
            {revenueValues.every(v => v === 0) ? (
              <div className="empty-state" style={{ padding: '32px 0' }}>Pas encore de données de revenus</div>
            ) : (
              <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8, height: 160, paddingBottom: 24 }}>
                {Object.entries(dailyRevenue).map(([date, val]) => {
                  const h = Math.max(4, Math.round(((val as number) / maxRevenue) * 140))
                  return (
                    <div key={date} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                      <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.3)', marginBottom: 4 }}>{val as number > 0 ? fmt(val as number) + '€' : ''}</div>
                      <div title={`${fmt(val as number)}€`} style={{ width: '100%', height: h, background: 'rgba(200,241,53,0.3)', borderRadius: '4px 4px 0 0', transition: 'all 0.3s', cursor: 'pointer', minHeight: 4 }}
                        onMouseEnter={e => (e.currentTarget.style.background = 'rgba(200,241,53,0.6)') }
                        onMouseLeave={e => (e.currentTarget.style.background = 'rgba(200,241,53,0.3)')}
                      />
                      <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)' }}>{format(new Date(date), 'EEE', { locale: fr })}</div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </div>

        <div className="grid-2">
          {/* Platform breakdown */}
          <div className="dash-card">
            <div className="card-title">Répartition par plateforme</div>
            {platformBreakdown.length === 0 ? (
              <div className="empty-state" style={{ padding: '24px 0' }}>Pas de données</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                {platformBreakdown.map((p: any) => {
                  const pct = totalOrders > 0 ? Math.round((p.count / totalOrders) * 100) : 0
                  return (
                    <div key={p.platform}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 6 }}>
                        <span style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'rgba(255,255,255,0.7)' }}>
                          <span style={{ width: 8, height: 8, borderRadius: '50%', background: PLATFORM_COLORS[p.platform] || '#888', display: 'inline-block' }} />
                          {p.platform}
                        </span>
                        <span style={{ color: 'var(--white)', fontWeight: 500 }}>{fmt(p.revenue)}€ <span style={{ color: 'rgba(255,255,255,0.3)', fontWeight: 400 }}>({pct}%)</span></span>
                      </div>
                      <div className="progress-bar">
                        <div className="progress-fill" style={{ width: `${pct}%`, background: PLATFORM_COLORS[p.platform] || '#888', opacity: 0.7 }} />
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>

          {/* Order status */}
          <div className="dash-card">
            <div className="card-title">Statuts des commandes</div>
            {!kpis ? (
              <div className="empty-state" style={{ padding: '24px 0' }}>Pas de données</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                {[
                  { label: 'Livrées', value: kpis.ordersDelivered, color: '#64dc78', badge: 'badge-green' },
                  { label: 'En transit', value: kpis.ordersInTransit, color: '#64b4ff', badge: 'badge-blue' },
                  { label: 'En attente', value: kpis.ordersPending, color: '#ffb432', badge: 'badge-orange' },
                ].map(row => {
                  const total = kpis.ordersDelivered + kpis.ordersInTransit + kpis.ordersPending
                  const pct = total > 0 ? Math.round((row.value / total) * 100) : 0
                  return (
                    <div key={row.label} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <span className={`badge ${row.badge}`} style={{ minWidth: 76, justifyContent: 'center' }}>{row.label}</span>
                      <div style={{ flex: 1, background: 'rgba(255,255,255,0.06)', borderRadius: 100, height: 6 }}>
                        <div style={{ width: `${pct}%`, height: '100%', background: row.color, borderRadius: 100 }} />
                      </div>
                      <span style={{ fontSize: 13, color: 'rgba(255,255,255,0.5)', minWidth: 40, textAlign: 'right' }}>{fmt(row.value)}</span>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </div>
      </DashboardLayout>
    </>
  )
}
