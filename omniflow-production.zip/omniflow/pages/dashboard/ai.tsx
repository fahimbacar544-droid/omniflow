import Head from 'next/head'
import DashboardLayout from '../../components/DashboardLayout'
import { useRequireAuth, useAnalytics, useStocks } from '../../lib/hooks'

export default function AI() {
  const { loading: authLoading } = useRequireAuth()
  const { data: stats } = useAnalytics()
  const { data: stocksData } = useStocks()

  if (authLoading) return null

  const criticalStocks = stats?.criticalStocks || []
  const products = stocksData?.products || []

  // Generate real AI insights from actual data
  const insights: { type: 'urgent' | 'warning' | 'success' | 'info'; title: string; body: string }[] = []

  criticalStocks.forEach((s: any) => {
    if (s.isRupture) {
      insights.push({ type: 'urgent', title: `🚨 Rupture — ${s.productName}`, body: `Stock à 0 dans ${s.warehouseName}. Réapprovisionnement immédiat recommandé.` })
    } else {
      insights.push({ type: 'warning', title: `⚡ Stock bas — ${s.productName}`, body: `${s.quantity} unités restantes (seuil : ${s.minLevel}). Commandez dès maintenant.` })
    }
  })

  if (stats?.kpis?.revenueToday > 0) {
    insights.push({ type: 'success', title: '📈 Activité du jour', body: `${stats.kpis.ordersToday} commandes pour ${Math.round(stats.kpis.revenueToday)}€ aujourd'hui.` })
  }

  if (insights.length === 0 && products.length === 0) {
    insights.push({ type: 'info', title: '💡 Commencez par ajouter des produits', body: 'L\'IA analysera vos stocks, commandes et ventes pour générer des recommandations personnalisées.' })
    insights.push({ type: 'info', title: '🔌 Connectez vos boutiques', body: 'Reliez Shopify, Amazon ou WooCommerce pour obtenir des insights en temps réel sur vos ventes.' })
  }

  if (stats?.kpis?.ordersMonth > 10) {
    const avg = Math.round(stats.kpis.revenueMonth / stats.kpis.ordersMonth)
    insights.push({ type: 'info', title: '📊 Panier moyen', body: `Votre panier moyen ce mois est de ${avg}€ sur ${stats.kpis.ordersMonth} commandes.` })
  }

  const COLORS: Record<string, string> = { urgent: '#ff5050', warning: '#ffb432', success: '#64dc78', info: '#64b4ff' }

  return (
    <>
      <Head><title>IA & Prévisions — OmniFlow</title></Head>
      <DashboardLayout title="IA & Prévisions" subtitle="Insights générés depuis vos données réelles" active="ai">
        <div className="kpi-grid">
          <div className="kpi-card"><div className="kpi-label">Insights actifs</div><div className="kpi-value">{insights.length}</div></div>
          <div className="kpi-card"><div className="kpi-label">Ruptures détectées</div><div className="kpi-value" style={{ color: criticalStocks.filter((s: any) => s.isRupture).length > 0 ? '#ff6b6b' : 'var(--white)' }}>{criticalStocks.filter((s: any) => s.isRupture).length}</div></div>
          <div className="kpi-card"><div className="kpi-label">Stocks bas</div><div className="kpi-value">{criticalStocks.filter((s: any) => !s.isRupture).length}</div></div>
          <div className="kpi-card"><div className="kpi-label">Produits analysés</div><div className="kpi-value">{products.length}</div></div>
        </div>

        <div className="grid-2">
          <div>
            <div className="table-wrap">
              <div className="table-header"><div className="table-title">Insights en temps réel</div></div>
              <div style={{ padding: '12px 16px' }}>
                {insights.length === 0 ? (
                  <div className="empty-state" style={{ padding: '32px 0' }}>
                    <div className="empty-state-icon">🤖</div>
                    Ajoutez des produits et commandes pour recevoir des insights IA
                  </div>
                ) : insights.map((ins, i) => (
                  <div key={i} style={{ padding: '14px 16px', border: '1px solid var(--border)', borderRadius: 12, marginBottom: 10, background: 'rgba(255,255,255,0.02)', position: 'relative', overflow: 'hidden' }}>
                    <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 3, background: COLORS[ins.type], borderRadius: 2 }} />
                    <div style={{ paddingLeft: 8 }}>
                      <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--white)', marginBottom: 4 }}>{ins.title}</div>
                      <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.45)', lineHeight: 1.5 }}>{ins.body}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div>
            <div className="dash-card" style={{ marginBottom: 16 }}>
              <div className="card-title">Prévisions stocks</div>
              {products.length === 0 ? (
                <div className="empty-state" style={{ padding: '24px 0' }}>Ajoutez des produits pour voir les prévisions</div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  {products.slice(0, 5).map((p: any) => (
                    <div key={p.id}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 5 }}>
                        <span style={{ color: 'rgba(255,255,255,0.7)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '60%' }}>{p.name}</span>
                        <span style={{ color: p.status === 'RUPTURE' ? '#ff5050' : p.status === 'BAS' ? '#ffb432' : '#64dc78', fontWeight: 500, flexShrink: 0 }}>{p.totalStock} u.</span>
                      </div>
                      <div className="progress-bar">
                        <div className="progress-fill" style={{
                          width: `${Math.min(100, (p.totalStock / Math.max(...products.map((x: any) => x.totalStock), 1)) * 100)}%`,
                          background: p.status === 'RUPTURE' ? '#ff5050' : p.status === 'BAS' ? '#ffb432' : '#64dc78',
                          opacity: 0.7
                        }} />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="dash-card" style={{ padding: '20px 22px' }}>
              <div className="card-title">Pour des insights avancés</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {[
                  { icon: '🔗', text: 'Connectez Shopify ou Amazon pour les données de ventes', done: false },
                  { icon: '📦', text: 'Ajoutez vos produits avec niveaux de stock', done: products.length > 0 },
                  { icon: '📋', text: 'Enregistrez vos commandes', done: (stats?.kpis?.ordersMonth ?? 0) > 0 },
                  { icon: '⚡', text: 'Configurez des règles d\'automatisation', done: false },
                ].map((item, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13 }}>
                    <span style={{ fontSize: 14 }}>{item.icon}</span>
                    <span style={{ flex: 1, color: item.done ? 'rgba(255,255,255,0.4)' : 'rgba(255,255,255,0.7)' }}>{item.text}</span>
                    {item.done && <span style={{ color: '#64dc78', fontSize: 12 }}>✓</span>}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </DashboardLayout>
    </>
  )
}
