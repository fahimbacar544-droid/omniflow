import Head from 'next/head'
import { useState } from 'react'
import DashboardLayout from '../../components/DashboardLayout'
import { useRequireAuth, useShops } from '../../lib/hooks'
import { api } from '../../lib/api'
import { PLANS } from '../../lib/stripe'

const PLAN_INFO: Record<string, { name: string; price: number }> = {
  STARTER: { name: 'Starter', price: 29 },
  PRO: { name: 'Pro', price: 79 },
  BUSINESS: { name: 'Business', price: 149 },
  ENTERPRISE: { name: 'Enterprise', price: 499 },
}

export default function Settings() {
  const { user, loading: authLoading } = useRequireAuth()
  const { data: shopsData, mutate: mutateShops } = useShops()
  const [saving, setSaving] = useState(false)
  const [portalLoading, setPortalLoading] = useState(false)
  const [msg, setMsg] = useState('')
  const [showAddShop, setShowAddShop] = useState(false)
  const [shopForm, setShopForm] = useState({ name: '', platform: 'SHOPIFY', url: '', apiKey: '', apiSecret: '' })

  const shops = shopsData?.shops || []
  const plan = user?.plan ? PLAN_INFO[user.plan] : null

  if (authLoading) return null

  async function handlePortal() {
    setPortalLoading(true)
    try {
      const { url } = await api.openPortal()
      window.location.href = url
    } catch (err: any) {
      setMsg('Erreur : ' + err.message)
    } finally {
      setPortalLoading(false)
    }
  }

  async function handleAddShop(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    try {
      await api.createShop(shopForm)
      mutateShops()
      setShowAddShop(false)
      setMsg('Boutique connectée ✓')
      setTimeout(() => setMsg(''), 3000)
    } catch (err: any) {
      setMsg(err.message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <>
      <Head><title>Paramètres — OmniFlow</title></Head>
      <DashboardLayout title="Paramètres" subtitle="Compte, boutiques et facturation" active="settings">
        {msg && (
          <div style={{ background: 'rgba(200,241,53,0.08)', border: '1px solid rgba(200,241,53,0.2)', borderRadius: 10, padding: '10px 16px', fontSize: 13, color: 'var(--accent)', marginBottom: 20 }}>
            {msg}
          </div>
        )}

        <div className="grid-2">
          {/* Profile */}
          <div className="dash-card">
            <div className="card-title">Profil</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 8 }}>
                <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'rgba(200,241,53,0.15)', border: '1px solid rgba(200,241,53,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, fontWeight: 500, color: 'var(--accent)' }}>
                  {user?.name?.charAt(0).toUpperCase()}
                </div>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 500, color: 'var(--white)' }}>{user?.name}</div>
                  <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.4)' }}>{user?.email}</div>
                </div>
              </div>
              <div className="field">
                <label>Nom complet</label>
                <input defaultValue={user?.name} placeholder="Votre nom" />
              </div>
              <div className="field">
                <label>Email</label>
                <input defaultValue={user?.email} type="email" disabled style={{ opacity: 0.5 }} />
              </div>
              <div className="field">
                <label>Nouveau mot de passe</label>
                <input type="password" placeholder="Laisser vide pour ne pas changer" />
              </div>
              <button className="btn-sm accent" style={{ alignSelf: 'flex-start' }} onClick={() => { setMsg('Profil sauvegardé ✓'); setTimeout(() => setMsg(''), 3000) }}>
                Sauvegarder
              </button>
            </div>
          </div>

          {/* Subscription */}
          <div className="dash-card">
            <div className="card-title">Abonnement</div>
            {plan ? (
              <>
                <div style={{ background: 'rgba(200,241,53,0.05)', border: '1px solid rgba(200,241,53,0.2)', borderRadius: 12, padding: '16px 20px', marginBottom: 16 }}>
                  <div style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'rgba(200,241,53,0.6)', marginBottom: 4 }}>Plan actif</div>
                  <div style={{ fontFamily: 'var(--serif)', fontSize: 28, color: 'var(--white)', letterSpacing: -1 }}>{plan.price}€<span style={{ fontFamily: 'var(--sans)', fontSize: 14, color: 'rgba(255,255,255,0.4)' }}>/mois</span></div>
                  <div style={{ fontSize: 16, fontWeight: 500, color: 'var(--accent)', marginTop: 2 }}>{plan.name}</div>
                  <div style={{ marginTop: 8 }}><span className={`badge ${user?.subscriptionStatus === 'ACTIVE' ? 'badge-green' : 'badge-orange'}`}>{user?.subscriptionStatus === 'ACTIVE' ? 'Actif' : user?.subscriptionStatus}</span></div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <button className="btn-sm" onClick={handlePortal} disabled={portalLoading} style={{ textAlign: 'left', justifyContent: 'flex-start' }}>
                    {portalLoading ? <span className="spinner" style={{ borderTopColor: 'rgba(255,255,255,0.6)' }} /> : '💳  Gérer la facturation (portail Stripe)'}
                  </button>
                  <button className="btn-sm" onClick={() => window.location.href = '/checkout?plan=BUSINESS'} style={{ textAlign: 'left', justifyContent: 'flex-start' }}>
                    ↑  Changer de plan
                  </button>
                </div>
              </>
            ) : (
              <>
                <p style={{ fontSize: 14, color: 'rgba(255,255,255,0.4)', marginBottom: 16 }}>Vous n'avez pas encore d'abonnement actif.</p>
                <button className="btn-sm accent" onClick={() => window.location.href = '/checkout?plan=STARTER'}>
                  Choisir un plan →
                </button>
              </>
            )}
          </div>

          {/* Shops */}
          <div className="dash-card">
            <div className="card-title" style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>Boutiques connectées</span>
              <button className="btn-sm accent" style={{ fontSize: 11 }} onClick={() => setShowAddShop(true)}>+ Ajouter</button>
            </div>
            {shops.length === 0 ? (
              <div className="empty-state" style={{ padding: '24px 0' }}>
                <div className="empty-state-icon" style={{ fontSize: 28 }}>🏪</div>
                Aucune boutique connectée
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {shops.map((s: any) => (
                  <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', background: 'rgba(255,255,255,0.03)', borderRadius: 10 }}>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: s.active ? '#64dc78' : '#888', flexShrink: 0 }} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.8)' }}>{s.name}</div>
                      <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)' }}>{s.platform}{s.url ? ` — ${s.url}` : ''}</div>
                    </div>
                    <span className={`badge ${s.active ? 'badge-green' : 'badge-gray'}`}>{s.active ? 'Active' : 'Inactive'}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* API Keys */}
          <div className="dash-card">
            <div className="card-title">API & Webhooks</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div>
                <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', marginBottom: 8 }}>Clé API OmniFlow</div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <div style={{ flex: 1, background: 'rgba(255,255,255,0.04)', border: '1px solid var(--border)', borderRadius: 8, padding: '8px 14px', fontFamily: 'monospace', fontSize: 12, color: 'rgba(255,255,255,0.3)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    sk_omni_{user?.id?.substring(0, 8)}••••••••••••••
                  </div>
                  <button className="btn-sm" onClick={() => { navigator.clipboard.writeText('sk_omni_' + user?.id); setMsg('Clé copiée ✓'); setTimeout(() => setMsg(''), 2000) }}>Copier</button>
                </div>
              </div>
              <div>
                <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', marginBottom: 8 }}>URL Webhook</div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <div style={{ flex: 1, background: 'rgba(255,255,255,0.04)', border: '1px solid var(--border)', borderRadius: 8, padding: '8px 14px', fontFamily: 'monospace', fontSize: 12, color: 'rgba(255,255,255,0.3)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {process.env.NEXT_PUBLIC_APP_URL}/api/webhooks/stripe
                  </div>
                  <button className="btn-sm" onClick={() => { setMsg('URL copiée ✓'); setTimeout(() => setMsg(''), 2000) }}>Copier</button>
                </div>
              </div>
              <div style={{ padding: '12px 14px', background: 'rgba(255,180,50,0.06)', border: '1px solid rgba(255,180,50,0.15)', borderRadius: 10, fontSize: 12, color: 'rgba(255,180,50,0.8)', lineHeight: 1.5 }}>
                ⚠ Ajoutez cette URL webhook dans votre dashboard Stripe → Developers → Webhooks pour activer les paiements automatiques.
              </div>
            </div>
          </div>
        </div>

        {/* Add Shop Modal */}
        {showAddShop && (
          <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) setShowAddShop(false) }}>
            <div className="modal-box">
              <button className="modal-close" onClick={() => setShowAddShop(false)}>✕</button>
              <div style={{ fontFamily: 'var(--serif)', fontSize: 20, color: 'var(--white)', marginBottom: 20 }}>Connecter une boutique</div>
              <form onSubmit={handleAddShop} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <div className="field">
                  <label>Nom de la boutique *</label>
                  <input required value={shopForm.name} onChange={e => setShopForm(f => ({ ...f, name: e.target.value }))} placeholder="Ma boutique Shopify" />
                </div>
                <div className="field">
                  <label>Plateforme *</label>
                  <select value={shopForm.platform} onChange={e => setShopForm(f => ({ ...f, platform: e.target.value }))}>
                    {['SHOPIFY','WOOCOMMERCE','AMAZON','TIKTOK','ETSY','PRESTASHOP','MANUAL'].map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
                <div className="field">
                  <label>URL de la boutique</label>
                  <input value={shopForm.url} onChange={e => setShopForm(f => ({ ...f, url: e.target.value }))} placeholder="ma-boutique.myshopify.com" />
                </div>
                <div className="field">
                  <label>Clé API</label>
                  <input value={shopForm.apiKey} onChange={e => setShopForm(f => ({ ...f, apiKey: e.target.value }))} placeholder="Clé API de la plateforme" />
                </div>
                <div className="field">
                  <label>Secret API</label>
                  <input type="password" value={shopForm.apiSecret} onChange={e => setShopForm(f => ({ ...f, apiSecret: e.target.value }))} placeholder="Secret API" />
                </div>
                <button type="submit" className="btn-auth" disabled={saving}>
                  {saving ? <span className="spinner" /> : 'Connecter la boutique →'}
                </button>
              </form>
            </div>
          </div>
        )}
      </DashboardLayout>
    </>
  )
}
