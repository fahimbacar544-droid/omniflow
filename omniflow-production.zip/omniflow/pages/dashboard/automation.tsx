import Head from 'next/head'
import { useState } from 'react'
import DashboardLayout from '../../components/DashboardLayout'
import { useRequireAuth, useAutomations } from '../../lib/hooks'
import { api } from '../../lib/api'

const TEMPLATES = [
  { name: 'Commande France → Colissimo', trigger: 'ORDER_CREATED', action: 'ASSIGN_CARRIER', conditions: '{"country":"FR","carrier":"Colissimo"}', desc: 'Auto-assign Colissimo pour les commandes françaises' },
  { name: 'Stock < seuil → Réapprovisionnement', trigger: 'STOCK_LOW', action: 'REORDER', conditions: '{"auto":true}', desc: 'Commander automatiquement quand le stock est bas' },
  { name: 'Commande USA → DHL Express', trigger: 'ORDER_CREATED', action: 'ASSIGN_CARRIER', conditions: '{"country":"US","carrier":"DHL"}', desc: 'Routage DHL pour les commandes américaines' },
  { name: 'Retard colis → Email client', trigger: 'TRACKING_DELAYED', action: 'SEND_EMAIL', conditions: '{"delay_days":3,"discount":"10%"}', desc: 'Email automatique + bon réduction si retard' },
]

export default function Automation() {
  const { loading: authLoading } = useRequireAuth()
  const { data, isLoading, mutate } = useAutomations()
  const [showAdd, setShowAdd] = useState(false)
  const [form, setForm] = useState({ name: '', description: '', trigger: 'ORDER_CREATED', action: 'ASSIGN_CARRIER', conditions: '' })
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')

  const automations = data?.automations || []
  if (authLoading) return null

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    try {
      await api.createAutomation(form)
      mutate()
      setShowAdd(false)
      setMsg('Règle créée ✓')
      setTimeout(() => setMsg(''), 3000)
    } catch (err: any) { setMsg(err.message) }
    finally { setSaving(false) }
  }

  async function toggle(id: string, active: boolean) {
    await api.toggleAutomation(id, !active)
    mutate()
  }

  async function remove(id: string) {
    if (!confirm('Supprimer cette règle ?')) return
    await api.deleteAutomation(id)
    mutate()
  }

  async function useTemplate(t: typeof TEMPLATES[0]) {
    setSaving(true)
    try {
      await api.createAutomation({ name: t.name, description: t.desc, trigger: t.trigger, action: t.action, conditions: t.conditions })
      mutate()
      setMsg('Règle créée depuis le template ✓')
      setTimeout(() => setMsg(''), 3000)
    } catch (err: any) { setMsg(err.message) }
    finally { setSaving(false) }
  }

  const active = automations.filter((a: any) => a.active).length
  const totalExec = automations.reduce((s: number, a: any) => s + a.execCount, 0)

  return (
    <>
      <Head><title>Automatisation — OmniFlow</title></Head>
      <DashboardLayout title="Automatisation" subtitle="Règles intelligentes sans code" active="automation"
        actions={<button className="btn-sm accent" onClick={() => setShowAdd(true)}>+ Nouvelle règle</button>}
      >
        {msg && <div style={{ background: 'rgba(200,241,53,0.08)', border: '1px solid rgba(200,241,53,0.2)', borderRadius: 10, padding: '10px 16px', fontSize: 13, color: 'var(--accent)', marginBottom: 16 }}>{msg}</div>}

        <div className="kpi-grid">
          <div className="kpi-card"><div className="kpi-label">Règles actives</div><div className="kpi-value">{active}</div></div>
          <div className="kpi-card"><div className="kpi-label">Total règles</div><div className="kpi-value">{automations.length}</div></div>
          <div className="kpi-card"><div className="kpi-label">Exécutions totales</div><div className="kpi-value">{totalExec.toLocaleString('fr-FR')}</div></div>
          <div className="kpi-card"><div className="kpi-label">Dernière activité</div>
            <div className="kpi-value" style={{ fontSize: 16 }}>
              {automations.find((a: any) => a.lastRunAt) ? new Date(automations.find((a: any) => a.lastRunAt).lastRunAt).toLocaleDateString('fr-FR') : '—'}
            </div>
          </div>
        </div>

        {/* Mes règles */}
        {isLoading ? (
          <div style={{ padding: 40, textAlign: 'center' }}><span className="spinner" style={{ width: 24, height: 24, borderTopColor: 'var(--accent)' }} /></div>
        ) : automations.length > 0 ? (
          <div className="table-wrap" style={{ marginBottom: 28 }}>
            <div className="table-header"><div className="table-title">Mes règles</div></div>
            <div style={{ padding: '8px 12px' }}>
              {automations.map((a: any) => (
                <div key={a.id} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 8px', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                  <div className={`toggle ${a.active ? 'on' : 'off'}`} onClick={() => toggle(a.id, a.active)} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, color: 'var(--white)', marginBottom: 2 }}>{a.name}</div>
                    {a.description && <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.35)' }}>{a.description}</div>}
                  </div>
                  <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.25)', minWidth: 80, textAlign: 'right' }}>{a.execCount} exec.</div>
                  <button className="btn-sm danger" onClick={() => remove(a.id)}>✕</button>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        {/* Templates */}
        <div>
          <div style={{ fontSize: 13, fontWeight: 500, color: 'rgba(255,255,255,0.5)', marginBottom: 12, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Templates prêts à l'emploi</div>
          <div className="grid-2">
            {TEMPLATES.map((t, i) => (
              <div key={i} className="dash-card" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--white)' }}>{t.name}</div>
                <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', lineHeight: 1.5, flex: 1 }}>{t.desc}</div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <span style={{ fontSize: 11, padding: '3px 8px', background: 'rgba(100,180,255,0.1)', color: '#64b4ff', borderRadius: 6 }}>{t.trigger}</span>
                  <span style={{ fontSize: 11, padding: '3px 8px', background: 'rgba(200,241,53,0.1)', color: 'var(--accent)', borderRadius: 6 }}>{t.action}</span>
                </div>
                <button className="btn-sm accent" onClick={() => useTemplate(t)} disabled={saving}>Utiliser ce template →</button>
              </div>
            ))}
          </div>
        </div>

        {showAdd && (
          <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) setShowAdd(false) }}>
            <div className="modal-box">
              <button className="modal-close" onClick={() => setShowAdd(false)}>✕</button>
              <div style={{ fontFamily: 'var(--serif)', fontSize: 20, color: 'var(--white)', marginBottom: 20 }}>Nouvelle règle</div>
              <form onSubmit={handleAdd} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <div className="field"><label>Nom de la règle *</label><input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Commande France → Colissimo" autoFocus /></div>
                <div className="field"><label>Description</label><input value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Description courte de la règle" /></div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="field"><label>Déclencheur</label>
                    <select value={form.trigger} onChange={e => setForm(f => ({ ...f, trigger: e.target.value }))}>
                      {['ORDER_CREATED','STOCK_LOW','TRACKING_DELAYED','PAYMENT_RECEIVED','DELIVERY_FAILED'].map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                  <div className="field"><label>Action</label>
                    <select value={form.action} onChange={e => setForm(f => ({ ...f, action: e.target.value }))}>
                      {['ASSIGN_CARRIER','REORDER','SEND_EMAIL','NOTIFY','UPDATE_STATUS','CREATE_LABEL'].map(a => <option key={a} value={a}>{a}</option>)}
                    </select>
                  </div>
                </div>
                <div className="field">
                  <label>Conditions (JSON)</label>
                  <input value={form.conditions} onChange={e => setForm(f => ({ ...f, conditions: e.target.value }))} placeholder='{"country":"FR","carrier":"Colissimo"}' style={{ fontFamily: 'monospace', fontSize: 12 }} />
                </div>
                <button type="submit" className="btn-auth" disabled={saving}>{saving ? <span className="spinner" /> : 'Créer la règle →'}</button>
              </form>
            </div>
          </div>
        )}
      </DashboardLayout>
    </>
  )
}
