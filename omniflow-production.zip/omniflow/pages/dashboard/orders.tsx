import Head from 'next/head'
import { useState } from 'react'
import DashboardLayout from '../../components/DashboardLayout'
import { useRequireAuth, useOrders } from '../../lib/hooks'
import { api } from '../../lib/api'
import { mutate } from 'swr'
import { format } from 'date-fns'
import { fr } from 'date-fns/locale'

const STATUS_BADGE: Record<string, string> = { PENDING:'badge-orange',PROCESSING:'badge-blue',SHIPPED:'badge-blue',IN_TRANSIT:'badge-blue',DELIVERED:'badge-green',RETURNED:'badge-gray',CANCELED:'badge-red' }
const STATUS_LABEL: Record<string, string> = { PENDING:'En attente',PROCESSING:'Traitement',SHIPPED:'Expédié',IN_TRANSIT:'En transit',DELIVERED:'Livré',RETURNED:'Retourné',CANCELED:'Annulé' }
const PLATFORM_COLORS: Record<string, string> = { SHOPIFY:'#95BE46',AMAZON:'#FF9900',WOOCOMMERCE:'#7F54B3',TIKTOK:'#FE2C55',ETSY:'#F56400',PRESTASHOP:'#DF0067',MANUAL:'#888' }

export default function Orders() {
  const { loading: authLoading } = useRequireAuth()
  const [filter, setFilter] = useState<Record<string, string>>({})
  const { data, isLoading, mutate: revalidate } = useOrders(filter)
  const [showAdd, setShowAdd] = useState(false)
  const [form, setForm] = useState({ customerName: '', customerEmail: '', totalAmount: '', platform: 'MANUAL', carrier: '', trackingNumber: '' })
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')

  const orders = data?.orders || []

  if (authLoading) return null

  async function handleAddOrder(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    try {
      await api.createOrder({ ...form, totalAmount: parseFloat(form.totalAmount) || 0 })
      revalidate()
      setShowAdd(false)
      setForm({ customerName: '', customerEmail: '', totalAmount: '', platform: 'MANUAL', carrier: '', trackingNumber: '' })
      setMsg('Commande ajoutée ✓')
      setTimeout(() => setMsg(''), 3000)
    } catch (err: any) {
      setMsg(err.message)
    } finally {
      setSaving(false)
    }
  }

  async function updateStatus(id: string, status: string) {
    await api.updateOrder(id, { status })
    revalidate()
  }

  return (
    <>
      <Head><title>Commandes — OmniFlow</title></Head>
      <DashboardLayout title="Commandes" subtitle="Toutes vos commandes multi-plateformes" active="orders"
        actions={<button className="btn-sm accent" onClick={() => setShowAdd(true)}>+ Nouvelle commande</button>}
      >
        {msg && <div style={{ background: 'rgba(200,241,53,0.08)', border: '1px solid rgba(200,241,53,0.2)', borderRadius: 10, padding: '10px 16px', fontSize: 13, color: 'var(--accent)', marginBottom: 16 }}>{msg}</div>}

        {/* Filters */}
        <div style={{ display: 'flex', gap: 10, marginBottom: 20, flexWrap: 'wrap' }}>
          {['', 'PENDING', 'IN_TRANSIT', 'DELIVERED', 'CANCELED'].map(s => (
            <button key={s} className={`btn-sm${filter.status === s || (!s && !filter.status) ? ' accent' : ''}`}
              onClick={() => setFilter(f => s ? { ...f, status: s } : {})}
            >{s ? STATUS_LABEL[s] : 'Toutes'}</button>
          ))}
          <select style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid var(--border)', borderRadius: 8, padding: '6px 12px', color: 'rgba(255,255,255,0.6)', fontFamily: 'var(--sans)', fontSize: 12, outline: 'none', marginLeft: 'auto' }}
            onChange={e => setFilter(f => e.target.value ? { ...f, platform: e.target.value } : Object.fromEntries(Object.entries(f).filter(([k]) => k !== 'platform')))}
          >
            <option value="">Toutes plateformes</option>
            {['SHOPIFY','AMAZON','WOOCOMMERCE','TIKTOK','ETSY','PRESTASHOP','MANUAL'].map(p => <option key={p} value={p}>{p}</option>)}
          </select>
        </div>

        <div className="table-wrap">
          <div className="table-header">
            <div className="table-title">{data?.total ?? 0} commandes</div>
          </div>
          {isLoading ? (
            <div style={{ padding: 40, textAlign: 'center' }}><span className="spinner" style={{ width: 24, height: 24, borderTopColor: 'var(--accent)' }} /></div>
          ) : orders.length === 0 ? (
            <div className="empty-state">
              <div className="empty-state-icon">📋</div>
              Aucune commande trouvée
            </div>
          ) : (
            <table>
              <thead><tr><th>Client</th><th>Produits</th><th>Plateforme</th><th>Montant</th><th>Transporteur</th><th>Statut</th><th>Date</th><th>Action</th></tr></thead>
              <tbody>
                {orders.map((o: any) => (
                  <tr key={o.id}>
                    <td>
                      <div style={{ color: 'rgba(255,255,255,0.85)', fontWeight: 500 }}>{o.customerName}</div>
                      {o.customerEmail && <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)' }}>{o.customerEmail}</div>}
                    </td>
                    <td style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>{o.items?.length || 0} article(s)</td>
                    <td>
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 12 }}>
                        <span style={{ width: 7, height: 7, borderRadius: '50%', background: PLATFORM_COLORS[o.platform] || '#888', display: 'inline-block' }} />
                        {o.platform}
                      </span>
                    </td>
                    <td style={{ fontWeight: 500, color: 'var(--white)' }}>{o.totalAmount.toLocaleString('fr-FR')}€</td>
                    <td style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12 }}>{o.carrier || '—'}</td>
                    <td>
                      <select className="badge" style={{ border: 'none', cursor: 'pointer', fontFamily: 'var(--sans)', fontSize: 11, fontWeight: 500, outline: 'none' }}
                        defaultValue={o.status}
                        onChange={e => updateStatus(o.id, e.target.value)}
                        style={{ background: 'transparent', border: 'none', outline: 'none', cursor: 'pointer', fontFamily: 'var(--sans)', fontSize: 11, fontWeight: 500, color: '#64dc78' }}
                      >
                        {Object.entries(STATUS_LABEL).map(([k,v]) => <option key={k} value={k}>{v}</option>)}
                      </select>
                    </td>
                    <td style={{ fontSize: 12, color: 'rgba(255,255,255,0.3)' }}>{format(new Date(o.createdAt), 'd MMM', { locale: fr })}</td>
                    <td><button className="btn-sm danger" onClick={async () => { if (confirm('Supprimer cette commande ?')) { await api.deleteOrder(o.id); revalidate() } }}>✕</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Add Order Modal */}
        {showAdd && (
          <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) setShowAdd(false) }}>
            <div className="modal-box">
              <button className="modal-close" onClick={() => setShowAdd(false)}>✕</button>
              <div style={{ fontFamily: 'var(--serif)', fontSize: 20, color: 'var(--white)', marginBottom: 4 }}>Nouvelle commande</div>
              <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.35)', marginBottom: 24 }}>Ajouter une commande manuellement</p>
              <form onSubmit={handleAddOrder} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <div className="field"><label>Nom du client *</label><input required value={form.customerName} onChange={e => setForm(f => ({ ...f, customerName: e.target.value }))} placeholder="Marie Dupont" /></div>
                <div className="field"><label>Email client</label><input type="email" value={form.customerEmail} onChange={e => setForm(f => ({ ...f, customerEmail: e.target.value }))} placeholder="marie@exemple.com" /></div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="field"><label>Montant (€) *</label><input type="number" required min="0" step="0.01" value={form.totalAmount} onChange={e => setForm(f => ({ ...f, totalAmount: e.target.value }))} placeholder="89.00" /></div>
                  <div className="field"><label>Plateforme</label>
                    <select value={form.platform} onChange={e => setForm(f => ({ ...f, platform: e.target.value }))}>
                      {['SHOPIFY','AMAZON','WOOCOMMERCE','TIKTOK','ETSY','PRESTASHOP','MANUAL'].map(p => <option key={p} value={p}>{p}</option>)}
                    </select>
                  </div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="field"><label>Transporteur</label><input value={form.carrier} onChange={e => setForm(f => ({ ...f, carrier: e.target.value }))} placeholder="Colissimo" /></div>
                  <div className="field"><label>N° suivi</label><input value={form.trackingNumber} onChange={e => setForm(f => ({ ...f, trackingNumber: e.target.value }))} placeholder="CF123456789FR" /></div>
                </div>
                <button type="submit" className="btn-auth" disabled={saving}>{saving ? <span className="spinner" /> : 'Ajouter la commande →'}</button>
              </form>
            </div>
          </div>
        )}
      </DashboardLayout>
    </>
  )
}
