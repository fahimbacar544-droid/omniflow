import Head from 'next/head'
import { useRouter } from 'next/router'
import { useState } from 'react'
import { api } from '../lib/api'
import { useRequireNoAuth } from '../lib/hooks'

export default function Login() {
  useRequireNoAuth()
  const router = useRouter()
  const { plan } = router.query

  const [form, setForm] = useState({ email: '', password: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (!form.email || !form.password) { setError('Email et mot de passe requis'); return }

    setLoading(true)
    try {
      await api.login(form)
      if (plan && plan !== 'undefined') {
        router.push(`/checkout?plan=${plan}`)
      } else {
        router.push('/dashboard')
      }
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <Head><title>Connexion — OmniFlow</title></Head>
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
        <div style={{ width: '100%', maxWidth: 420 }}>
          <div style={{ fontFamily: 'var(--serif)', fontSize: 28, color: 'var(--white)', marginBottom: 6, cursor: 'pointer' }} onClick={() => router.push('/')}>
            Omni<span style={{ color: 'var(--accent)' }}>Flow</span>
          </div>
          <p style={{ fontSize: 14, color: 'rgba(255,255,255,0.4)', marginBottom: 32 }}>Connectez-vous à votre compte</p>
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {error && <div className="auth-error">{error}</div>}
            <div className="field">
              <label>Email</label>
              <input type="email" placeholder="vous@exemple.com" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} autoFocus />
            </div>
            <div className="field">
              <label>Mot de passe</label>
              <input type="password" placeholder="••••••••" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} />
            </div>
            <button type="submit" className="btn-auth" disabled={loading}>
              {loading ? <span className="spinner" /> : 'Se connecter →'}
            </button>
          </form>
          <p className="auth-switch">Pas de compte ? <a onClick={() => router.push(plan ? `/register?plan=${plan}` : '/register')}>Créer un compte gratuitement</a></p>
        </div>
      </div>
    </>
  )
}
