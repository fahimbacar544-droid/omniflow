import Head from 'next/head'
import { GetServerSideProps } from 'next'
import { format } from 'date-fns'
import { fr } from 'date-fns/locale'

const STATUS_LABEL: Record<string, string> = {
  PENDING: 'En attente', IN_TRANSIT: 'En transit', OUT_FOR_DELIVERY: 'En livraison',
  DELIVERED: 'Livré', EXCEPTION: 'Problème', RETURNED: 'Retourné',
}
const STATUS_BADGE: Record<string, string> = {
  PENDING: '#888', IN_TRANSIT: '#64b4ff', OUT_FOR_DELIVERY: '#ffb432',
  DELIVERED: '#64dc78', EXCEPTION: '#ff5050', RETURNED: '#b464ff',
}

export default function PublicTracking({ tracking, error }: { tracking: any; error?: string }) {
  if (error) {
    return (
      <>
        <Head><title>Suivi introuvable — OmniFlow</title></Head>
        <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 24, textAlign: 'center' }}>
          <div style={{ fontFamily: 'var(--serif)', fontSize: 28, color: 'var(--white)', marginBottom: 16 }}>Omni<span style={{ color: 'var(--accent)' }}>Flow</span></div>
          <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.4)', marginBottom: 8 }}>Suivi introuvable</div>
          <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.25)' }}>{error}</div>
        </div>
      </>
    )
  }

  return (
    <>
      <Head>
        <title>Suivi {tracking.trackingNumber} — OmniFlow</title>
        <meta name="description" content={`Suivez votre colis ${tracking.trackingNumber} en temps réel`} />
      </Head>
      <div style={{ minHeight: '100vh', padding: '60px 24px' }}>
        <div style={{ maxWidth: 640, margin: '0 auto' }}>
          <div style={{ fontFamily: 'var(--serif)', fontSize: 28, color: 'var(--white)', textAlign: 'center', marginBottom: 8 }}>
            Omni<span style={{ color: 'var(--accent)' }}>Flow</span>
          </div>
          <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.35)', textAlign: 'center', marginBottom: 40 }}>Suivi de votre colis en temps réel</div>

          <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid var(--border)', borderRadius: 20, padding: 32 }}>
            {/* Header */}
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
              <div>
                <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.3)', marginBottom: 4 }}>Numéro de suivi</div>
                <div style={{ fontFamily: 'monospace', fontSize: 16, fontWeight: 500, color: 'var(--accent)' }}>{tracking.trackingNumber}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.3)', marginBottom: 4 }}>Transporteur</div>
                <div style={{ fontSize: 14, color: 'var(--white)' }}>{tracking.carrier}</div>
              </div>
              <div style={{ padding: '6px 14px', borderRadius: 100, background: `${STATUS_BADGE[tracking.status]}18`, color: STATUS_BADGE[tracking.status], fontSize: 13, fontWeight: 500 }}>
                {STATUS_LABEL[tracking.status] || tracking.status}
              </div>
            </div>

            {/* Current status */}
            {tracking.currentEvent && (
              <div style={{ background: 'rgba(200,241,53,0.05)', border: '1px solid rgba(200,241,53,0.15)', borderRadius: 12, padding: '14px 18px', marginBottom: 24, display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ width: 8, height: 8, background: 'var(--accent)', borderRadius: '50%', animation: 'pulse 2s infinite', flexShrink: 0 }} />
                <span style={{ fontSize: 14, color: 'rgba(255,255,255,0.7)' }}>{tracking.currentEvent}</span>
              </div>
            )}

            {/* Estimated */}
            {tracking.estimatedDate && (
              <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.4)', marginBottom: 24, textAlign: 'center' }}>
                Livraison estimée : <strong style={{ color: 'var(--white)' }}>{format(new Date(tracking.estimatedDate), "EEEE d MMMM", { locale: fr })}</strong>
              </div>
            )}

            {/* Timeline */}
            {tracking.events?.length > 0 && (
              <div style={{ borderTop: '1px solid var(--border)', paddingTop: 20 }}>
                <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'rgba(255,255,255,0.3)', marginBottom: 16 }}>Historique</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
                  {tracking.events.map((ev: any, i: number) => (
                    <div key={ev.id} style={{ display: 'flex', gap: 16, paddingBottom: i < tracking.events.length - 1 ? 20 : 0, position: 'relative' }}>
                      {i < tracking.events.length - 1 && (
                        <div style={{ position: 'absolute', left: 13, top: 28, bottom: 0, width: 1, background: 'rgba(255,255,255,0.08)' }} />
                      )}
                      <div style={{ width: 28, height: 28, borderRadius: '50%', border: `2px solid ${i === 0 ? 'var(--accent)' : 'rgba(255,255,255,0.15)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, flexShrink: 0, zIndex: 1, background: '#0d0d0d', color: i === 0 ? 'var(--accent)' : 'rgba(255,255,255,0.2)' }}>
                        {i === 0 ? '→' : '✓'}
                      </div>
                      <div style={{ flex: 1, paddingTop: 4 }}>
                        <div style={{ fontSize: 14, color: i === 0 ? 'var(--white)' : 'rgba(255,255,255,0.5)', marginBottom: 2 }}>{ev.event}</div>
                        {ev.location && <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.3)', marginBottom: 2 }}>📍 {ev.location}</div>}
                        <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.25)' }}>{format(new Date(ev.occurredAt), "d MMM yyyy, HH:mm", { locale: fr })}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Order items */}
            {tracking.order?.items?.length > 0 && (
              <div style={{ borderTop: '1px solid var(--border)', paddingTop: 20, marginTop: 20 }}>
                <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'rgba(255,255,255,0.3)', marginBottom: 12 }}>Contenu du colis</div>
                {tracking.order.items.map((item: any) => (
                  <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: 'rgba(255,255,255,0.5)', padding: '6px 0' }}>
                    <span>{item.name}</span>
                    <span>x{item.quantity}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div style={{ textAlign: 'center', marginTop: 32, fontSize: 13, color: 'rgba(255,255,255,0.2)' }}>
            Suivi propulsé par <a href="/" style={{ color: 'var(--accent)' }}>OmniFlow</a>
          </div>
        </div>
      </div>
    </>
  )
}

export const getServerSideProps: GetServerSideProps = async ({ params }) => {
  const slug = params?.slug as string
  try {
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'
    const res = await fetch(`${baseUrl}/api/tracking/public/${slug}`)
    if (!res.ok) return { props: { tracking: null, error: 'Numéro de suivi introuvable' } }
    const { tracking } = await res.json()
    return { props: { tracking } }
  } catch {
    return { props: { tracking: null, error: 'Erreur lors de la récupération du suivi' } }
  }
}
